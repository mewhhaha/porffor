use icu_collator::provider::{
    CollationDiacriticsV1, CollationJamoV1, CollationMetadataV1, CollationReorderingV1,
    CollationRootV1, CollationSpecialPrimariesV1, CollationTailoringV1,
};
use icu_locale::LocaleFallbacker;
use icu_normalizer::provider::{NormalizerNfdDataV1, NormalizerNfdTablesV1};
use icu_provider::{DataMarker, DataProvider, DataRequest, IterableDataProvider};
use icu_provider_export::baked_exporter::{BakedExporter, BakedExporterCloseMetadata, Options};
use icu_provider_export::{DataLocaleFamily, DeduplicationStrategy, ExportDriver};
use icu_provider_source::{CollationRootHan, SourceDataProvider};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::error::Error;
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};

const INPUT_SHA256: &str = "e5dae398d77a31ee7fcd86e4b35041cf9bf4643c694794629fc7c5dca76d9c6b";

fn sha256(path: &Path) -> Result<String, Box<dyn Error>> {
    Ok(format!("{:x}", Sha256::digest(fs::read(path)?)))
}

fn collect_files(root: &Path, at: &Path, output: &mut Vec<Value>) -> Result<(), Box<dyn Error>> {
    let mut entries = fs::read_dir(at)?.collect::<Result<Vec<_>, _>>()?;
    entries.sort_by_key(|entry| entry.file_name());
    for entry in entries {
        let path = entry.path();
        let kind = entry.file_type()?;
        if kind.is_symlink() {
            return Err(format!("generated source is a symlink: {}", path.display()).into());
        }
        if kind.is_dir() {
            collect_files(root, &path, output)?;
        } else if kind.is_file() {
            output.push(json!({
                "path": path.strip_prefix(root)?.to_str().ok_or("non-UTF8 generated path")?,
                "bytes": fs::metadata(&path)?.len(),
                "sha256": sha256(&path)?,
            }));
        } else {
            return Err(format!("unexpected generated entry: {}", path.display()).into());
        }
    }
    Ok(())
}

fn write_new_json(path: &Path, value: &Value) -> Result<(), Box<dyn Error>> {
    let mut file = OpenOptions::new().write(true).create_new(true).open(path)?;
    serde_json::to_writer_pretty(&mut file, value)?;
    writeln!(file)?;
    file.sync_all()?;
    Ok(())
}

fn run() -> Result<(), Box<dyn Error>> {
    let arguments = std::env::args_os().skip(1).collect::<Vec<_>>();
    if arguments.len() != 1 {
        return Err("usage: collator-export <checksum-pinned-icu-export.zip>".into());
    }
    let source_path = PathBuf::from(&arguments[0]).canonicalize()?;
    if sha256(&source_path)? != INPUT_SHA256 {
        return Err(
            "ICU export archive checksum does not match the captured official release".into(),
        );
    }
    let package = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let generated = package.join("generated");
    let receipt_path = package.join("export-receipt.json");
    if generated.exists() || receipt_path.exists() {
        return Err("refusing to overwrite generated source or an existing export receipt".into());
    }
    let lock = package.join("Cargo.lock");
    if !lock.is_file() {
        return Err("export requires the actual Cargo-generated isolated lockfile".into());
    }

    // new_custom selects the pinned Small TrieType default. There is no small-trie
    // setter in this release; calling with_fast_tries would select different files.
    // Only the captured ZIP is available to this networking-disabled provider.
    let provider = SourceDataProvider::new_custom()
        .with_icuexport(&source_path)?
        .with_collation_root_han(CollationRootHan::Implicit);
    let identifiers = IterableDataProvider::<CollationMetadataV1>::iter_ids(&provider)?;
    let mut source_metadata = Vec::with_capacity(identifiers.len());
    for id in &identifiers {
        let response = DataProvider::<CollationMetadataV1>::load(
            &provider,
            DataRequest {
                id: id.as_borrowed(),
                metadata: Default::default(),
            },
        )?;
        source_metadata.push(json!({
            "locale": id.locale.to_string(),
            "attributes": id.marker_attributes.as_str(),
            "metadata_bits": response.payload.get().bits,
        }));
    }
    if !source_metadata.iter().any(|row| {
        row["locale"] == "de" && row["attributes"] == "search" && row["metadata_bits"] == 9
    }) {
        return Err("captured genuine German search metadata was not loaded".into());
    }
    if !source_metadata
        .iter()
        .any(|row| row["locale"] == "ko" && row["attributes"] == "searchjl")
    {
        return Err("captured genuine Korean searchjl metadata was not loaded".into());
    }
    let markers = [
        CollationRootV1::INFO,
        CollationTailoringV1::INFO,
        CollationMetadataV1::INFO,
        CollationDiacriticsV1::INFO,
        CollationJamoV1::INFO,
        CollationReorderingV1::INFO,
        CollationSpecialPrimariesV1::INFO,
        NormalizerNfdDataV1::INFO,
        NormalizerNfdTablesV1::INFO,
    ];
    let mut options = Options::default();
    options.use_separate_crates = true;
    // Keep pinned internal fallback and non-overwrite behavior. FULL plus None
    // retains identifier coverage, while fallback handles non-explicit requests.
    let metadata = ExportDriver::new(
        [DataLocaleFamily::FULL],
        DeduplicationStrategy::None.into(),
        LocaleFallbacker::new().static_to_owned(),
    )
    .with_markers(markers)
    .with_additional_collations([String::from("search*")])
    .export(&provider, BakedExporter::new(generated.clone(), options)?)?;
    let baked = metadata
        .exporter
        .0
        .ok_or("baked exporter returned no close metadata")?
        .downcast::<BakedExporterCloseMetadata>()
        .map_err(|_| "unexpected baked exporter close metadata type")?;
    if baked.statistics.len() != markers.len()
        || markers
            .iter()
            .any(|marker| !baked.statistics.contains_key(marker))
    {
        return Err(
            "baked exporter marker census does not match the nine constructor markers".into(),
        );
    }
    let statistics = baked
        .statistics
        .iter()
        .map(|(marker, statistic)| {
            json!({
                "marker": marker.id.name(),
                "structs_total_size": statistic.structs_total_size,
                "structs_count": statistic.structs_count,
                "lookup_struct_size": statistic.lookup_struct_size,
                "identifiers_count": statistic.identifiers_count,
            })
        })
        .collect::<Vec<_>>();
    let mut generated_files = Vec::new();
    collect_files(&generated, &generated, &mut generated_files)?;
    if !generated_files.iter().any(|row| row["path"] == "mod.rs") {
        return Err("baked exporter did not produce mod.rs".into());
    }
    let receipt = json!({
        "schema": "lila-collator-foundation-export/v1",
        "status": "completed genuine pinned source export; kernel admission not yet run",
        "input": {"path": source_path, "sha256": INPUT_SHA256},
        "exporter_binary_sha256": sha256(&std::env::current_exe()?)?,
        "cargo_lock_sha256": sha256(&lock)?,
        "settings": {
            "han": "Implicit", "normalization_trie": "Small (pinned new_custom default)",
            "locale_family": "FULL", "deduplication": "None", "additional_collations": ["search*"],
            "fallback": "icu_locale2.0.0 compiled_data (same pin required at runtime)",
            "use_internal_fallback": true, "use_separate_crates": true, "networking": false,
        },
        "source_metadata": source_metadata,
        "statistics": statistics,
        "required_crates": baked.required_crates,
        "generated_files": generated_files,
        "available_service_locale_count": null,
        "kernel_admission": false,
        "product_admission": false,
    });
    write_new_json(&receipt_path, &receipt)?;
    println!(
        "{}",
        serde_json::to_string(&json!({
            "export_receipt": receipt_path, "sha256": sha256(&receipt_path)?,
            "source_metadata_identifiers": identifiers.len(), "markers": markers.len(),
            "generated_files": receipt["generated_files"].as_array().map(Vec::len),
        }))?
    );
    Ok(())
}

fn main() {
    if let Err(error) = run() {
        eprintln!("collator-export: {error}");
        std::process::exit(1);
    }
}
