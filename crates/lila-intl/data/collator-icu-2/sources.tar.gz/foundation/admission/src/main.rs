use icu_collator::options::{AlternateHandling, CaseLevel, CollatorOptions, MaxVariable, Strength};
use icu_collator::preferences::{CollationCaseFirst, CollationNumericOrdering};
use icu_collator::provider::{
    CollationDiacriticsV1, CollationJamoV1, CollationMetadataV1, CollationReorderingV1,
    CollationRootV1, CollationSpecialPrimariesV1, CollationTailoringV1,
};
use icu_collator::{Collator, CollatorPreferences};
use icu_locale_core::{extensions::unicode::Value as UnicodeValue, Locale};
use icu_normalizer::provider::{NormalizerNfdDataV1, NormalizerNfdTablesV1};
use icu_provider::marker::DataMarkerExt;
use icu_provider::{
    DataError, DataIdentifierCow, DataMarker, DataProvider, DataRequest, DataResponse,
    IterableDataProvider,
};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::cell::RefCell;
use std::cmp::Ordering;
use std::collections::BTreeSet;
use std::error::Error;
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::Path;

include!(concat!(env!("CARGO_MANIFEST_DIR"), "/../generated/mod.rs"));

struct GeneratedProvider;
make_provider!(GeneratedProvider);
impl_collation_root_v1!(GeneratedProvider);
impl_collation_tailoring_v1!(GeneratedProvider);
// Only metadata needs enumeration. The pinned singleton ITER expansion has a
// BtreeSet spelling defect, so do not expand unused singleton iterable macros.
impl_collation_metadata_v1!(GeneratedProvider, ITER);
impl_collation_diacritics_v1!(GeneratedProvider);
impl_collation_jamo_v1!(GeneratedProvider);
impl_collation_reordering_v1!(GeneratedProvider);
impl_collation_special_primaries_v1!(GeneratedProvider);
impl_normalizer_nfd_data_v1!(GeneratedProvider);
impl_normalizer_nfd_tables_v1!(GeneratedProvider);

const EXPORT_RECEIPT: &str = include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../export-receipt.json"
));
const COMPILED_RECEIPT_SHA256: &str = env!("COLLATOR_EXPORT_RECEIPT_SHA256");

#[derive(Clone, Copy)]
enum LoadDomain {
    Profile,
    Diacritics,
    Singleton,
}

// This probe cannot relabel a missing search as sort. Every dynamic request is
// associated with one real metadata identifier; empty-attribute retry is a fault
// for every nonempty profile, including search/searchjl. Actual fallback locales
// remain observable in the returned trace, rather than assumed equal by a count.
struct ProbeProvider<'a> {
    expected: &'a DataIdentifierCow<'static>,
    bits: u32,
    observations: RefCell<Vec<Value>>,
}

impl<'a> ProbeProvider<'a> {
    fn new(expected: &'a DataIdentifierCow<'static>, bits: u32) -> Self {
        Self {
            expected,
            bits,
            observations: RefCell::new(Vec::new()),
        }
    }

    fn load<M: DataMarker>(
        &self,
        request: DataRequest,
        domain: LoadDomain,
        marker_name: &'static str,
    ) -> Result<DataResponse<M>, DataError>
    where
        GeneratedProvider: DataProvider<M>,
    {
        let profile_request = request.id == self.expected.as_borrowed();
        let singleton_request =
            request.id.locale.is_unknown() && request.id.marker_attributes.is_empty();
        let allowed = match domain {
            LoadDomain::Profile => profile_request,
            LoadDomain::Diacritics if self.bits & 16 != 0 => profile_request,
            LoadDomain::Diacritics | LoadDomain::Singleton => singleton_request,
        };
        if !allowed {
            return Err(DataError::custom(
                "constructor attempted a mismatched profile or missing-profile retry",
            )
            .with_req(M::INFO, request));
        }
        let response = DataProvider::<M>::load(&GeneratedProvider, request)?;
        self.observations.borrow_mut().push(json!({
            "marker": marker_name,
            "requested_locale": request.id.locale.to_string(),
            "requested_attributes": request.id.marker_attributes.as_str(),
            "returned_locale": response.metadata.locale.as_ref().unwrap_or(request.id.locale).to_string(),
            "internal_locale_fallback": response.metadata.locale.is_some(),
        }));
        Ok(response)
    }
}

macro_rules! trace_provider {
    ($marker:ident, $domain:expr) => {
        impl DataProvider<$marker> for ProbeProvider<'_> {
            fn load(&self, request: DataRequest) -> Result<DataResponse<$marker>, DataError> {
                self.load::<$marker>(request, $domain, stringify!($marker))
            }
        }
    };
}

trace_provider!(CollationMetadataV1, LoadDomain::Profile);
trace_provider!(CollationTailoringV1, LoadDomain::Profile);
trace_provider!(CollationReorderingV1, LoadDomain::Profile);
trace_provider!(CollationDiacriticsV1, LoadDomain::Diacritics);
trace_provider!(CollationRootV1, LoadDomain::Singleton);
trace_provider!(CollationJamoV1, LoadDomain::Singleton);
trace_provider!(CollationSpecialPrimariesV1, LoadDomain::Singleton);
trace_provider!(NormalizerNfdDataV1, LoadDomain::Singleton);
trace_provider!(NormalizerNfdTablesV1, LoadDomain::Singleton);

#[derive(Clone, Copy, Debug)]
enum Sensitivity {
    Base,
    Accent,
    Case,
    Variant,
}

impl Sensitivity {
    const ALL: [Self; 4] = [Self::Base, Self::Accent, Self::Case, Self::Variant];

    fn options(self, ignore: bool) -> CollatorOptions {
        let (strength, case_level) = match self {
            Self::Base => (Strength::Primary, CaseLevel::Off),
            Self::Accent => (Strength::Secondary, CaseLevel::Off),
            Self::Case => (Strength::Primary, CaseLevel::On),
            Self::Variant => (Strength::Tertiary, CaseLevel::Off),
        };
        let mut options = CollatorOptions::default();
        options.strength = Some(strength);
        options.case_level = Some(case_level);
        options.alternate_handling = Some(if ignore {
            AlternateHandling::Shifted
        } else {
            AlternateHandling::NonIgnorable
        });
        options.max_variable = Some(MaxVariable::Punctuation);
        options
    }
}

fn preferences(id: &DataIdentifierCow<'static>) -> Result<CollatorPreferences, Box<dyn Error>> {
    let locale: Locale = id.locale.to_string().parse()?;
    let mut preferences = CollatorPreferences::from(locale);
    if !id.marker_attributes.is_empty() {
        let value = UnicodeValue::try_from_str(id.marker_attributes.as_str())?;
        preferences.collation_type =
            Some(icu_collator::preferences::CollationType::try_from(&value)?);
    }
    // An exported marker identity that cannot actually be selected by the real
    // constructor must not silently be counted as a completed admission.
    if CollationTailoringV1::make_locale(preferences.locale_preferences) != id.locale {
        return Err(
            format!("metadata identifier {id} is not selectable by the real constructor").into(),
        );
    }
    Ok(preferences)
}

fn comparison(collator: &Collator, left: &[u16], right: &[u16]) -> i8 {
    match collator.as_borrowed().compare_utf16(left, right) {
        Ordering::Less => -1,
        Ordering::Equal => 0,
        Ordering::Greater => 1,
    }
}

fn units(value: &str) -> Vec<u16> {
    value.encode_utf16().collect()
}

fn require_equal(
    collator: &Collator,
    left: &[u16],
    right: &[u16],
    label: &str,
) -> Result<(), Box<dyn Error>> {
    if comparison(collator, left, right) != 0 || comparison(collator, right, left) != 0 {
        return Err(format!("{label}: required collation equality failed").into());
    }
    Ok(())
}

fn canonical_and_utf16(collator: &Collator) -> Result<usize, Box<dyn Error>> {
    for (left, right) in [
        ("ä", "a\u{0308}"),
        ("é", "e\u{0301}"),
        ("가", "\u{1100}\u{1161}"),
        ("각", "\u{1100}\u{1161}\u{11a8}"),
        ("힣", "\u{1112}\u{1175}\u{11c2}"),
    ] {
        require_equal(
            collator,
            &units(left),
            &units(right),
            "canonical equivalence (including Hangul)",
        )?;
    }
    for (raw, replaced) in [
        (vec![0xd800], vec![0xfffd]),
        (vec![0xdbff], vec![0xfffd]),
        (vec![0xdc00], vec![0xfffd]),
        (vec![0xdfff], vec![0xfffd]),
        (vec![0xd800, 0xd800], vec![0xfffd, 0xfffd]),
        (vec![0xdc00, 0xdfff], vec![0xfffd, 0xfffd]),
        (vec![0x61, 0xd800, 0x62], vec![0x61, 0xfffd, 0x62]),
        (vec![0xd800, 0xd83d, 0xde00], vec![0xfffd, 0xd83d, 0xde00]),
    ] {
        let decoded = utf16_iter::Utf16Chars::new(&raw)
            .flat_map(|character| {
                let mut pair = [0; 2];
                character.encode_utf16(&mut pair).to_vec()
            })
            .collect::<Vec<_>>();
        if decoded != replaced {
            return Err(
                "locked UTF16 iterator does not implement the selected maximal-subsequence policy"
                    .into(),
            );
        }
        require_equal(
            collator,
            &raw,
            &replaced,
            "documented maximal ill-formed replacement policy",
        )?;
    }
    require_equal(
        collator,
        &[0xd83d, 0xde00],
        &units("😀"),
        "valid surrogate pair",
    )?;
    let raw = [0x61, 0xd83d, 0xde00];
    let other = [0x61, 0xd83d, 0xde01];
    let scalar_result = comparison(collator, &units("a😀"), &units("a😁"));
    if comparison(collator, &raw, &other) != scalar_result {
        return Err("valid-pair prefix comparison changed the scalar interpretation".into());
    }
    let pair = [0x61, 0xd800, 0xdc00];
    let isolated = [0x61, 0xd800];
    let replacement = [0x61, 0xfffd];
    if comparison(collator, &pair, &isolated) != comparison(collator, &pair, &replacement) {
        return Err(
            "shared high-surrogate prefix split violated the selected replacement policy".into(),
        );
    }
    if comparison(collator, &pair, &replacement) == 0 {
        return Err(
            "a valid supplementary code point collapsed to an isolated replacement unit".into(),
        );
    }
    Ok(17)
}

fn consistent_comparator(collator: &Collator) -> Result<usize, Box<dyn Error>> {
    let corpus = [
        Vec::new(),
        units("a"),
        units("A"),
        units("a-"),
        units("2"),
        units("10"),
        vec![0xd800],
        vec![0xfffd],
        vec![0xd800, 0xdc00],
        vec![0xd800, 0xdc01],
    ];
    let mut comparisons = vec![vec![0; corpus.len()]; corpus.len()];
    for (i, left) in corpus.iter().enumerate() {
        for (j, right) in corpus.iter().enumerate() {
            comparisons[i][j] = comparison(collator, left, right);
        }
    }
    for i in 0..corpus.len() {
        if comparisons[i][i] != 0 {
            return Err("comparator reflexivity failed".into());
        }
        for j in 0..corpus.len() {
            if comparisons[i][j] != -comparisons[j][i] {
                return Err("comparator antisymmetry failed".into());
            }
            for k in 0..corpus.len() {
                if comparisons[i][j] <= 0 && comparisons[j][k] <= 0 && comparisons[i][k] > 0 {
                    return Err("comparator total-preorder transitivity failed".into());
                }
                if comparisons[i][j] == 0 && comparisons[i][k] != comparisons[j][k] {
                    return Err("comparator collation-equivalence substitution failed".into());
                }
            }
        }
    }
    Ok(corpus.len() * corpus.len())
}

fn resolved_json(collator: &Collator) -> Value {
    let options = collator.as_borrowed().resolved_options();
    json!({
        "strength": format!("{:?}", options.strength),
        "case_level": format!("{:?}", options.case_level),
        "alternate_handling": format!("{:?}", options.alternate_handling),
        "max_variable": format!("{:?}", options.max_variable),
        "case_first": format!("{:?}", options.case_first),
        "numeric": format!("{:?}", options.numeric),
    })
}

fn validate_trace(
    provider: &ProbeProvider<'_>,
    numeric: bool,
    ignore: bool,
) -> Result<Vec<Value>, Box<dyn Error>> {
    let trace = provider.observations.borrow().clone();
    let count = |name: &str| trace.iter().filter(|row| row["marker"] == name).count();
    for name in [
        "CollationRootV1",
        "CollationJamoV1",
        "CollationMetadataV1",
        "CollationDiacriticsV1",
        "NormalizerNfdDataV1",
        "NormalizerNfdTablesV1",
    ] {
        if count(name) != 1 {
            return Err(format!("constructor load census for {name} was not exactly one").into());
        }
    }
    for (name, expected) in [
        ("CollationTailoringV1", provider.bits & 8 != 0),
        ("CollationReorderingV1", provider.bits & 32 != 0),
        ("CollationSpecialPrimariesV1", numeric || ignore),
    ] {
        if count(name) != usize::from(expected) {
            return Err(
                format!("constructor flag/option payload association failed for {name}").into(),
            );
        }
    }
    Ok(trace)
}

fn admit_profile(id: &DataIdentifierCow<'static>) -> Result<Value, Box<dyn Error>> {
    let bits = DataProvider::<CollationMetadataV1>::load(
        &GeneratedProvider,
        DataRequest {
            id: id.as_borrowed(),
            metadata: Default::default(),
        },
    )?
    .payload
    .get()
    .bits;
    let defaults = ProbeProvider::new(id, bits);
    let collator =
        Collator::try_new_unstable(&defaults, preferences(id)?, CollatorOptions::default())?;
    let resolved = collator.as_borrowed().resolved_options();
    let expected_case = if bits & 512 == 0 {
        CollationCaseFirst::False
    } else if bits & 1024 != 0 {
        CollationCaseFirst::Upper
    } else {
        CollationCaseFirst::Lower
    };
    let default_ignore = bits & 256 != 0;
    if resolved.strength != Strength::Tertiary
        || resolved.case_level != CaseLevel::Off
        || resolved.numeric != CollationNumericOrdering::False
        || resolved.case_first != expected_case
        || resolved.alternate_handling
            != if default_ignore {
                AlternateHandling::Shifted
            } else {
                AlternateHandling::NonIgnorable
            }
        || resolved.max_variable != MaxVariable::Punctuation
    {
        return Err(format!(
            "{id}: actual defaults differ from the captured metadata-owned policy"
        )
        .into());
    }
    let default_trace = validate_trace(&defaults, false, default_ignore)?;
    canonical_and_utf16(&collator)?;
    consistent_comparator(&collator)?;
    let mut controls = Vec::new();
    for sensitivity in Sensitivity::ALL {
        for case_first in [
            CollationCaseFirst::False,
            CollationCaseFirst::Lower,
            CollationCaseFirst::Upper,
        ] {
            for numeric in [false, true] {
                for ignore in [false, true] {
                    let mut preferences = preferences(id)?;
                    preferences.case_first = Some(case_first);
                    preferences.numeric_ordering = Some(if numeric {
                        CollationNumericOrdering::True
                    } else {
                        CollationNumericOrdering::False
                    });
                    let provider = ProbeProvider::new(id, bits);
                    let collator = Collator::try_new_unstable(
                        &provider,
                        preferences,
                        sensitivity.options(ignore),
                    )?;
                    let resolved = collator.as_borrowed().resolved_options();
                    let wanted = sensitivity.options(ignore);
                    if Some(resolved.strength) != wanted.strength
                        || Some(resolved.case_level) != wanted.case_level
                        || Some(resolved.alternate_handling) != wanted.alternate_handling
                        || resolved.max_variable != MaxVariable::Punctuation
                        || resolved.case_first != case_first
                        || resolved.numeric
                            != if numeric {
                                CollationNumericOrdering::True
                            } else {
                                CollationNumericOrdering::False
                            }
                    {
                        return Err(
                            format!("{id}: a final option override was not consumed").into()
                        );
                    }
                    let canonical_utf16_controls = canonical_and_utf16(&collator)?;
                    let comparator_pairs = consistent_comparator(&collator)?;
                    controls.push(json!({
                        "sensitivity": format!("{sensitivity:?}"), "case_first": format!("{case_first:?}"),
                        "numeric": numeric, "ignore_punctuation": ignore,
                        "resolved": resolved_json(&collator),
                        "loads": validate_trace(&provider, numeric, ignore)?,
                        "canonical_utf16_controls": canonical_utf16_controls, "comparator_pairs": comparator_pairs,
                    }));
                }
            }
        }
    }
    Ok(json!({
        "locale": id.locale.to_string(), "attributes": id.marker_attributes.as_str(), "metadata_bits": bits,
        "default": {"resolved": resolved_json(&collator), "loads": default_trace},
        "option_control_count": controls.len(), "option_controls": controls,
    }))
}

fn selected_id(
    locale: &str,
    attributes: &str,
) -> Result<DataIdentifierCow<'static>, Box<dyn Error>> {
    Ok(DataIdentifierCow::from_owned(
        icu_provider::DataMarkerAttributes::try_from_str(attributes)
            .map_err(|error| format!("invalid marker attributes {attributes:?}: {error:?}"))?
            .to_owned(),
        locale.parse()?,
    ))
}

fn select(
    id: &DataIdentifierCow<'static>,
    options: CollatorOptions,
) -> Result<Collator, Box<dyn Error>> {
    let bits = DataProvider::<CollationMetadataV1>::load(
        &GeneratedProvider,
        DataRequest {
            id: id.as_borrowed(),
            metadata: Default::default(),
        },
    )?
    .payload
    .get()
    .bits;
    let provider = ProbeProvider::new(id, bits);
    Ok(Collator::try_new_unstable(
        &provider,
        preferences(id)?,
        options,
    )?)
}

fn focused_controls() -> Result<Value, Box<dyn Error>> {
    let german_sort = selected_id("de", "")?;
    let german_search = selected_id("de", "search")?;
    let sort = select(&german_sort, CollatorOptions::default())?;
    let search = select(&german_search, CollatorOptions::default())?;
    let sort_order = comparison(&sort, &units("AE"), &units("Ä"));
    let search_order = comparison(&search, &units("AE"), &units("Ä"));
    if sort_order != 1 || search_order > 0 {
        return Err(
            "German sort/search does not satisfy the actual pinned usage-de stable ordering".into(),
        );
    }
    let german_base = select(&german_search, Sensitivity::Base.options(false))?;
    require_equal(
        &german_base,
        &units("AE"),
        &units("Ä"),
        "genuine German search primary equivalence",
    )?;

    // The provider itself must reject the constructor's empty-attribute fallback;
    // success here would conceal missing search data as an unrelated sort result.
    // Zhuyin is a real ICU collation preference but has no German payload in
    // this export. An unknown keyword would fail preference parsing before the
    // constructor could exercise the missing-profile retry rejection.
    let nonexistent = selected_id("de", "zhuyin")?;
    let missing = ProbeProvider::new(&nonexistent, 9);
    if Collator::try_new_unstable(
        &missing,
        preferences(&nonexistent)?,
        CollatorOptions::default(),
    )
    .is_ok()
    {
        return Err(
            "nonexistent profile was silently retried as the default sort collation".into(),
        );
    }

    let english = selected_id("en", "")?;
    let mut sensitivity_results = Vec::new();
    for (sensitivity, case_equal, accent_equal) in [
        (Sensitivity::Base, true, true),
        (Sensitivity::Accent, true, false),
        (Sensitivity::Case, false, true),
        (Sensitivity::Variant, false, false),
    ] {
        let collator = select(&english, sensitivity.options(false))?;
        let case = comparison(&collator, &units("a"), &units("A"));
        let accent = comparison(&collator, &units("a"), &units("ä"));
        if (case == 0) != case_equal || (accent == 0) != accent_equal {
            return Err(format!("English sensitivity {sensitivity:?} did not preserve its distinct case/accent domain").into());
        }
        sensitivity_results.push(json!({"sensitivity": format!("{sensitivity:?}"), "case_order": case, "accent_order": accent}));
    }
    let bits = DataProvider::<CollationMetadataV1>::load(
        &GeneratedProvider,
        DataRequest {
            id: english.as_borrowed(),
            metadata: Default::default(),
        },
    )?
    .payload
    .get()
    .bits;
    for numeric in [false, true] {
        let mut preferences = preferences(&english)?;
        preferences.numeric_ordering = Some(if numeric {
            CollationNumericOrdering::True
        } else {
            CollationNumericOrdering::False
        });
        let collator = Collator::try_new_unstable(
            &ProbeProvider::new(&english, bits),
            preferences,
            Sensitivity::Variant.options(false),
        )?;
        if comparison(&collator, &units("2"), &units("10")) != if numeric { -1 } else { 1 } {
            return Err("English numeric option did not change 2/10 ordering".into());
        }
    }
    for (case_first, wanted) in [
        (CollationCaseFirst::Lower, -1),
        (CollationCaseFirst::Upper, 1),
    ] {
        let mut preferences = preferences(&english)?;
        preferences.case_first = Some(case_first);
        let collator = Collator::try_new_unstable(
            &ProbeProvider::new(&english, bits),
            preferences,
            Sensitivity::Variant.options(false),
        )?;
        if comparison(&collator, &units("a"), &units("A")) != wanted {
            return Err("English caseFirst option was not reflected in comparison".into());
        }
    }
    let thai = selected_id("th", "")?;
    let thai_default = select(&thai, CollatorOptions::default())?;
    let thai_explicit = select(&thai, Sensitivity::Variant.options(false))?;
    require_equal(
        &thai_default,
        &units("ab"),
        &units("a-b"),
        "Thai metadata-owned punctuation default",
    )?;
    if comparison(&thai_explicit, &units("ab"), &units("a-b")) == 0 {
        return Err("Thai ignorePunctuation false did not restore punctuation distinction".into());
    }
    let mut korean = Vec::new();
    for attributes in ["search", "searchjl"] {
        let id = selected_id("ko", attributes)?;
        let collator = select(&id, Sensitivity::Base.options(false))?;
        canonical_and_utf16(&collator)?;
        consistent_comparator(&collator)?;
        korean.push(json!({
            "attributes": attributes,
            "hangul_vs_choseong": comparison(&collator, &units("가"), &units("ᄀ")),
            "hangul_vs_next_choseong": comparison(&collator, &units("가"), &units("ᄂ")),
            "canonical_hangul_and_comparator_controls": "passed",
            "prefix_matching_support_claimed": false,
        }));
    }
    Ok(json!({
        "German_sort_AE_vs_A_umlaut": sort_order, "German_search_AE_vs_A_umlaut": search_order,
        "German_search_primary_equivalence": true, "missing_profile_retry_rejected": true,
        "English_sensitivities": sensitivity_results, "numeric_and_caseFirst": true,
        "Thai_owned_punctuation_default_and_override": true, "Korean": korean,
    }))
}

fn sha256(path: &Path) -> Result<String, Box<dyn Error>> {
    Ok(format!("{:x}", Sha256::digest(fs::read(path)?)))
}

fn run() -> Result<(), Box<dyn Error>> {
    if std::env::args_os().len() != 1 {
        return Err(
            "usage: collator-admission (no arguments; consumes the sealed sibling export)".into(),
        );
    }
    let package = Path::new(env!("CARGO_MANIFEST_DIR"));
    let root = package.parent().ok_or("admission manifest has no parent")?;
    let receipt_path = root.join("export-receipt.json");
    if sha256(&receipt_path)? != COMPILED_RECEIPT_SHA256
        || fs::read_to_string(&receipt_path)? != EXPORT_RECEIPT
    {
        return Err("export receipt drifted from the build-time generated-source seal".into());
    }
    let output = root.join("admission-receipt.json");
    if output.exists() {
        return Err("refusing to overwrite an existing actual admission receipt".into());
    }
    let export: Value = serde_json::from_str(EXPORT_RECEIPT)?;
    for row in export["generated_files"]
        .as_array()
        .ok_or("export has no generated file rows")?
    {
        let path = root
            .join("generated")
            .join(row["path"].as_str().ok_or("invalid generated path")?);
        if sha256(&path)? != row["sha256"].as_str().ok_or("invalid generated checksum")? {
            return Err("generated source drifted after the actual admission compile".into());
        }
    }
    let identifiers = IterableDataProvider::<CollationMetadataV1>::iter_ids(&GeneratedProvider)?
        .into_iter()
        .map(|id| id.as_borrowed().into_owned())
        .collect::<BTreeSet<_>>();
    let keys = identifiers
        .iter()
        .map(ToString::to_string)
        .collect::<BTreeSet<_>>();
    for row in export["source_metadata"]
        .as_array()
        .ok_or("export has no source metadata")?
    {
        let locale = row["locale"].as_str().ok_or("invalid source locale")?;
        let attributes = row["attributes"]
            .as_str()
            .ok_or("invalid source attributes")?;
        let key = if attributes.is_empty() {
            locale.to_owned()
        } else {
            format!("{locale}/{attributes}")
        };
        if !keys.contains(&key) {
            return Err(
                format!("actual baked export omitted source metadata identity {key}").into(),
            );
        }
    }
    for mandatory in ["de/search", "ko/search", "ko/searchjl"] {
        if !keys.contains(mandatory) {
            return Err(
                format!("actual export omitted mandatory genuine profile {mandatory}").into(),
            );
        }
    }
    let mut profiles = Vec::with_capacity(identifiers.len());
    for id in &identifiers {
        eprintln!("admitting {id}");
        profiles.push(admit_profile(id).map_err(|error| format!("{id}: {error}"))?);
    }
    let focused = focused_controls()?;
    let lock = package.join("Cargo.lock");
    let receipt = json!({
        "schema": "lila-collator-foundation-admission/v1", "status": "completed actual native foundation controls",
        "export_receipt_sha256": COMPILED_RECEIPT_SHA256,
        "admission_binary_sha256": sha256(&std::env::current_exe()?)?, "cargo_lock_sha256": sha256(&lock)?,
        "actual_metadata_identifiers": identifiers.len(), "profiles": profiles,
        "constructors_per_identifier": 49, "option_controls_per_identifier": 48,
        "focused_controls": focused,
        "utf16_policy": "direct locked compare_utf16; maximal ill-formed replacement weighting, valid pairs preserved; no lexical tie-break",
        "available_service_locale_count": null, "product_admission": false,
        "limits": ["finite comparator corpus is a meaningful regression control, not a proof over every string", "no JS/compiler/Engine or full pinned conformance ran"],
    });
    let mut file = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&output)?;
    serde_json::to_writer_pretty(&mut file, &receipt)?;
    writeln!(file)?;
    file.sync_all()?;
    println!(
        "{}",
        serde_json::to_string(&json!({
            "admission_receipt": output, "sha256": sha256(&output)?,
            "actual_metadata_identifiers": identifiers.len(), "constructors": identifiers.len() * 49,
            "available_service_locale_count": null, "product_admission": false,
        }))?
    );
    Ok(())
}

fn main() {
    if let Err(error) = run() {
        eprintln!("collator-admission: {error}");
        std::process::exit(1);
    }
}
