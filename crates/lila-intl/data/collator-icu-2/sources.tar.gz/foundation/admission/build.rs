use sha2::{Digest, Sha256};
use std::fs;
use std::path::{Component, PathBuf};

fn main() {
    let package = PathBuf::from(std::env::var_os("CARGO_MANIFEST_DIR").unwrap());
    let root = package.parent().unwrap();
    let receipt_path = root.join("export-receipt.json");
    let receipt_bytes = fs::read(&receipt_path).expect("run the actual pinned exporter first");
    let receipt: serde_json::Value = serde_json::from_slice(&receipt_bytes).unwrap();
    assert_eq!(receipt["schema"], "lila-collator-foundation-export/v1");
    assert_eq!(
        receipt["input"]["sha256"],
        "e5dae398d77a31ee7fcd86e4b35041cf9bf4643c694794629fc7c5dca76d9c6b"
    );
    println!("cargo:rerun-if-changed={}", receipt_path.display());
    let mut paths = std::collections::BTreeSet::new();
    for row in receipt["generated_files"].as_array().unwrap() {
        let relative = PathBuf::from(row["path"].as_str().unwrap());
        assert!(relative
            .components()
            .all(|part| matches!(part, Component::Normal(_))));
        assert!(paths.insert(relative.clone()));
        let path = root.join("generated").join(relative);
        assert!(!fs::symlink_metadata(&path)
            .unwrap()
            .file_type()
            .is_symlink());
        let bytes = fs::read(&path).unwrap();
        assert_eq!(bytes.len() as u64, row["bytes"].as_u64().unwrap());
        assert_eq!(
            format!("{:x}", Sha256::digest(&bytes)),
            row["sha256"].as_str().unwrap()
        );
        println!("cargo:rerun-if-changed={}", path.display());
    }
    assert!(paths.contains(&PathBuf::from("mod.rs")));
    assert_eq!(receipt["statistics"].as_array().unwrap().len(), 9);
    println!(
        "cargo:rustc-env=COLLATOR_EXPORT_RECEIPT_SHA256={:x}",
        Sha256::digest(receipt_bytes)
    );
}
