# scriptw

Scriptw is an experimental JavaScript-to-WebAssembly compiler written in Rust.
Compile JavaScript and its builtins to Wasm, run it through Wasmtime, or embed
it in a Rust application. WebAssembly is the sole output target.

## Benchmarks vs V8

Measured on 2026-10-22 at compiler source `b9ecfe64b`. Medians of seven samples;
all workload outputs checked against Node. V8 is faster in these measured cases.

| Measurement | scriptw / Wasmtime | Node / V8 |
| --- | ---: | ---: |
| Cold start | 1,084.901 ms | 32.679 ms |
| Cached start | 801.288 ms | 37.437 ms |
| Execute: 10,000 integer steps | 6.505 ms | 2.493 ms |
| Execute: 500 objects | 15.040 ms | 0.064 ms |
| Execute: 8,192 retained objects | 1,287.305 ms | 3.357 ms |

| Peak process RSS | scriptw / Wasmtime | Node / V8 |
| --- | ---: | ---: |
| Cold start (median) | 383.04 MiB | 27.12 MiB |
| Cached start (median) | 349.78 MiB | 27.12 MiB |
| Retained-object run (one process) | 392.80 MiB | 52.88 MiB |

AMD EPYC 9V74; 32 GiB memory limit; four-CPU cloud quota. Both runtimes pinned
to one CPU. Wasmtime 47.0.0; Node 24.19.0 / V8 13.6.233.17-node.51.

Cold and cached starts use fresh processes with empty or populated application
caches; the shared runtime is precompiled and the OS cache is not flushed.
Execution reuses compiled code with a fresh Wasmtime Store or V8 context after
ten warmups. Scriptw initializes its Wasm realm and builtins inside execution.
Process RSS includes host/runtime overhead; the retained-object peak also
includes compilation and warmups. It is not JavaScript heap usage.
The Rust compiler uses `release`; generated program modules use Fast compilation.
NativeHost and Portable have separate matching optimized runtime images.
Portable native-image storage is compressed, and decoded load buffers are
transient. The measured CLI is 277.10 MiB, with Rust debug information stripped.
These small workloads are a local baseline; short timing differences overlap
across paired controls.
[Methodology, raw evidence and reproduction](docs/rust-rewrite/v8-baseline.md).
The [performance tooling](docs/rust-rewrite/v8-baseline.md#current-performance-and-memory-tooling)
also records memory, runtime phases and code size, with selected-workload and
before/after comparisons. A selected three-sample integer run takes about three
seconds with the checked execution cache already populated.
[Prioritized performance backlog](docs/performance-hills.md).
[Bounded native verification workflow](docs/rust-rewrite/batch-workflow.md#optional-sequential-cli-chunks).

## Tests

**Verification, 2026-10-21:** the compiler repair makes **12 of the original 16
failures pass**. A separate recheck of the remaining four still gives **0 passed,
4 failed**; ten nearby original-test controls pass. These failures remain open:

| Remaining case | Failed executions | Why it fails | Upstream tracking |
| --- | ---: | --- | --- |
| Implicit `arguments` binding | 1 | The test expects the arguments object to survive; the current specification replaces it with the block function. | [Test262 #5113](https://github.com/tc39/test262/issues/5113), [fix PR #5112](https://github.com/tc39/test262/pull/5112): open, unmerged |
| Johnston/Honolulu timezone identity | 2 | The test expects Johnston (UM) and Honolulu (US) to share an identity; country-preserving rules and historical-zone handling disagree. | [ECMA-402 #806](https://github.com/tc39/ecma402/issues/806): open, blocked; related Johnston discussion |
| Labelled block functions | 1 | Function visibility under block labels differs between the pinned specification and deployed engines. | No exact issue found; related [Annex B tracker #1595](https://github.com/tc39/ecma262/issues/1595) is open |

**All four remain counted as failures.** Upstream tracking does not change their results.
[Exact cases and verification](docs/rust-rewrite/failed-case-replay-20261021.md#remaining-four-recheck)
· [Upstream status and related issues](test262/errata/proposals/upstream-status-20261021.md).
The **2026-10-22 hot-read checkpoint** (`b9ecfe64b`) passes **3,742 native
tests** across eight affected targets and seventeen compiled semantic families.
This combines seven passing runtime targets with the complete structural target
rerun after correcting a stale trim-visibility assertion; production code is
unchanged by that repair. The previous numeric/collection checkpoint's
**3,235-case Test262 replay gave 3,231 passed / 4 failed**, with zero crashes or
unimplemented cases. A fresh full-suite run is the next acceptance step.
[Source-bound evidence](docs/rust-rewrite/performance-hot-reads-20261022.json)
· [Measured gains and limits](docs/rust-rewrite/v8-baseline.md#hot-read-checkpoint--published-2026-10-22).
Earlier wider native and Test262 results remain bound to their original sources.
These affected checks do not replace a fresh full-suite campaign.
The chart below reconciles the complete 2026-10-20 baseline with the exact
original-failure replay and an audited standalone Wasm scope split. A fresh full
run of the repaired compiler is still pending.

<!-- scriptw-test-graph:start -->
![Test262 checkpoints: 102,561 passing in scope, 4 failing, 0 not implemented, 429 out of standalone Wasm scope](docs/rust-rewrite/assets/test262-status.svg)

**Reconciled checkpoints, 2026-10-21:** 102,994 mode-specific
executions at pin `6a4268a93`. This combines the complete **2026-10-20**
baseline with the exact original-failure replay: **12 repaired, 4 still failing**.
The other baseline successes have not had a fresh full rerun on the repaired compiler.

Blue is an audited **429-execution subset** focused on dynamic
`eval` / Function source compilation outside the standalone Wasm product promise.
These cases passed through the native host; their historical results remain intact.
Ordinary API properties and `call` / `apply` / `bind` stay in the measured categories.
The four bars partition the original 102,994 executions; scope is not a failure fix.
[Chart inputs and exact scope inventory](docs/rust-rewrite/test262-chart-reconciliation-20261021.json) ·
[Original complete baseline](test262/snapshots/published-status-wasm-aot.json) ·
[Failure replay](docs/rust-rewrite/failed-case-replay-20261021.md) ·
[Scope policy](docs/rust-rewrite/runtime-requirements.md#out-of-scope-tests).
<!-- scriptw-test-graph:end -->

## Caveats

- **Wasm is the sole compilation target.** C/native output and a REPL are outside scope.
- **Conformance is incomplete.** The chart identifies its measured compiler
  and complete pinned suite. [Current verification and remaining work](docs/rust-rewrite/current-inventory.md).
  [Verified repairs and original-test conflicts](docs/rust-rewrite/failed-case-replay-20261021.md).
- **Dynamic code generation is limited.** Prepared `eval` / `new Function`
  sources can run; the native host can compile additional supported sources.
  Standalone Wasm does not contain a parser or provide general runtime `eval`.
  Cases requiring a parser or VM inside emitted Wasm are outside product scope.
- **Host APIs are limited.** Scriptw is not a Node.js or browser replacement.
  Three synchronous React SSR cases work; the public browser/streaming entry
  fails. [React probe and limitations](docs/rust-rewrite/react-ssr.md).

## Wasm requirements and support

The backend requires:

- Wasm GC structs and arrays;
- reference types and typed function references;
- exception handling and tail calls;
- multi-memory and threads/shared memory.

The host must also provide the matching Scriptw runtime, `scriptw_host` imports
and Intl data. The native integration selects Wasmtime's copying collector.

| Runtime / host | Scriptw support |
| --- | --- |
| Vendored Wasmtime 47.0.0 through the Scriptw CLI or Rust API | Tested execution path |
| Browsers, Node's Wasm API and other engines | Integration and compatibility unverified; feature support alone is insufficient |
| A bare WASI host | Does not supply Scriptw's JavaScript runtime or host bindings |

[Runtime requirements and dynamic-source details](docs/rust-rewrite/runtime-requirements.md).

## Try it

Requires Rust 1.94 or newer. From a checkout:

```sh
cargo build --locked --release -p scriptw-cli --bin scriptw
printf 'print("Hello Wasm");\n' > hello.js
./target/release/scriptw run hello.js
SCRIPTW_WASM_DUMP=hello.wasm ./target/release/scriptw build wasm hello.js
```

<details>
<summary>Detailed published conformance record</summary>

## Current Status
<!-- scriptw-status:start -->
Rust rewrite status must be read in layers, not one vanity number:
- Fake wasm-safe Test262 subset: `187/187` green
- Fake full Rust rewrite suite: `191/191` green
- Pinned real Test262 baseline (`wasm-aot`, refreshed `2026-10-23`): `102990/102994` not green (`100.0%`)
- Real Test262 goal: Success=102990/102994 (100.0%); burn down NotImplemented=0, Crash=0, Bug=4 to zero
- Pinned revisions: `ecma262=5345883164f463e87f8b40aca4956157ecba8783` `test262=6a4268a9354a545d41c3b62efebc478ed8c521f4`
- Compiler build fingerprint: `7337ccbc2834d0d17902382431789227b6dddf8fda40842bf19c4243161d56f9`; executing image SHA-256: `32ee09a9a33daaf7d27fcb1b649db7223fcbd3ce00f0943cf19cce5ef886101b`
- Current real outcomes: `Success=102990`, `NotImplemented=0`, `Crash=0`, `Bug=4`
- Biggest current real failing kinds: `Runtime=4`
- Biggest current real failing origins: `unknown=4`
- Worst current real matrix targets: `intl402/Temporal/ZonedDateTime: 248/250 passed`, `annexB: 1376/1377 passed`, `staging/sm/lexical-environment: 38/39 passed`
- Published status artifacts: `/workspace/scriptw-full-suite-20261022/test262/snapshots/scriptw-hot-reads-b9ecfe64b-20261022-aggregate-13327628081868727304.json` and `/workspace/scriptw-full-suite-20261022/test262/snapshots/scriptw-hot-reads-b9ecfe64b-20261022-aggregate-13327628081868727304.txt`

As of `2026-10-23`, Rust Wasm-AOT path is at 100% of repo fake coverage, not 100% ECMAScript. Project is still off literal 100% until full pinned real Test262 run is green for Rust path.

Status refresh commands:
- `cargo test -p scriptw-engine --quiet`
- `cargo test -p scriptw-cli --quiet`
- `./target/debug/scriptw test262 run language/wasm/pass --suite-root crates/scriptw-test262/tests/fixtures/fake_test262/vendor/test262 --execution-backend wasm`
- `./target/debug/scriptw test262 run --suite-root crates/scriptw-test262/tests/fixtures/fake_test262/vendor/test262`
- `./scripts/publish-real-status-low-ram.sh wasm-aot codex-published-real`

When counts move, update this block in same change. Do not claim full Test262 `100%` from fake-suite numbers.
<!-- scriptw-status:end -->

</details>

## Documentation

[Project inventory](docs/rust-rewrite/current-inventory.md) ·
[Rust architecture and development](docs/rust-rewrite/README.md) ·
[Conformance commands and shard syntax](docs/rust-rewrite/batch-workflow.md#full-test262-measurement-and-publication) ·
[Contributing](CONTRIBUTING.md) ·
[Development history](DEVELOPMENT_HISTORY.md).
