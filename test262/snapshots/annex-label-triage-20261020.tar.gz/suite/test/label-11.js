// Copyright (C) 2024 Mozilla Corporation. All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.

/*---
flags:
  - noStrict
description: |
  pending
esid: pending
---*/

function expectSyntaxError(str) {
  assert.throws(SyntaxError, function() {
    eval(str);
  });

  assert.throws(SyntaxError, function() {
    eval('"use strict";' + str);
  });
}

function expectSloppyPass(str) {
  eval(str);

  assert.throws(SyntaxError, function() {
    eval('"use strict";' + str);
  });
}

expectSyntaxError(`for (;;) l: function f6() {}`);
