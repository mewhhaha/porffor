// Copyright (C) 2024 Mozilla Corporation. All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.

/*---
flags:
  - noStrict
description: |
  pending
esid: pending
---*/

function expectSyntaxError(str) {
  assert.throws(SyntaxError, function() {
    eval(str);
  });

  assert.throws(SyntaxError, function() {
    eval('"use strict";' + str);
  });
}

function expectSloppyPass(str) {
  eval(str);

  assert.throws(SyntaxError, function() {
    eval('"use strict";' + str);
  });
}

expectSloppyPass(`switch (1) { case 1: assert.sameValue(f8(), 'f8'); case 2: l: function f8() { return 'f8'; } } assert.sameValue(f8(), 'f8');`);
