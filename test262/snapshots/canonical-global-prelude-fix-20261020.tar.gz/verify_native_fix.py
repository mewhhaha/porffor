#!/usr/bin/env python3
"""Build the isolated candidate and replay original failures without editing main."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import time
import traceback

OUT = Path(__file__).resolve().parent
ROOT = OUT / 'candidate'
FROZEN = OUT.parent / 'scriptw-test262-refresh-20261020-run1'
SUITE = Path('/workspace/lila-tooling-next/test262/vendor/test262')
RECEIPT = OUT / 'native-fix-verification.json'
STATE = {'schema': 'scriptw-isolated-global-prelude-fix-native-v1', 'complete': False,
         'status': 'starting', 'checks': [], 'baseline_source_changed': False,
         'baseline_counts_changed': False, 'published_to_main': False}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save():
    STATE['updated_utc'] = time.strftime('%FT%TZ', time.gmtime())
    pending = RECEIPT.with_suffix('.pending')
    pending.write_text(json.dumps(STATE, indent=2) + '\n')
    pending.replace(RECEIPT)


def run(label, command, timeout):
    STATE['status'] = label
    save()
    print(label, flush=True)
    stdout, stderr = OUT / (label + '.stdout'), OUT / (label + '.stderr')
    started = time.monotonic()
    with stdout.open('xb') as output, stderr.open('xb') as errors:
        result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=errors, timeout=timeout)
    STATE['checks'].append({'label': label, 'command': command, 'exit_code': result.returncode,
                            'seconds': round(time.monotonic() - started, 3),
                            'stdout': stdout.name, 'stdout_sha256': sha(stdout),
                            'stderr': stderr.name, 'stderr_sha256': sha(stderr)})
    save()
    if result.returncode:
        raise RuntimeError(f'{label} exited {result.returncode}; original logs retained')
    return stdout


def main():
    assert not RECEIPT.exists(), 'review existing verification before starting another run'
    preparation = json.loads((OUT / 'fix-preparation.json').read_text())
    assert preparation['focused_verification']['passed'] == 6
    assert preparation['complete_ir_integration']['passed'] == 742
    for name, expected in preparation['candidate_sha256'].items():
        assert sha(ROOT / name) == expected, name
    STATE['candidate_rust_source_sha256'] = preparation['candidate_sha256']
    STATE['candidate_manifest_adjustment'] = preparation['candidate_manifest_adjustment']
    STATE['prior_ir_integration'] = preparation['complete_ir_integration']
    STATE['frozen_baseline_binary_sha256'] = sha(FROZEN / 'scriptw')
    original_ids = (OUT / 'executions.txt').read_text().splitlines()
    assert len(original_ids) == len(set(original_ids)) == 6
    controls = [mode + ':' + name for name in ['built-ins/Number/parseInt.js',
                'built-ins/Number/parseFloat.js'] for mode in ['sloppy-script', 'strict-script']]
    ids = original_ids + controls
    inventory = OUT / 'native-repair-executions.txt'
    inventory.write_text('\n'.join(ids) + '\n')
    STATE['original_failure_ids'] = original_ids
    STATE['retained_control_ids'] = controls
    dependencies = run('candidate-product-dependencies',
        ['cargo', 'tree', '--locked', '--offline', '-p', 'scriptw-cli', '-e', 'normal'], 600)
    assert not re.search(r'\b(?:boa_engine|scriptw-spec-exec) v', dependencies.read_text()), \
        'ordinary product dependencies must exclude the interpreter oracle'
    artifacts = run('candidate-product-build',
        ['cargo', 'build', '--release', '--locked', '--offline', '-p', 'scriptw-cli',
         '--bin', 'scriptw', '--jobs', '1', '--message-format=json-render-diagnostics'], 14400)
    executable = None
    for line in artifacts.read_text().splitlines():
        try:
            record = json.loads(line)
        except ValueError:
            continue
        if (record.get('reason') == 'compiler-artifact' and record.get('executable')
                and record.get('target', {}).get('name') == 'scriptw'):
            executable = Path(record['executable'])
    assert executable is not None and executable.is_file(), 'build did not produce the actual CLI'
    binary = OUT / 'candidate-scriptw'
    assert not binary.exists(), 'do not replace a previously verified executable'
    shutil.copy2(executable, binary)
    identity_file = run('candidate-compiler-identity',
                        [str(binary), '--jobs', '1', 'compiler-identity'], 120)
    identity = json.loads(identity_file.read_text())
    assert identity['executable_sha256'] == sha(binary)
    assert identity['source_revision']['kind'] == 'unversioned-archive'
    STATE['compiler_identity'] = identity
    snapshots = OUT / 'native-repair-snapshots'
    assert not snapshots.exists(), 'native replay requires a fresh family'
    run('candidate-original-six-plus-controls', [str(binary), '--jobs', '1', 'test262',
        'run-list', str(inventory), '--suite-root', str(SUITE), '--snapshot-dir', str(snapshots),
        '--snapshot-name', 'canonical-global-prelude-fix-20261020', '--execution-backend',
        'wasm-aot', '--threads', '1', '--timeout-ms', '60000', '--reuse-case-workers'], 1200)
    native_files = list(snapshots.glob('*.json'))
    assert len(native_files) == 1, 'expected one exact execution-list snapshot'
    native = json.loads(native_files[0].read_text())
    assert native['total'] == native['passed'] == len(ids) == 10
    assert not native['failures']
    assert set(native['completed_test_ids']) == set(ids)
    assert native['compiler_identity'] == identity
    assert STATE['frozen_baseline_binary_sha256'] == sha(FROZEN / 'scriptw')
    STATE.update(complete=True, status='verified', original_six_repaired=6,
                 native_executions_passed=10, native_executions_failed=0,
                 native_snapshot=str(native_files[0]), native_snapshot_sha256=sha(native_files[0]),
                 full_fixed_compiler_test262_acceptance=False)
    save()
    print('Verified all six original Wasm-AOT failures plus four retained controls.', flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception:
        STATE['status'] = 'failed; original evidence retained'
        STATE['error'] = traceback.format_exc()
        save()
        raise
