const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const original = '/workspace/lila-tooling-next/test262/vendor/test262';
const amended = path.join(__dirname, 'prepared/suite');
const tests = [
  'annexB/language/function-code/block-decl-func-skip-arguments.js',
  'staging/sm/lexical-environment/block-scoped-functions-annex-b-arguments.js',
  'staging/sm/regress/regress-602621.js',
];
const suites = [original, amended].map((suite, index) => {
  const harness = ['sta.js', 'assert.js'].map(name =>
    fs.readFileSync(path.join(suite, 'harness', name), 'utf8')).join('\n');
  const cases = tests.map(file => {
    try {
      vm.runInNewContext(harness + '\n' + fs.readFileSync(path.join(suite, 'test', file), 'utf8'),
        {}, { filename: file, timeout: 60000 });
      return { file, outcome: 'Success' };
    } catch (error) {
      return { file, outcome: 'Failure', detail: String(error) };
    }
  });
  return { suite: index ? 'explicitly-amended' : 'unmodified',
    passed: cases.filter(row => row.outcome === 'Success').length, cases };
});
console.log(JSON.stringify({ node: process.version, v8: process.versions.v8, suites }, null, 2));
if (suites[0].passed !== 2 || suites[0].cases[0].outcome !== 'Failure' || suites[1].passed !== 3)
  process.exitCode = 1;
