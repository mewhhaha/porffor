#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import subprocess
import time
import traceback

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/lila-tooling-next')
FIX = OUT.parent / 'scriptw-object-global-triage-20261020-run1'
SUITE = ROOT / 'test262/vendor/test262'
STATE = {'schema': 'scriptw-reviewed-test262-errata-validation-v1', 'complete': False,
         'checks': [], 'stock_suite_changed': False, 'stock_results_changed': False,
         'full_amended_suite_verified': False, 'unmodified_upstream_all_green': False}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save():
    (OUT / 'verification.json').write_text(json.dumps(STATE, indent=2) + '\n')


def run(label, command, expected=0, timeout=1200):
    STATE['status'] = label
    save()
    print(label, flush=True)
    stdout, stderr = OUT / (label + '.stdout'), OUT / (label + '.stderr')
    start = time.monotonic()
    with stdout.open('xb') as output, stderr.open('xb') as errors:
        result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=errors, timeout=timeout)
    STATE['checks'].append({'label': label, 'command': command, 'exit_code': result.returncode,
                            'seconds': round(time.monotonic() - start, 3),
                            'stdout': stdout.name, 'stdout_sha256': sha(stdout),
                            'stderr': stderr.name, 'stderr_sha256': sha(stderr)})
    save()
    assert result.returncode == expected, (label, result.returncode, expected)
    return stdout


def native(label, suite, expected):
    snapshots = OUT / (label + '-snapshots')
    run(label, [str(FIX / 'candidate-scriptw'), '--jobs', '1', 'test262', 'run-list',
        str(OUT / 'executions.txt'), '--suite-root', str(suite), '--snapshot-dir', str(snapshots),
        '--snapshot-name', 'reviewed-errata-' + label + '-20261020', '--execution-backend',
        'wasm-aot', '--threads', '1', '--timeout-ms', '60000', '--reuse-case-workers'], expected)
    files = list(snapshots.glob('*.json'))
    assert len(files) == 1
    result = json.loads(files[0].read_text())
    ids = (OUT / 'executions.txt').read_text().splitlines()
    assert result['total'] == len(ids) == 27
    assert set(result['completed_test_ids']) == set(ids)
    assert result['compiler_identity'] == STATE['compiler_identity']
    return {'total': result['total'], 'passed': result['passed'],
            'counts_per_outcome': result['counts_per_outcome'], 'failures': result['failures'],
            'native_snapshot': str(files[0].relative_to(OUT)), 'sha256': sha(files[0])}


def main():
    assert not (OUT / 'verification.json').exists()
    identity = json.loads((FIX / 'native-fix-verification.json').read_text())['compiler_identity']
    assert sha(FIX / 'candidate-scriptw') == identity['executable_sha256']
    STATE['compiler_identity'] = identity
    run('errata-tooling-tests', ['python3', '-B', '-m', 'unittest', 'discover', '-s',
        str(OUT / 'files/scripts/tests'), '-p', 'test_prepare_test262_errata.py', '-v'])
    prepared = run('prepare-amended-suite', ['python3', '-B',
        str(OUT / 'files/scripts/prepare_test262_errata.py'), '--suite', str(SUITE), '--errata',
        str(OUT / 'files/test262/errata'), '--pins', str(ROOT / 'crates/scriptw-test262/src/source-pins.json'),
        '--output', str(OUT / 'prepared')])
    STATE['preparation'] = json.loads(prepared.read_text())
    assert STATE['preparation']['complete'] is True
    stock = native('stock', SUITE, 1)
    disputed = {'sloppy-script:annexB/language/function-code/block-decl-func-skip-arguments.js',
                'sloppy-script:intl402/Temporal/ZonedDateTime/links.js',
                'strict-script:intl402/Temporal/ZonedDateTime/links.js'}
    assert stock['passed'] == 24 and stock['counts_per_outcome'] == {
        'Success': 24, 'Bug': 3, 'Crash': 0, 'NotImplemented': 0}
    assert {failure['test_id'] for failure in stock['failures']} == disputed
    STATE['unmodified_fixture_replay'] = stock
    save()
    corrected = native('amended', OUT / 'prepared/suite', 0)
    assert corrected['passed'] == 27 and not corrected['failures']
    assert corrected['counts_per_outcome'] == {'Success': 27, 'Bug': 0, 'Crash': 0, 'NotImplemented': 0}
    STATE['corrected_fixture_replay'] = corrected
    node = run('v8-annex-comparison', ['node', str(OUT / 'v8-annex-comparison.cjs')])
    STATE['v8_annex_comparison'] = json.loads(node.read_text())
    assert [row['passed'] for row in STATE['v8_annex_comparison']['suites']] == [2, 3]
    run('stock-source-pins-still-verified', ['python3', '-B', 'scripts/check_conformance_source_pins.py'])
    assert sha(FIX / 'candidate-scriptw') == identity['executable_sha256']
    STATE.update(complete=True, status='verified', disputed_executions_corrected=3,
                 corrected_executions_passed=27, retained_controls_passed=24)
    save()
    print('Verified 27/27 amended executions; original 24/27 replay and all three failures retained.', flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception:
        STATE['status'] = 'failed; original logs retained'
        STATE['error'] = traceback.format_exc()
        save()
        raise
