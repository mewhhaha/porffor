const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const suite = '/workspace/lila-tooling-next/test262/vendor/test262';
const ids = fs.readFileSync(path.join(__dirname, 'executions.txt'), 'utf8').trim().split('\n');
const harness = ['sta.js', 'assert.js'].map(name => fs.readFileSync(path.join(suite, 'harness', name), 'utf8')).join('\n');
const cases = ids.map(id => {
  const file = id.slice(id.indexOf(':') + 1);
  try {
    vm.runInNewContext(harness + '\n' + fs.readFileSync(path.join(suite, 'test', file), 'utf8'), {}, { filename: file, timeout: 60000 });
    return { id, outcome: 'Success' };
  } catch (error) {
    return { id, outcome: 'Failure', detail: String(error) };
  }
});
console.log(JSON.stringify({ node: process.version, v8: process.versions.v8, cases }, null, 2));
if (cases.filter(test => test.outcome === 'Success').length !== 2 || cases[0].outcome !== 'Failure') process.exitCode = 1;
