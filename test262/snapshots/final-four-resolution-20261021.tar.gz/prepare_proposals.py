import difflib,hashlib,json,shutil,urllib.request
from pathlib import Path
root=Path.cwd(); out=Path('/workspace/porffor/target/scriptw-final-four-resolution-20261021-run1')
proposals=root/'test262/errata/proposals'; proposals.mkdir(exist_ok=False)
check=out/'patch-checks'; check.mkdir(exist_ok=False)
def sha(data):return hashlib.sha256(data).hexdigest()
authorities={}
for name,revision,path in [('ecma262-current','4feb0272b799ea795c5eadee9b482aea0c10ce45','spec.html')]:
 url=f'https://raw.githubusercontent.com/tc39/ecma262/{revision}/{path}'
 with urllib.request.urlopen(url,timeout=30) as response:data=response.read()
 (out/(name+'.html')).write_bytes(data)
 authorities[name]={'revision':revision,'url':url,'sha256':sha(data)}
base262=Path('/workspace/porffor/target/scriptw-test262-refresh-20261020-run1/ecma262-pinned-spec.html').read_bytes()
base402=Path('/workspace/porffor/target/scriptw-timezone-links-triage-20261020-run1/ecma402-locales-currencies-tz.html').read_bytes()
assert sha(base262)=='5194892f5a5f595962929b7099e028b1db44c8b68c44f4ce20f77b266507d57d'
assert sha(base402)=='96162f26bf0ff1478f7359cf8d637ea954da8e633e433204e2d67fb4e7411ebd'
entries=[]
def add(name,project,relative,original,replacement,description):
 patch=''.join(difflib.unified_diff(original.decode().splitlines(keepends=True),replacement.decode().splitlines(keepends=True),fromfile='a/'+relative,tofile='b/'+relative))
 assert patch
 p=proposals/(name+'.patch'); p.write_text(patch)
 dest=check/project/relative; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(original)
 expected=out/'expected-patched'/project/relative; expected.parent.mkdir(parents=True,exist_ok=True); expected.write_bytes(replacement)
 entries.append({'id':name,'project':project,'target':relative,'patch':p.relative_to(proposals).as_posix(),'patch_sha256':sha(p.read_bytes()),'base_sha256':sha(original),'proposed_sha256':sha(replacement),'status':'draft-not-submitted-not-adopted','description':description})
for ident,p in [('test262-arguments','annexB/language/function-code/block-decl-func-skip-arguments.js'),('test262-johnston','intl402/Temporal/ZonedDateTime/links.js')]:
 original=(root/'test262/vendor/test262/test'/p).read_bytes()
 replacement=(root/'test262/errata/replacements/test'/p).read_bytes()
 add(ident,'test262','test/'+p,original,replacement,'Proposed fixture correction; existing explicit erratum, not applied to the vendor suite.')
text=base262.decode()
for op,anchor in [('LexicallyDeclaredNames','sec-static-semantics-lexicallydeclarednames'),('LexicallyScopedDeclarations','sec-static-semantics-lexicallyscopeddeclarations')]:
 begin=text.index('<emu-clause id="'+anchor+'"'); end=text.index('</emu-clause>',begin)
 section=text[begin:end]
 old='<emu-grammar>LabelledItem : Statement</emu-grammar>\n      <emu-alg>\n        1. Return a new empty List.'
 assert section.count(old)==1
 new='<emu-grammar>LabelledItem : Statement</emu-grammar>\n      <emu-alg>\n        1. If |Statement| is <emu-grammar>Statement : LabelledStatement</emu-grammar>, return the '+op+' of |Statement|.\n        1. Return a new empty List.'
 changed=section.replace(old,new)
 text=text[:begin]+changed+text[end:]
old='that is directly contained in the |StatementList| of any |Block|, |CaseClause|, or |DefaultClause| _x_ such that'
new='that is either directly contained in the |StatementList| of any |Block|, |CaseClause|, or |DefaultClause| _x_, or is the terminal declaration of a sequence of one or more |LabelledStatement| Parse Nodes whose outermost |LabelledStatement| is directly contained in that |StatementList|, such that'
assert text.count(old)==3
text=text.replace(old,new)
add('ecma262-labelled-functions','ecma262','spec.html',base262,text.encode(),'Normative proposal: recursive labelled lexical collection and labelled Annex B copy eligibility. Changes the pinned contract; requires standards review before compiler adoption.')
text=base402.decode()
start=text.index('                  1. Let _backzone_ be *undefined*.')
last='                  1. Set _primary_ to _backzone_.'
end=text.index(last,start)+len(last)
section=text[start:end]
replacement='''                  1. If file <code>backzone</code> of the IANA Time Zone Database contains a Zone whose name is _identifier_, then
                    1. Set _primary_ to _identifier_.
                  1. Else,
'''+ '\n'.join('  '+line for line in section.splitlines())
text=text[:start]+replacement+text[end:]
add('ecma402-backzone-zone','ecma402','spec/locales-currencies-tz.html',base402,text.encode(),'Normative proposal: explicitly retain a cross-country historical Zone as its own primary when the multi-country-row branch has no alias-only topology. The country-preservation requirement remains.')
manifest={'schema':'scriptw-conformance-resolution-proposals-v1','status':'draft-not-submitted-not-adopted','applied_to_product':False,'stock_suite_changed':False,'source_pins_changed':False,'base_source_pins':json.loads((root/'crates/scriptw-test262/src/source-pins.json').read_text()),'ecma402_observation':{'revision':'730ca2b88c305862db7be2f83c510dcca33ab48c','sha256':sha(base402),'url':'https://raw.githubusercontent.com/tc39/ecma402/730ca2b88c305862db7be2f83c510dcca33ab48c/spec/locales-currencies-tz.html'},'current_ecma262_observation':authorities['ecma262-current'],'patches':entries}
(proposals/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'patches':[e['id'] for e in entries],'source_pins_changed':False},indent=2))
