import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd(); out=Path('/workspace/porffor/target/scriptw-final-four-resolution-20261021-run1')
proposals=root/'test262/errata/proposals'; manifest=json.loads((proposals/'manifest.json').read_text())
records=[]
for entry in manifest['patches']:
 patch=proposals/entry['patch']; work=out/'patch-checks'/entry['project']; target=work/entry['target']
 assert hashlib.sha256(patch.read_bytes()).hexdigest()==entry['patch_sha256']
 assert hashlib.sha256(target.read_bytes()).hexdigest()==entry['base_sha256']
 command=['patch','--batch','--fuzz=0','-p1','-d',str(work),'-i',str(patch)]
 dry=subprocess.run([command[0],'--dry-run',*command[1:]],capture_output=True,text=True)
 assert dry.returncode==0, dry.stderr+dry.stdout
 applied=subprocess.run(command,capture_output=True,text=True)
 assert applied.returncode==0, applied.stderr+applied.stdout
 expected=(out/'expected-patched'/entry['project']/entry['target']).read_bytes()
 assert target.read_bytes()==expected
 assert hashlib.sha256(target.read_bytes()).hexdigest()==entry['proposed_sha256']
 if entry['project']=='test262':
  rel=Path(entry['target']).relative_to('test')
  assert target.read_bytes()==(root/'test262/errata/replacements/test'/rel).read_bytes()
 records.append({'id':entry['id'],'dry_run_exit_code':dry.returncode,'apply_exit_code':applied.returncode,'exact_expected_output':True,'dry_run_stdout':dry.stdout,'apply_stdout':applied.stdout,'command':command})
(out/'patch-validation.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'patches_checked':len(records),'all_exact':True,'vendor_modified':False},indent=2))
