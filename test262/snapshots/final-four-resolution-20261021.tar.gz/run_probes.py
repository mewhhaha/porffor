import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path.cwd()
out=Path('/workspace/porffor/target/scriptw-final-four-resolution-20261021-run1')
observations=[]
node_code='globalThis.print = console.log; require("node:vm").runInThisContext(require("node:fs").readFileSync(process.argv[1], "utf8"), {filename: process.argv[1]});'
pm_code='import pythonmonkey as pm,sys; from pathlib import Path; pm.eval("(fn) => {globalThis.print = fn}")(lambda value: print(value)); pm.eval(Path(sys.argv[1]).read_text())'
qjs_code='import quickjs,sys; from pathlib import Path; ctx=quickjs.Context(); ctx.add_callable("print",lambda value: print(value)); ctx.eval(Path(sys.argv[1]).read_text())'
engines={
 'scriptw':['python3','-B','scripts/limited_verification.py','--cloud','--','/workspace/porffor/target/scriptw-object-global-triage-20261020-run1/candidate-scriptw','--jobs','1','run'],
 'v8':['node','-e',node_code],
 'spidermonkey':['/workspace/.scriptw-tools/annex-oracles/bin/python','-c',pm_code],
 'quickjs':['/workspace/.scriptw-tools/annex-oracles/bin/python','-c',qjs_code],
}
logs=out/'probe-logs'; logs.mkdir(exist_ok=False)
for probe in sorted((root/'test262/errata/reproducers').glob('*.js')):
 for engine,prefix in engines.items():
  command=[*prefix,str(probe)]
  started=time.monotonic()
  result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90,env=os.environ | {'TMPDIR':'/tmp'})
  basename=probe.stem+'-'+engine
  (logs/(basename+'.stdout')).write_bytes(result.stdout)
  (logs/(basename+'.stderr')).write_bytes(result.stderr)
  row={'probe':probe.name,'probe_sha256':hashlib.sha256(probe.read_bytes()).hexdigest(),'engine':engine,'command':command,'exit_code':result.returncode,'elapsed_seconds':round(time.monotonic()-started,3),'stdout':str((logs/(basename+'.stdout')).relative_to(out)),'stderr':str((logs/(basename+'.stderr')).relative_to(out))}
  try: row['observation']=json.loads(result.stdout)
  except (ValueError,UnicodeDecodeError): row['observation']=None
  observations.append(row)
  (out/'probe-observations.json').write_text(json.dumps(observations,indent=2)+'\n')
  print(json.dumps({k:row[k] for k in ('probe','engine','exit_code','observation')}),flush=True)
