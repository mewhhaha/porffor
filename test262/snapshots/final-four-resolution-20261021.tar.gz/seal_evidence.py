import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path.cwd(); out=Path('/workspace/porffor/target/scriptw-final-four-resolution-20261021-run1')
def sha(data):return hashlib.sha256(data).hexdigest()
prior=json.loads((root/'docs/rust-rewrite/failed-case-replay-20261021.json').read_text())
proposals=json.loads((root/'test262/errata/proposals/manifest.json').read_text())
results={}
commands=json.loads((out/'native-commands.json').read_text())
for command in commands:
 name=command['name']; paths=list((out/(name+'-snapshots')).glob('*.json')); assert len(paths)==1
 p=paths[0]; snapshot=json.loads(p.read_text())
 assert snapshot['compiler_identity']==prior['compiler_identity']
 filename='original-and-controls.txt' if name=='original-and-controls' else 'original-four.txt'
 ids=(out/filename).read_text().splitlines()
 assert len(ids)==len(set(ids))==snapshot['total']
 assert command['exit_code']==1
 results[name]={'total':snapshot['total'],'passed':snapshot['passed'],'counts_per_outcome':snapshot['counts_per_outcome'],'execution_ids':ids,'failures':snapshot['failures'],'exit_code':command['exit_code'],'elapsed_seconds':command['elapsed_seconds'],'native_snapshot':str(p.relative_to(out)),'native_snapshot_sha256':sha(p.read_bytes())}
assert results['original-and-controls']['counts_per_outcome']=={'Bug':4,'Crash':0,'NotImplemented':0,'Success':10}
assert results['proposed-test-corrections']['counts_per_outcome']=={'Bug':1,'Crash':0,'NotImplemented':0,'Success':3}
assert results['proposed-test-corrections']['failures'][0]['test_id']=='sloppy-script:staging/sm/lexical-environment/block-scoped-functions-annex-b-label.js'
for p,expected in prior['canonical_baseline_unchanged'].items():assert sha((root/p).read_bytes())==expected
receipt=json.loads((out/'proposed-suite/errata-receipt.json').read_text())
assert receipt['complete'] and not receipt['eligible_for_stock_test262_publication']
assert len(receipt['corrections'])==2
label='test/staging/sm/lexical-environment/block-scoped-functions-annex-b-label.js'
assert (out/'proposed-suite/suite'/label).read_bytes()==(root/'test262/vendor/test262'/label).read_bytes()
rows=json.loads((out/'probe-observations.json').read_text()); assert len(rows)==28
assert {r['engine'] for r in rows}=={'scriptw','v8','spidermonkey','quickjs'}
for r in rows:
 assert r['probe_sha256']==sha((root/'test262/errata/reproducers'/r['probe']).read_bytes())
probes=[{k:v for k,v in r.items() if k not in {'command'}} for r in rows]
identity=json.loads((out/'original-fixture-differential.json').read_text())['identities']
files={}
for name in ['run_probes.py','prepare_proposals.py','verify_proposals.py','seal_evidence.py','probe-observations.json','original-fixture-differential.json','oracle-install.json','oracle-install.log','patch-validation.json','native-commands.json','original-four.txt','original-and-controls.txt','prepare-suite.stdout','prepare-suite.stderr','timezone-tooling-tests.log','errata-tooling-tests.log','ecma262-arguments-normative-commit.patch','ecma262-label-editorial-source.patch','test262-sm-import-relevant.patch','ecma402-timezone-rules-commit.patch','ecma262-current.html']:
 files[name]=(out/name).read_bytes()
for name in ['ecma262-pinned-spec.html']:
 files[name]=(Path('/workspace/porffor/target/scriptw-test262-refresh-20261020-run1')/name).read_bytes()
files['ecma402-observed.html']=Path('/workspace/porffor/target/scriptw-timezone-links-triage-20261020-run1/ecma402-locales-currencies-tz.html').read_bytes()
for directory in ['probe-logs','original-and-controls-snapshots','proposed-test-corrections-snapshots','proposed-fixtures']:
 for p in (out/directory).rglob('*'):
  if p.is_file():files[str(p.relative_to(out))]=p.read_bytes()
for command in commands:
 for suffix in ['stdout','stderr']:
  name=command[suffix]; files[name]=(out/name).read_bytes()
for p in out.glob('original-[01]-*.std*'): files[p.name]=p.read_bytes()
for p in out.glob('oracle-original-*.js'): files[p.name]=p.read_bytes()
files['proposed-suite/errata-receipt.json']=(out/'proposed-suite/errata-receipt.json').read_bytes()
for directory in ['test262/errata/proposals','test262/errata/reproducers']:
 for p in (root/directory).rglob('*'):
  if p.is_file():files[str(p.relative_to(root))]=p.read_bytes()
for correction in [*receipt['corrections'],{'path':label}]:
 rel=correction['path']; files['original-fixtures/'+rel]=(root/'test262/vendor/test262'/rel).read_bytes()
for name in ['sta.js','assert.js']:files['original-fixtures/harness/'+name]=(root/'test262/vendor/test262/harness'/name).read_bytes()
files['inventory.json']=(json.dumps({name:sha(data) for name,data in sorted(files.items())},indent=2)+'\n').encode()
archive=root/'test262/snapshots/final-four-resolution-20261021.tar.gz'; assert not archive.exists()
with archive.open('wb') as stream,gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644; tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)
 for member in tar.getmembers():assert tar.extractfile(member).read()==files[member.name]
report={'schema':'scriptw-conformance-resolution-evidence-v1','date':'2026-10-21','local_preparation_complete':True,'all_original_failures_fixed':False,'compiler_changed':False,'new_original_execution_fixes':0,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'compiler_identity':prior['compiler_identity'],'reuse_basis':'No product/compiler source diff since the integrated global-prelude repair; previous source-equivalence inventory still applies.','original_source_pins':proposals['base_source_pins'],'canonical_baseline_unchanged':prior['canonical_baseline_unchanged'],'native_results':results,'proposed_suite_receipt':receipt,'label_original_unchanged_in_proposed_suite':True,'patch_validation':[{k:v for k,v in x.items() if k!='command'} for x in json.loads((out/'patch-validation.json').read_text())],'proposals_manifest':'test262/errata/proposals/manifest.json','proposals_manifest_sha256':sha((root/'test262/errata/proposals/manifest.json').read_bytes()),'proposed_source_changes_adopted':False,'upstream_messages_sent':False,'comparison_engine_identities':identity,'probe_observations':probes,'comparison_original_fixtures':[{k:v for k,v in x.items() if k!='command'} for x in json.loads((out/'original-fixture-differential.json').read_text())['cases']],'tooling_checks':{'timezone_generation':{'passed':11,'failed':0,'skipped':0},'errata_preparation':{'passed':7,'failed':0,'skipped':0}},'full_fixed_source_suite_verified':False,'full_campaign_status':'Not started: authoritative resolution of label semantics and timezone/test proposals is outstanding. No compiler change has been adopted.','evidence_archive':str(archive.relative_to(root)),'evidence_archive_sha256':sha(archive.read_bytes()),'evidence_archive_members':len(files),'archive_round_trip_verified':True}
(root/'docs/rust-rewrite/final-four-resolution-20261021.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'archive':str(archive.relative_to(root)),'bytes':archive.stat().st_size,'members':len(files),'sha256':sha(archive.read_bytes()),'native_original':'10/14 pass;4 fail','proposed_test_corrections':'3/4 pass;original label still fails'},indent=2))
