#![no_std]
#[unsafe(no_mangle)]
pub static SCRIPTW_RUNTIME_PACKAGE: [u8; 40191425] = *include_bytes!("/workspace/porffor/target/release/build/scriptw-runtime-image-fffa17acded86ba0/out/scriptw-runtime-package.bin");
#[unsafe(no_mangle)]
pub static SCRIPTW_RUNTIME_NATIVE: [u8; 81711440] = *include_bytes!("/workspace/porffor/target/release/build/scriptw-runtime-image-fffa17acded86ba0/out/scriptw-runtime-native.bin");
#[unsafe(no_mangle)]
pub static SCRIPTW_RUNTIME_MANIFEST: [u8; 173] = *include_bytes!("/workspace/porffor/target/release/build/scriptw-runtime-image-fffa17acded86ba0/out/scriptw-runtime-manifest.bin");
#[unsafe(no_mangle)]
pub static SCRIPTW_RUNTIME_PORTABLE_PACKAGE: [u8; 40189491] = *include_bytes!("/workspace/porffor/target/release/build/scriptw-runtime-image-fffa17acded86ba0/out/scriptw-runtime-portable-package.bin");
#[unsafe(no_mangle)]
pub static SCRIPTW_RUNTIME_PORTABLE_NATIVE: [u8; 21924155] = *include_bytes!("/workspace/porffor/target/release/build/scriptw-runtime-image-fffa17acded86ba0/out/scriptw-runtime-portable-native.packed");
#[unsafe(no_mangle)]
pub static SCRIPTW_RUNTIME_PORTABLE_MANIFEST: [u8; 173] = *include_bytes!("/workspace/porffor/target/release/build/scriptw-runtime-image-fffa17acded86ba0/out/scriptw-runtime-portable-manifest.bin");
