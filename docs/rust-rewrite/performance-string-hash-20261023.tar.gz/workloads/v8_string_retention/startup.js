print('scriptw-startup-ok');
