"""Keep existing reserves while sharing verified library bytes across disk/tmpfs."""
import hashlib,json,os,shutil,stat,subprocess,tarfile
from pathlib import Path
r=Path('/workspace/lila-tooling-next');b=r/'target/performance-hills-20261021-attribution';release=Path('/workspace/porffor/target/release')
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
assert json.loads((b/'candidate53-product-timing-gates-complete.json').read_text())['complete']
# Use the same verified archive/active-consumer primitives as the prior batch,
# without executing its task-specific retirement code.
source=Path('/tmp/scriptw-performance-batch24/preserve-runtime-space.py').read_text()
namespace={};exec(source[:source.index('old_record=')],namespace)
archive=namespace['archive'];active_paths=namespace['active_paths']
# All current measurements are closed; preserve their private caches separately
# from the raw observations and reusable shared build/native caches.
cache_dirs=[b/name for name in ['candidate43-repeated-key-execution-cache','candidate44-native-policy-cache','candidate49-equivalence-cache','candidate52-measurement-cache','candidate53-measurement-cache-after','candidate53-measurement-cache-before','candidate53-semantic-cache']]
cache_dirs.extend(p for p in (b/'candidate53-startup-paired').iterdir() if p.is_dir() and 'cache' in p.name)
closed_paths=[p for d in cache_dirs for p in sorted(d.rglob('*')) if p.is_file()]
closed_paths.extend(b/'candidate53-source-guards'/target/'source-guards' for target in ['structure_builtins','structure_language'])
assert len(closed_paths)==len(set(closed_paths)) and not set(closed_paths)&active_paths()
closed_caches=archive('candidate53-closed-private-caches-archive',closed_paths)
for p in closed_paths:p.unlink()
print('Private completed caches/guards archived',sum(x['bytes'] for x in closed_caches['files']),'->',closed_caches['archive_bytes'],flush=True)
old=[]
for directory in ['/tmp/scriptw-performance-candidate-b59303ebe','/tmp/scriptw-performance-candidate-4fe934c4b']:
 old.extend(sorted(Path(directory).iterdir()))
assert {(p.parent.name,p.name) for p in old} == {('scriptw-performance-candidate-b59303ebe','scriptw'),('scriptw-performance-candidate-b59303ebe','runtime_baseline'),('scriptw-performance-candidate-4fe934c4b','scriptw')}
assert all(p.open('rb').read(4)==b'\x7fELF' for p in old)
assert not set(old)&active_paths()
closed=archive('candidate53-closed-older-products-archive',old)
aliases=[]
for directory in [release,release/'deps',release/'examples']:
 for p in directory.iterdir():
  if p.is_symlink() and p.resolve() in old:aliases.append(dict(original=str(p),storage=str(p.resolve()),sha256=sha(p)))
closed['retired_aliases']=aliases
(b/'candidate53-closed-older-products-archive/inventory.json').write_text(json.dumps(closed,indent=2)+'\n')
for row in aliases:Path(row['original']).unlink()
for p in old:p.unlink()
print('Closed old products archived',sum(x['bytes'] for x in closed['files']),'->',closed['archive_bytes'],flush=True)
# Preserve all dependencies: copies are byte-verified and replaced by aliases.
# Rustc's existing wrapper detaches only actual dirty outputs on rebuild.
stage=Path('/tmp/scriptw-performance-staged-libraries53');stage.mkdir(exist_ok=False)
before={p:shutil.disk_usage(p).free for p in ['/workspace','/tmp']};rows=[]
selected=[];free_root=before['/workspace'];free_tmp=before['/tmp']
for p in sorted((release/'deps').glob('libscriptw_*.rlib'),key=lambda p:p.stat().st_size if p.is_file() else 0,reverse=True):
 if free_root>=3*1024**3:break
 if not p.is_file() or p.is_symlink() or p.stat().st_size<60*1024**2:continue
 size=p.stat().st_size
 if free_tmp-size < 450_000_000+2*256*1024**2:continue
 selected.append(p);free_root+=size;free_tmp-=size
assert free_root>=3*1024**3,dict(free_root=free_root,free_tmp=free_tmp,before=before)
assert not set(selected)&active_paths()
for p in selected:
 st=p.stat();digest=sha(p);dest=stage/(digest+'-'+p.name)
 aliases=[p]+[x for x in release.glob(p.name.split('-')[0]+'.*') if x.is_file() and not x.is_symlink() and x.samefile(p)]
 assert len(aliases)==st.st_nlink
 shutil.copy2(p,dest);assert sha(dest)==digest
 rows.append(dict(original=str(p),storage=str(dest),sha256=digest,bytes=st.st_size,aliases=list(map(str,aliases))))
receipt=dict(complete=True,files=rows,free_before=before,policy='All dependency bytes retained, not retired. Only verified aliases move storage; exact mtime/mode retained and dirty rustc outputs protected. Reserve 450MB independent native runtime output plus 256MiB scratch per native process.')
(b/'candidate53-staged-libraries.json').write_text(json.dumps(receipt,indent=2)+'\n')
for row in rows:
 for name in row['aliases']:
  p=Path(name);assert sha(p)==row['sha256'];p.unlink();p.symlink_to(row['storage'])
receipt['free_after']={p:shutil.disk_usage(p).free for p in ['/workspace','/tmp']}
assert receipt['free_after']['/workspace'] >= 3*1024**3
assert receipt['free_after']['/tmp'] >= 450_000_000+2*256*1024**2
(b/'candidate53-staged-libraries.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Dependency storage',receipt['free_after'],flush=True)
