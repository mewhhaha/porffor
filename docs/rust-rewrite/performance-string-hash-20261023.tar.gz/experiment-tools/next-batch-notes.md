# Next performance batch: isolate retained-row execution

Read-only audit on 2026-10-23; this is a plan, not hill acceptance.

- P067's `resolve_env_handle_local` already emits the exact number of parent
  field reads. Zero hops loads the current environment; there is no runtime
  search loop to remove. Any cached handle must track lexical instance changes,
  per-iteration scope replacement and generator/async resume. Profile before
  adding another representation or repeating the rejected inline-cell layout.
- Prefer completing P001/P002 attribution next. `runtime_baseline` compiles once
  then uses a fresh Store per warmup/sample. Its existing execution-and-completion
  timer excludes compilation, module setup and instantiation. Existing external
  CPU profiles cover the whole child, and invocation RSS includes admission.
- Reuse the existing 256/1024/4096-row, width 2/4/8, pass 0/1/4 corpus in
  `performance-first-wave-20261022.json`. It already supplies geometric scaling
  and construction/pass controls. Do not rebuild a second row-sweep framework.
- Narrow P001 design: opt-in external sampler control at the existing execution
  span, with measured boundary/control overhead, exact R/P identities and checked
  stdout. Keep compiler, warmups and native verification outside that sample.
- Narrow P002 design: retain rows in the same invocation and separate named
  buildRows/scanRows regions. That alone is not a traversal-only elapsed timer.
  An added benchmark-only timer boundary needs measured clock/host-call overhead
  and an empty control. Do not subtract independently timed p0 from p4 and call
  the difference direct traversal timing. Do not share a Store across ordinary
  observations or bypass ordinary script entry semantics.
- P005 balanced repeated comparisons already exist, but an explicit empirical
  noise range is still missing. P008 application-cache/warm-OS-cache labels are
  established. P003 needs analysis/plots of existing curves rather than a repeat
  sweep. P011-P015 still need broader workload coverage; React SSR correctness
  evidence is not an SSR performance benchmark.

The verification observer also has measured overhead: about 0.52 s to scan
~18,000 /proc entries. The virtual /proc has no usable children files and the
visible cgroup.procs is empty, so those faster process-discovery attempts are
rejected (membership comparisons failed). Upcoming acceptance watchers keep
whole-cgroup sampling every two seconds and sample optional per-process detail
every 30 seconds. No compiler/cache/worker/deadline policy changes. These are
verification diagnostics, not product throughput measurements.

Existing scaling evidence worth targeting (historical source621ba89ca, three-
sample screen; not a current-source benchmark or isolated GC attribution):

| Width4 rows | Construction-only median ns | Four-pass combined median ns | GC capacity after |
| ---: | ---: | ---: | ---: |
| 256 | 10409635 | 23747967 | 16 MiB |
| 1024 | 31181782 | 63773165 | 16 MiB |
| 4096 | 419958172 | 610377463 | 32 MiB |

The 1024→4096 construction jump is ~13.5x for 4x rows, coincident with a reported
capacity transition. Coincidence is not proof that GC causes the excess cost.
These values are `reports.current-screen.summaries.execution.wasmtime` in the
first-wave archive. The original seven-sample 1024 controls are 32665040 ns
construction and 65891974 ns combined. Analyze existing raw points and memory
boundaries before spending time on another row sweep. The current product differs
substantially, so a narrow current-source phase profile is still necessary.

Correction to the initial coverage audit: the default V8 README manifest is not
all measured coverage. `scripts/performance_corpus.py` and first-wave
`reports.current-screen` contain 43 measured cases for both Wasmtime and V8,
including direct zero/two-argument, closure, indirect and recursive calls;
own/dynamic/inherited/getter/proxy reads; typed copy/sort; JSON parse/stringify;
and string/RegExp/Map/Set cases. Do not add duplicate families under P011-P013.
Broader parameter sweeps, causal attribution and explicit acceptance analysis
remain separate questions; these historical baseline scores are not current
product throughput or new optimization wins. Any later ledger reconciliation
should cite those existing source-bound measurements and the actual unfulfilled
criterion, rather than looking only at the three-row default README manifest.
