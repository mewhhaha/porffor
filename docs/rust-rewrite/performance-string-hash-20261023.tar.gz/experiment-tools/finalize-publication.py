"""Publish only after the frozen replay and saved-result validation complete."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

root = Path('/workspace/lila-tooling-next')
base = root / 'target/performance-hills-20261021-attribution'
batch = Path('/tmp/scriptw-performance-batch24')
memory = base / 'candidate53-string-hash-replay-memory.jsonl'
print('Waiting for sealed original-case replay completion', flush=True)
while True:
    rows = memory.read_text().splitlines()
    last = json.loads(rows[-1])
    if last['type'] == 'completion':
        break
    time.sleep(2)
assert last['exit_code'] == 1
summary = base / 'candidate53-string-hash-replay/summary.json'
original = summary.read_bytes()
data = json.loads(original)
assert data['total'] == 13104 and data['outcomes'] == dict(Success=13100, Bug=4, Crash=0, NotImplemented=0)
backup = base / 'candidate53-string-hash-replay-original-summary.json'
with backup.open('xb') as output:
    output.write(original)
command = ['python3', '-B', 'scripts/limited_verification.py', '--cloud', '--cloud-cpus', 'auto', '--',
           'python3', '-B', 'scripts/replay-test262-executions.py',
           str(base / 'candidate53-string-hash.executions'),
           '--binary', '/tmp/scriptw-performance-candidate-97036e5a8/scriptw',
           '--suite-root', str(root / 'test262/vendor/test262'),
           '--output-dir', str(base / 'candidate53-string-hash-replay'),
           '--workers', '4', '--reuse-case-workers', '--resume']
log_path = base / 'candidate53-string-hash-replay-resume.log'
with log_path.open('x') as log:
    result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
assert result.returncode == 1 and summary.read_bytes() == original
assert 'Resuming 13104/13104 verified completed executions' in log_path.read_text()
(base / 'candidate53-string-hash-replay-resume-verification.json').write_text(json.dumps(dict(
    command=command, exit_code=result.returncode, completed_execution_count=13104,
    summary_unchanged=True, summary_sha256=hashlib.sha256(original).hexdigest(),
    transcript_sha256=hashlib.sha256(log_path.read_bytes()).hexdigest()), indent=2) + '\n')
print('All 13,104 saved results validate without rerunning cases', flush=True)
for script in ['publish-string-hash.py', 'update-docs.py']:
    subprocess.run(['python3', '-B', str(batch / script)], cwd=root, check=True)
for args in [
    ['python3', '-B', 'scripts/generate-test-graph.py', '--check'],
    ['python3', '-B', 'scripts/status_publication.py', '--check-committed'],
    ['git', 'diff', '--check'],
]:
    subprocess.run(args, cwd=root, check=True)
paths = ['README.md', 'CONTINUE.md', 'docs/performance-hills.md',
         'docs/rust-rewrite/current-inventory.md', 'docs/rust-rewrite/v8-baseline.md',
         'docs/rust-rewrite/performance-string-hash-20261023.json',
         'docs/rust-rewrite/performance-string-hash-20261023.tar.gz']
subprocess.run(['git', 'add', '--sparse', '--', *paths], cwd=root, check=True)
subprocess.run(['git', 'commit', '-m', 'Accept cached String hashes with complete affected conformance evidence'], cwd=root, check=True)
subprocess.run(['bash', 'scripts/check-readme-status-artifacts.sh', 'HEAD^'], cwd=root, check=True)
subprocess.run(['git', 'push', 'origin', 'HEAD:main'], cwd=root, check=True)
subprocess.run(['git', 'ls-remote', 'origin', 'refs/heads/main'], cwd=root, check=True)
print('String-hash checkpoint published and pushed', flush=True)
