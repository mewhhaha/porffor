"""Pinned whole-process startup ABBA; immutable52 vs53, no V8 or heap claim."""
import hashlib,json,os,statistics,subprocess,sys
from pathlib import Path
root=Path('/workspace/lila-tooling-next');base=root/'target/performance-hills-20261021-attribution'
sys.path.insert(0,str(root/'scripts'))
from benchmark_metrics import digest,measure_process
out=base/'candidate53-startup-paired';out.mkdir(exist_ok=False)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
env=dict(os.environ);env.pop('SCRIPTW_WASM_TRACE',None)
binaries={};identities={};frozen={}
for side,n in [('before',52),('after',53)]:
 rows=json.loads((base/f'candidate{n}-product-frozen.json').read_text());r=next(r for r in rows if Path(r['storage']).name=='scriptw');p=Path(r['storage'])
 assert digest(p)==r['sha256'];binaries[side]=p;frozen[side]=r
 identities[side]=json.loads(subprocess.check_output([str(p),'compiler-identity'],cwd=root,text=True))
 assert identities[side]['executable_sha256']==r['sha256']
assert identities['before']['source_revision']['commit']=='5c63c6597383ba4d6f56e0780daac922798b1033'
assert identities['after']['source_revision']['commit']==source
fixture=root/'crates/scriptw-cli/tests/fixtures/v8_baseline/startup.js'
expected='scriptw-startup-ok\nrun outcome: RunOutcome { backend_used: WasmAot, note: "wasm-aot completion: undefined(undefined)" }\n'
report=dict(schema='scriptw-native-storage-startup-v1',complete=False,source_commit=source,harness_sha256=digest(__file__),cpu=sorted(os.sched_getaffinity(0)),identities=identities,frozen=frozen,source_sha256=digest(fixture),samples_per_round=7,order=['before','after','after','before'],observations=[],boundary='Whole process spawn-to-reap including GNU time supervisor; child kernel high-water RSS is not live JS heap. OS caches not flushed. Cold application caches unique, hot cache prewarmed per round. Traced priming excluded; no execution or statistical significance claim.')
def save():
 (out/'progress.json').write_text(json.dumps(report,indent=2)+'\n')
for round_index,side in enumerate(report['order']):
 command=[str(binaries[side]),'--jobs','1','run','--execution-backend','wasm',str(fixture)]
 hot=out/f'hot-cache-{round_index}'
 trace=subprocess.run(command,cwd=root,env=dict(env,SCRIPTW_CACHE_DIR=str(hot),SCRIPTW_WASM_TRACE='1'),capture_output=True,text=True,timeout=180)
 (out/f'prime-{round_index}.stdout').write_text(trace.stdout);(out/f'prime-{round_index}.stderr').write_text(trace.stderr)
 assert trace.returncode==0 and trace.stdout==expected and 'runtime-native-bundle hit:' in trace.stderr
 for mode in ['cold','hot']:
  for index in range(7):
   label=f'{round_index}-{side}-{mode}-{index}';cache=hot if mode=='hot' else out/f'cold-cache-{round_index}-{index}'
   stdout=out/(label+'.stdout');stderr=out/(label+'.stderr')
   with stdout.open('x') as x,stderr.open('x') as y:event=measure_process(command,cwd=root,env=dict(env,SCRIPTW_CACHE_DIR=str(cache)),stdout=x,stderr=y,timeout=180,time_binary='/workspace/.scriptw-tools/gnu-time/usr/bin/time')
   assert event['exit_code']==0 and not event['timed_out'] and stdout.read_text()==expected
   report['observations'].append(dict(side=side,round=round_index,mode=mode,index=index,command=command,cache=str(cache),stdout=stdout.name,stdout_sha256=digest(stdout),stderr=stderr.name,stderr_sha256=digest(stderr),**event));save()
 for mode in ['cold','hot']:
  obs=[r for r in report['observations'] if r['round']==round_index and r['mode']==mode]
  print(side,round_index,mode,'median_ms',statistics.median(r['elapsed_ns'] for r in obs)/1e6,'median_RSS_MiB',statistics.median(r['peak_rss_bytes'] for r in obs)/2**20,flush=True)
report['summaries']={}
for mode in ['cold','hot']:
 report['summaries'][mode]={}
 for side in binaries:
  rows=[r for r in report['observations'] if r['side']==side and r['mode']==mode]
  report['summaries'][mode][side]={metric:dict(round_medians=[statistics.median(r[metric] for r in rows if r['round']==n) for n in sorted({r['round'] for r in rows})],median_of_round_medians=statistics.median(statistics.median(r[metric] for r in rows if r['round']==n) for n in sorted({r['round'] for r in rows}))) for metric in ['elapsed_ns','peak_rss_bytes']}
assert len(report['observations'])==56 and all(digest(binaries[s])==frozen[s]['sha256'] for s in binaries)
report['complete']=True;(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print('Startup ABBA complete',report['summaries'],flush=True)
