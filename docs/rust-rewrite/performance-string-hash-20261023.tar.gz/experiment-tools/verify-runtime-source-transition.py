"""Preserve repaired metadata and recover original-source staging from archive."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

root = Path('/workspace/lila-tooling-next')
base = root / 'target/performance-hills-20261021-attribution'
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
hash_bytes = lambda raw: hashlib.sha256(raw).hexdigest()
identity_path = base / 'candidate53-independent-native-runtime-identity.json'
identity = json.loads(identity_path.read_text())
archive = json.loads((base / 'candidate53-frozen-runtime-image-archive/inventory.json').read_text())
assert archive['complete'] and sha(archive['archive']) == archive['archive_sha256']
assert json.loads((base / 'candidate53b-native-memory.jsonl').read_text().splitlines()[-1])['type'] == 'completion'
expected = {Path(row['original']).name: row for row in archive['files']}
images = {Path(row['native']).name: row for row in identity['files']}
current = {name: dict(path=row['native'], bytes=Path(row['native']).stat().st_size,
                      sha256=sha(row['native'])) for name, row in images.items()}
changed = [name for name in images if current[name]['sha256'] != images[name]['sha256']]
assert set(changed) == {'libscriptw_runtime_images.a', 'scriptw-runtime-manifest.bin',
                       'scriptw-runtime-portable-manifest.bin', 'scriptw-runtime-package.bin',
                       'scriptw-runtime-portable-package.bin'}, changed
# Preserve every changed repaired file, dereferencing its staging aliases.
repair_dir = base / 'candidate53b-runtime-metadata-archive'
repair_dir.mkdir(exist_ok=False)
packed = repair_dir / 'payload.tar.zst'
with packed.open('xb') as output:
    process = subprocess.Popen(['zstd', '-q', '-1', '-T1', '--long=29', '-c'], stdin=subprocess.PIPE, stdout=output)
    with tarfile.open(fileobj=process.stdin, mode='w|', dereference=True) as tar:
        for name in sorted(changed): tar.add(current[name]['path'], arcname=name, recursive=False)
    process.stdin.close()
    assert process.wait() == 0
process = subprocess.Popen(['zstd', '-q', '--long=29', '-dc', str(packed)], stdout=subprocess.PIPE)
with tarfile.open(fileobj=process.stdout, mode='r|') as tar:
    actual = [(member.name, member.size, hashlib.file_digest(tar.extractfile(member), 'sha256').hexdigest()) for member in tar]
assert process.wait() == 0
assert actual == [(name, current[name]['bytes'], current[name]['sha256']) for name in sorted(changed)]
repair_inventory = dict(complete=True, archive=str(packed), archive_sha256=sha(packed), files=[current[name] | dict(member=name) for name in sorted(changed)])
(repair_dir / 'inventory.json').write_text(json.dumps(repair_inventory, indent=2) + '\n')

original_small = {}
restored = Path('/tmp/scriptw-performance-original53-restored')
restored.mkdir(exist_ok=False)
restorations = []
process = subprocess.Popen(['zstd', '-q', '--long=29', '-dc', archive['archive']], stdout=subprocess.PIPE)
verified = []
with tarfile.open(fileobj=process.stdout, mode='r|') as tar:
    for member in tar:
        name = Path(member.name).name
        wanted = expected[name]
        raw = tar.extractfile(member).read()
        assert member.name == wanted['member'] and len(raw) == wanted['bytes'] and hash_bytes(raw) == wanted['sha256']
        verified.append(name)
        if name.endswith('manifest.bin') or name.endswith('package.bin'):
            original_small[name] = raw
        row = images[name]
        if name == 'image_data.rs':
            native_raw = Path(row['native']).read_bytes()
            assert hash_bytes(native_raw) == row['sha256']
            assert native_raw.replace(str(Path(row['native']).parent).encode(), str(Path(row['product']).parent).encode()) == raw
        else:
            assert row['sha256'] == wanted['sha256'], 'Original native comparison must match archived product bytes'
        if sha(row['product']) != wanted['sha256']:
            assert name.endswith('package.bin')
            destination = restored / (wanted['sha256'] + '-' + name)
            with destination.open('xb') as output: output.write(raw)
            assert sha(destination) == wanted['sha256']
            restorations.append(dict(path=row['product'], previous_alias=str(Path(row['product']).resolve()),
                                     previous_sha256=sha(row['product']), restored=str(destination), sha256=wanted['sha256']))
assert process.wait() == 0 and set(verified) == set(expected)

profiles = []
for prefix in ['scriptw-runtime', 'scriptw-runtime-portable']:
    name = prefix + '-package.bin'
    before = original_small[name]
    after = Path(images[name]['native']).read_bytes()
    assert before[:8] == after[:8] == b'SCRWRB01'
    assert int.from_bytes(before[8:12], 'little') == int.from_bytes(after[8:12], 'little') == 16
    assert hash_bytes(before[:-32]) == before[-32:].hex() and hash_bytes(after[:-32]) == after[-32:].hex()
    # Envelope: magic/layout, 32-byte compiler source, then identity, key,
    # complete raw Wasm payload/metadata, and final package checksum.
    assert before[:12] == after[:12] and before[44:-32] == after[44:-32]
    assert before[12:44] != after[12:44]
    manifest_name = prefix + '-manifest.bin'
    old_manifest = original_small[manifest_name]
    new_manifest = Path(images[manifest_name]['native']).read_bytes()
    assert old_manifest[:8] == new_manifest[:8] == b'SCRWNR01'
    assert int.from_bytes(old_manifest[8:12], 'little') == int.from_bytes(new_manifest[8:12], 'little') == 4
    target_len = int.from_bytes(old_manifest[19:21], 'little')
    offset = 21 + target_len
    assert len(old_manifest) == len(new_manifest) == offset + 128
    assert old_manifest[:offset] == new_manifest[:offset]
    assert old_manifest[offset:offset+32] == before[12:44]
    assert new_manifest[offset:offset+32] == after[12:44]
    assert old_manifest[offset+32:offset+64] == new_manifest[offset+32:offset+64] == before[76:108]
    assert old_manifest[offset+64:offset+96] == hashlib.sha256(before).digest()
    assert new_manifest[offset+64:offset+96] == hashlib.sha256(after).digest()
    native_digest = sha(images[prefix + '-native.bin']['native'])
    assert old_manifest[offset+96:] == new_manifest[offset+96:] == bytes.fromhex(native_digest)
    assert native_digest == images[prefix + '-native.bin']['sha256']
    profiles.append(dict(profile=prefix, original_source_fingerprint=before[12:44].hex(),
                         repair_source_fingerprint=after[12:44].hex(),
                         raw_package_payload_unchanged=True, payload_sha256=hash_bytes(before[44:-32]),
                         runtime_key=before[76:108].hex(), native_sha256=native_digest,
                         manifest_differences='compiler source identity and full package digest only'))

# Change only the old product aliases; repaired native producer bytes stay put.
for row in restorations:
    alias = Path(row['path'])
    assert alias.is_symlink() and sha(alias) == row['previous_sha256']
    pending = alias.with_name(alias.name + '.original53-restored')
    pending.symlink_to(row['restored'])
    pending.replace(alias)
assert all(sha(row['product']) == row['product_sha256'] for row in images.values())
assert all(sha(row['path']) == row['sha256'] for row in current.values())
receipt = dict(complete=True, original_source=identity['source'],
               repair_source='7efa1348276e55c9779714662c6ad938c50db6a7',
               original_identity_receipt_sha256=sha(identity_path),
               original_archive_sha256=archive['archive_sha256'], original_archive_members_verified=verified,
               repaired_native_files=current, repaired_archive=repair_inventory,
               profiles=profiles, restored_original_product_aliases=restorations,
               conclusion='Test-only source changes altered conservative source identities and package/manifest checksums. Full raw Wasm payloads, runtime keys and serialized native code remain byte-identical. The repair build rewrote two shared mutable package aliases; original product staging was restored from the verified archive without changing the repaired native outputs or frozen executables.')
(base / 'candidate53b-runtime-source-transition.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('Both raw runtime payloads and native images match; changed source metadata preserved; two original aliases restored')
