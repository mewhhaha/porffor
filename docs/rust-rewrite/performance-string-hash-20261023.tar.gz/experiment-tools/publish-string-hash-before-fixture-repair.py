"""Validate and preserve the cached raw-string-hash performance checkpoint."""
import gzip
import hashlib
import io
import json
from datetime import datetime, timezone
from pathlib import Path
from statistics import median
import subprocess
import tarfile

ROOT = Path('/workspace/lila-tooling-next')
BASE = ROOT / 'target/performance-hills-20261021-attribution'
SOURCE = '97036e5a80c165067879cc2e407f15042d7f18d7'
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
read = lambda name: json.loads((BASE / name).read_text())
admission = read('candidate53-performance-admission.json')
assert admission['source'] == SOURCE and admission['proceed_to_correctness'] and admission['retain_if_correct']
native = read('candidate53-native-checkpoint/receipt.json')
assert native['head'] == SOURCE and native['source_unchanged'] and native['shared_runtime_linker_unchanged']
expected_scopes = {
    ('scriptw-aot-wasm', 'scriptw_aot_wasm'), ('scriptw-aot-wasm', 'structure_builtins'),
    ('scriptw-aot-wasm', 'structure_language'), ('scriptw-engine', 'scriptw_engine'),
    ('scriptw-engine', 'aot_builtins'), ('scriptw-engine', 'aot_language'),
    ('scriptw-engine', 'aot_realm_modules'), ('scriptw-engine', 'aot_gc_entries'),
    ('scriptw-engine', 'aot_native_program_templates'), ('scriptw-engine', 'runtime_cache'),
    ('scriptw-cli', 'cli'), ('scriptw-runtime-image', 'scriptw_runtime_image'),
}
assert len(native['cases']) == 12 and {(c['package'], c['target']) for c in native['cases']} == expected_scopes
assert all(c['state'] == 'passed' and c['exit_code'] == 0 and c['inventory_matches'] for c in native['cases'])
counts = {key: sum(o[key] for c in native['cases'] for o in c['outcomes']) for key in ['passed', 'failed', 'ignored']}
assert counts['passed'] > 3893 and counts['failed'] == counts['ignored'] == 0
assert not subprocess.check_output(['git', 'diff', '--name-only', SOURCE, '--', 'crates', 'Cargo.toml', 'Cargo.lock', 'vendor'], cwd=ROOT)

controls = read('candidate53-product-semantic-controls-final/receipt.json')
assert controls['complete'] and controls['source_commit'] == SOURCE
assert len(controls['cases']) == 18 and all(c['exit_code'] == 0 and c['native_image_hit'] for c in controls['cases'])
guard_set = read('candidate53-source-guards/receipt.json')
assert guard_set['passed'] and guard_set['exit_code'] == 0
assert {r['target'] for r in guard_set['targets']} == {'structure_builtins', 'structure_language'}
guards = {}
for row in guard_set['targets']:
    guard = read('candidate53-source-guards/' + row['receipt'])
    assert guard['passed'] and guard['result_summaries'] == [['ok', str(len(guard['test_inventory'])), '0', '0', '0', '0']]
    assert len(guard['full_cargo_only_modules']) == 4
    guards[row['target']] = {k: guard[k] for k in ['compile_ns', 'execute_ns', 'result_summaries', 'source_modules', 'full_cargo_only_modules']}
frozen = read('candidate53-product-frozen.json')
for row in frozen:
    assert Path(row['storage']).stat().st_size == row['bytes'] and sha(row['storage']) == row['sha256']
images = read('candidate53-independent-native-runtime-identity.json')
assert images['complete'] and images['source'] == SOURCE and len(images['files']) == 10
for row in images['files']:
    assert sha(row['native']) == row['sha256']
    if not row['producer_path_only_difference']:
        assert row['exact_bytes'] and row['sha256'] == row['product_sha256']

replay = read('candidate53-string-hash-replay/summary.json')
requested = (BASE / 'candidate53-string-hash.executions').read_text().splitlines()
assert replay['total'] == len(requested) == len(set(requested)) == 13104
assert replay['binary_sha256'] == controls['cli_sha256']
assert replay['execution_list_sha256'] == sha(BASE / 'candidate53-string-hash.executions')
assert replay['outcomes'] == dict(Success=13100, Bug=4, Crash=0, NotImplemented=0)
assert {r['execution_id'] for r in replay['results']} == set(requested)
assert not any('infrastructure_error' in r for r in replay['results'])
known = {
    'sloppy-script:annexB/language/function-code/block-decl-func-skip-arguments.js',
    'sloppy-script:intl402/Temporal/ZonedDateTime/links.js',
    'strict-script:intl402/Temporal/ZonedDateTime/links.js',
    'sloppy-script:staging/sm/lexical-environment/block-scoped-functions-annex-b-label.js',
}
assert {r['execution_id'] for r in replay['results'] if r['outcome'] != 'Success'} == known
replay_memory = [json.loads(line) for line in (BASE / 'candidate53-string-hash-replay-memory.jsonl').read_text().splitlines()][-1]
assert replay_memory['type'] == 'completion' and replay_memory['exit_code'] == 1
assert all(replay_memory['memory_events_delta'].get(k, 0) == 0 for k in ['oom', 'oom_kill', 'oom_group_kill'])

cohorts = {}
for name in ['candidate53-hash-screen', 'candidate53-hash-confirm']:
    report = read(name + '/receipt.json')
    assert report['complete'] and report['source_commit'] == SOURCE
    assert report['identities']['after']['executable_sha256'] == controls['cli_sha256']
    for row in report['observations']:
        assert row['process']['exit_code'] == 0 and not row['process']['timed_out']
        assert len(row['execution_ns']) == report['configuration']['samples']
        assert row['median_ns'] == median(row['execution_ns'])
        raw_path = BASE / name / row['raw']
        assert sha(raw_path) == row['raw_sha256']
        raw = json.loads(raw_path.read_text())
        case, = raw['cases']
        samples = [r for r in case['observations'] if not r['warmup']]
        assert [r['execution_ns'] for r in samples] == row['execution_ns']
        expected = next(c['stdout'] for c in json.loads((Path(row['command'][1]) / 'manifest.json').read_text())['execution'] if c['file'] == row['file'])
        assert all(r['stdout'] == expected for r in case['observations'])
        assert all(r['module_cache'] == 'Hit' for r in samples)
        assert row['source_fingerprint'] == report['identities'][row['side']]['source_fingerprint']
        assert row['runner_sha256'] == raw['executable_sha256'] == report['runners'][row['side']]['sha256']
    rows = []
    for file in dict.fromkeys(r['file'] for r in report['observations']):
        row = dict(file=file)
        for side in ['before', 'after']:
            values = [r['median_ns'] for r in report['observations'] if r['file'] == file and r['side'] == side]
            row[side] = dict(round_medians_ns=values, median_ns=median(values))
        rows.append(row)
    cohorts[name] = rows
startup = read('candidate53-startup-paired/receipt.json')
assert startup['complete'] and startup['source_commit'] == SOURCE and len(startup['observations']) == 56
for event in startup['observations']:
    assert event['exit_code'] == 0 and not event['timed_out']
    for stream in ['stdout', 'stderr']:
        assert sha(BASE / 'candidate53-startup-paired' / event[stream]) == event[stream + '_sha256']
for mode, groups in startup['summaries'].items():
    for side, metrics in groups.items():
        rows = [r for r in startup['observations'] if r['mode'] == mode and r['side'] == side]
        for metric, values in metrics.items():
            medians = [median(r[metric] for r in rows if r['round'] == n) for n in sorted({r['round'] for r in rows})]
            assert values == dict(round_medians=medians, median_of_round_medians=median(medians))
memory = [json.loads(line) for line in (BASE / 'candidate53-native-memory.jsonl').read_text().splitlines()]
assert memory[-1]['type'] == 'completion' and memory[-1]['exit_code'] == 0
assert all(memory[-1]['memory_events_delta'].get(k, 0) == 0 for k in ['oom', 'oom_kill', 'oom_group_kill'])

retention_memory = {}
report = read('candidate53-hash-confirm/receipt.json')
for file in ['retained-unhashed.js', 'retained-first-hash.js']:
    retention_memory[file] = {}
    for side in ['before', 'after']:
        observations = [row for row in report['observations'] if row['file'] == file and row['side'] == side]
        rounds = []
        for row in observations:
            case, = json.loads((BASE / 'candidate53-hash-confirm' / row['raw']).read_text())['cases']
            samples = [s['memory'] for s in case['observations'] if not s['warmup']]
            assert all(s['process_rss']['status'] == 'sampled' for s in samples)
            rounds.append(dict(gc_capacity_before_bytes=sorted({s['gc_capacity_before_bytes'] for s in samples}),
                gc_capacity_after_bytes=sorted({s['gc_capacity_after_bytes'] for s in samples}),
                median_invocation_max_rss_bytes=median(s['process_rss']['maximum_rss_bytes'] for s in samples),
                whole_child_peak_rss_bytes=row['process']['peak_rss_bytes']))
        retention_memory[file][side] = rounds

assets = {}
def add(path, name):
    assert name not in assets and not Path(name).is_absolute() and '..' not in Path(name).parts
    raw = path.read_bytes()
    assert not raw.startswith(b'\x7fELF'), path
    assets[name] = raw

allowed = {'.json', '.jsonl', '.log', '.txt', '.stdout', '.stderr', '.wasm', '.rs', '.js', '.gz', '.html', '.executions', '.attempts'}
for path in sorted(BASE.glob('candidate53*')):
    if path.is_file() and path.suffix in allowed:
        add(path, 'evidence/' + path.name)
    elif path.is_dir():
        for child in sorted(path.rglob('*')):
            relative = child.relative_to(path)
            if not child.is_file() or any('cache' in part or part.startswith(('cold-', 'hot-')) for part in relative.parts[:-1]):
                continue
            if child.suffix in allowed:
                add(child, 'evidence/' + str(child.relative_to(BASE)))
for path in sorted((ROOT / 'target/watched').glob('workspace-candidate53*.log')):
    add(path, 'watched/' + path.name)
def capture_transcripts(value):
    if isinstance(value, dict):
        for child in value.values(): capture_transcripts(child)
    elif isinstance(value, list):
        for child in value: capture_transcripts(child)
    elif isinstance(value, str) and value.endswith('.log'):
        path = ROOT / value
        if path.is_file() and path.resolve().is_relative_to(ROOT / 'target/watched'):
            name = 'watched/' + path.name
            if name not in assets: add(path, name)
for directory in ['candidate53-native-checkpoint']:
    for path in (BASE / directory).rglob('*.json'):
        capture_transcripts(json.loads(path.read_text()))
for path in sorted(Path('/tmp/scriptw-performance-batch24').iterdir()):
    if path.is_file() and path.suffix in {'.py', '.sh', '.rs', '.md', '.json', '.patch', '.log'}:
        add(path, 'experiment-tools/' + path.name)
for row in images['files']:
    assert sha(row['product']) == row['product_sha256']
    if row['bytes'] < 10000:
        for producer in ['native', 'product']:
            path = Path(row[producer])
            add(path, 'runtime-producers/' + producer + '/' + path.name)
for folder in ['v8_property_definition', 'v8_baseline', 'v8_repeated_keys', 'v8_string_retention']:
    for path in sorted((ROOT / 'crates/scriptw-cli/tests/fixtures' / folder).glob('*')):
        if path.is_file(): add(path, 'workloads/' + folder + '/' + path.name)
for row in controls['cases']:
    path = ROOT / row['fixture']
    assert sha(path) == row['source_sha256']
    add(path, 'semantic-fixtures/' + path.name)
for name in ['scripts/check-source-guards.py', '.cargo/config.toml']:
    add(ROOT / name, 'verification-inputs/' + name)

inventory = [dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) for name, raw in sorted(assets.items())]
add_raw = json.dumps(inventory, indent=2).encode() + b'\n'
assets['inventory.json'] = add_raw
archive = ROOT / 'docs/rust-rewrite/performance-string-hash-20261023.tar.gz'
assert not archive.exists()
with archive.open('xb') as output, gzip.GzipFile(fileobj=output, mode='wb', mtime=0, filename='') as compressed, tarfile.open(fileobj=compressed, mode='w|') as tar:
    for name, raw in sorted(assets.items()):
        info = tarfile.TarInfo(name); info.size = len(raw); info.mode = 0o644
        tar.addfile(info, io.BytesIO(raw))
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == set(assets)
    for member in tar:
        assert tar.extractfile(member).read() == assets[member.name]
receipt = dict(schema='scriptw-string-hash-checkpoint-v1', complete=True,
    published_at=datetime.now(timezone.utc).isoformat(), measured_product_source=SOURCE,
    preceding_product_source='5c63c6597383ba4d6f56e0780daac922798b1033',
    native_counts=counts, native_scopes=sorted(expected_scopes), compiled_semantic_families=18,
    source_equivalence='Product/compiler/fixtures remain exactly the measured source through native and original-case acceptance. Documentation may change after that checkpoint.',
    test262=dict(total=replay['total'], outcomes=replay['outcomes'], known_failures=sorted(known), execution_list_sha256=replay['execution_list_sha256'], full_suite=False),
    paired_cohorts=cohorts, startup_summaries=startup['summaries'], frozen_products=frozen,
    native_memory_completion=memory[-1], replay_memory_completion=replay_memory,
    product_memory_completion=json.loads((BASE / 'candidate53-product-memory.jsonl').read_text().splitlines()[-1]),
    retained_string_memory=retention_memory, performance_admission=read('candidate53-performance-admission.json'),
    fast_source_guards=guards, hill_terminal_count=24, hill_partial_count=7, hill_unresolved_count=129,
    archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive), members=len(assets), inventory_sha256=hashlib.sha256(add_raw).hexdigest()),
    limitations=[
        'Affected release native scopes and original Test262 families; broader release/all-feature acceptance remains open.',
        'All paired screens and confirmation observations, including slower/noisy controls, are retained.',
        'Paired medians are descriptive; no statistical significance or isolated per-change attribution is claimed.',
        'Every StringValue carries an extra i64 payload field even when never hashed; Wasmtime does not expose live/allocation heap counters.',
        'GC capacity and process RSS cannot establish a zero allocation cost; runtime/code/allocator memory are included.',
        'The README V8 table and full-suite graph remain bound to their separately identified source50 reports.',
        'Twenty older shared-memory archives remain unavailable. Newly retired products/runtime payloads have verified workspace archives.',
        'Cargo intentionally retains the existing empty-encoded-Rustflags dependency cohort; normal future builds use restored tracked config.'
    ])
output = archive.with_suffix('').with_suffix('.json')
assert not output.exists(); output.write_text(json.dumps(receipt, indent=2) + '\n')
print('Published', len(assets), 'verified members;', archive.stat().st_size, 'compressed bytes;', counts, replay['outcomes'])
