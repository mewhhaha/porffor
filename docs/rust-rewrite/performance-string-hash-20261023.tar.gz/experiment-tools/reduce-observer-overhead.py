"""Keep cgroup sampling unchanged; sample optional per-process details less often."""
from pathlib import Path
b=Path('/tmp/scriptw-performance-batch24');base=Path('/workspace/lila-tooling-next/target/performance-hills-20261021-attribution')
for file,output in [('watch-native-repair.py','candidate53b-native-memory.jsonl'),('watch-string-hash-replay.py','candidate53-string-hash-replay-memory.jsonl')]:
 assert not (base/output).exists(),'Never modify a running/recorded watcher'
 p=b/file;s=p.read_text();old=p.with_name(p.stem+'-original.py');assert not old.exists();old.write_text(s)
 s=s.replace('interval_seconds=2,','interval_seconds=2, process_details_interval_seconds=30,',1)
 s=s.replace("Per-PID RSS double-counts shared mappings. No policy changes.","Per-PID RSS double-counts shared mappings and is sampled every 30 seconds to reduce /proc observer overhead; whole-cgroup usage remains every 2 seconds. No policy changes.",1)
 s=s.replace('    maximum = 0\n','    maximum = 0\n    next_process_sample = 0\n',1)
 a=s.index('        procs = {}\n');z=s.index('        try:\n            code = child.wait',a)
 oldblock=s[a:z]
 core=oldblock[:oldblock.index('        emit(dict(type=')]
 wrapped='        details_sampled = time.monotonic() >= next_process_sample\n        processes = None\n        if details_sampled:\n'+''.join('    '+line if line.strip() else line for line in core.splitlines(True))+'            processes = [procs[pid] for pid in sorted(owned) if pid in procs]\n            next_process_sample = time.monotonic() + 30\n        emit(dict(type="sample", monotonic_ns=time.monotonic_ns(), memory_current_bytes=usage,\n                  process_details_sampled=details_sampled, processes=processes))\n'
 s=s[:a]+wrapped+s[z:];compile(s,str(p),'exec');p.write_text(s)
 print('Updated',file,'before launch; same cgroup interval/workers/budgets')
