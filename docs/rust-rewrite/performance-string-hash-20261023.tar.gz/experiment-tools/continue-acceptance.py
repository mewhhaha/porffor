"""Run source-fenced acceptance after isolated product timing has completed."""
import json,os,subprocess,time
from pathlib import Path
root=Path('/workspace/lila-tooling-next');base=root/'target/performance-hills-20261021-attribution';batch=Path('/tmp/scriptw-performance-batch24')
def run(name):
 with (batch/(name+'.log')).open('x') as f:subprocess.run(['python3','-B',str(batch/(name+'.py'))],cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
assert json.loads((base/'candidate53-runtime-images-preserved-before-native.json').read_text())['complete']
run('prepare-native-storage');run('watch-native-memory')
r=json.loads((base/'candidate53-native-checkpoint/receipt.json').read_text())
assert r['head']=='97036e5a80c165067879cc2e407f15042d7f18d7' and r['source_unchanged'] and r['shared_runtime_linker_unchanged']
assert len(r['cases'])==12 and all(c['state']=='passed' and c['inventory_matches'] and c['exit_code']==0 for c in r['cases'])
assert all(o['failed']==o['ignored']==0 for c in r['cases'] for o in c['outcomes'])
print('Native acceptance complete:',sum(o['passed'] for c in r['cases'] for o in c['outcomes']),'tests; starting original-case replay',flush=True)
with (batch/'string-hash-replay.log').open('x') as f:
 code=subprocess.call(['python3','-B',str(batch/'watch-string-hash-replay.py')],cwd=root,stdout=f,stderr=subprocess.STDOUT)
assert code==1,('Expected four original ordinary failures; inspect exact receipt',code)
r=json.loads((base/'candidate53-string-hash-replay/summary.json').read_text())
assert r['total']==13104 and r['outcomes']==dict(Success=13100,Bug=4,Crash=0,NotImplemented=0)
print('13104-case affected replay complete; final identity/evidence validation pending',flush=True)
