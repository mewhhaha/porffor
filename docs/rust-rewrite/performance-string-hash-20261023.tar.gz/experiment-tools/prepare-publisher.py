from pathlib import Path
old=Path('/tmp/scriptw-performance-batch23/publish-definition.py').read_text()
prefix=old[:old.index("native = read(")].replace('prepared ordinary-definition','cached raw-string-hash').replace('5c63c6597383ba4d6f56e0780daac922798b1033','97036e5a80c165067879cc2e407f15042d7f18d7')
native='''native = read('candidate53-native-checkpoint/receipt.json')
assert native['head'] == SOURCE and native['source_unchanged'] and native['shared_runtime_linker_unchanged']
expected_scopes = {
    ('scriptw-aot-wasm', 'scriptw_aot_wasm'), ('scriptw-aot-wasm', 'structure_builtins'),
    ('scriptw-aot-wasm', 'structure_language'), ('scriptw-engine', 'scriptw_engine'),
    ('scriptw-engine', 'aot_builtins'), ('scriptw-engine', 'aot_language'),
    ('scriptw-engine', 'aot_realm_modules'), ('scriptw-engine', 'aot_gc_entries'),
    ('scriptw-engine', 'aot_native_program_templates'), ('scriptw-engine', 'runtime_cache'),
    ('scriptw-cli', 'cli'), ('scriptw-runtime-image', 'scriptw_runtime_image'),
}
assert len(native['cases']) == 12 and {(c['package'], c['target']) for c in native['cases']} == expected_scopes
assert all(c['state'] == 'passed' and c['exit_code'] == 0 and c['inventory_matches'] for c in native['cases'])
counts = {key: sum(o[key] for c in native['cases'] for o in c['outcomes']) for key in ['passed', 'failed', 'ignored']}
assert counts['passed'] > 3893 and counts['failed'] == counts['ignored'] == 0
assert not subprocess.check_output(['git', 'diff', '--name-only', SOURCE, '--', 'crates', 'Cargo.toml', 'Cargo.lock', 'vendor'], cwd=ROOT)

'''
body=old[old.index('controls = read('):old.index('receipt = dict(schema=')]
body=body.replace('candidate52b','candidate53').replace('candidate52','candidate53').replace('batch23','batch24').replace('candidate53-definition-screen','candidate53-hash-screen').replace('candidate53-definition-confirm','candidate53-hash-confirm').replace('candidate53-definition','candidate53-string-hash').replace('candidate53-extended-source-guards','candidate53-source-guards')
body=body.replace("len(controls['cases']) == 17", "len(controls['cases']) == 18").replace('7174','13104').replace('7170','13100').replace("memory[-1]['exit_code'] == 1", "memory[-1]['exit_code'] == 0")
body=body.replace("['candidate53-native-checkpoint', 'candidate53c-structural-checkpoint', 'candidate53e-native-checkpoint']", "['candidate53-native-checkpoint']")
body=body.replace("['v8_property_definition', 'v8_baseline', 'v8_key_arguments']", "['v8_property_definition', 'v8_baseline', 'v8_repeated_keys', 'v8_string_retention']")
body=body.replace('performance-property-definition-20261023.tar.gz','performance-string-hash-20261023.tar.gz')
# The source-only runner itself is unchanged in this batch; preserve its exact input.
start=body.index("for name in ['scripts/check-source-guards.py'");end=body.index('\ninventory = ',start)
body=body[:start]+"for name in ['scripts/check-source-guards.py', '.cargo/config.toml']:\n    add(ROOT / name, 'verification-inputs/' + name)\n"+body[end:]
# Collect real GC capacity/RSS observations without inventing live-heap counters.
start=body.index('\nassets = {}')
mem='''
retention_memory = {}
report = read('candidate53-hash-confirm/receipt.json')
for file in ['retained-unhashed.js', 'retained-first-hash.js']:
    retention_memory[file] = {}
    for side in ['before', 'after']:
        observations = [row for row in report['observations'] if row['file'] == file and row['side'] == side]
        rounds = []
        for row in observations:
            case, = json.loads((BASE / 'candidate53-hash-confirm' / row['raw']).read_text())['cases']
            samples = [s['memory'] for s in case['observations'] if not s['warmup']]
            assert all(s['process_rss']['status'] == 'sampled' for s in samples)
            rounds.append(dict(gc_capacity_before_bytes=sorted({s['gc_capacity_before_bytes'] for s in samples}),
                gc_capacity_after_bytes=sorted({s['gc_capacity_after_bytes'] for s in samples}),
                median_invocation_max_rss_bytes=median(s['process_rss']['maximum_rss_bytes'] for s in samples),
                whole_child_peak_rss_bytes=row['process']['peak_rss_bytes']))
        retention_memory[file][side] = rounds
'''
body=body[:start]+mem+body[start:]
tail='''receipt = dict(schema='scriptw-string-hash-checkpoint-v1', complete=True,
    published_at=datetime.now(timezone.utc).isoformat(), measured_product_source=SOURCE,
    preceding_product_source='5c63c6597383ba4d6f56e0780daac922798b1033',
    native_counts=counts, native_scopes=sorted(expected_scopes), compiled_semantic_families=18,
    source_equivalence='Product/compiler/fixtures remain exactly the measured source through native and original-case acceptance. Documentation may change after that checkpoint.',
    test262=dict(total=replay['total'], outcomes=replay['outcomes'], known_failures=sorted(known), execution_list_sha256=replay['execution_list_sha256'], full_suite=False),
    paired_cohorts=cohorts, startup_summaries=startup['summaries'], frozen_products=frozen,
    native_memory_completion=memory[-1], replay_memory_completion=replay_memory,
    product_memory_completion=json.loads((BASE / 'candidate53-product-memory.jsonl').read_text().splitlines()[-1]),
    retained_string_memory=retention_memory, performance_admission=read('candidate53-performance-admission.json'),
    fast_source_guards=guards, hill_terminal_count=24, hill_partial_count=7, hill_unresolved_count=129,
    archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive), members=len(assets), inventory_sha256=hashlib.sha256(add_raw).hexdigest()),
    limitations=[
        'Affected release native scopes and original Test262 families; broader release/all-feature acceptance remains open.',
        'All paired screens and confirmation observations, including slower/noisy controls, are retained.',
        'Paired medians are descriptive; no statistical significance or isolated per-change attribution is claimed.',
        'Every StringValue carries an extra i64 payload field even when never hashed; Wasmtime does not expose live/allocation heap counters.',
        'GC capacity and process RSS cannot establish a zero allocation cost; runtime/code/allocator memory are included.',
        'The README V8 table and full-suite graph remain bound to their separately identified source50 reports.',
        'Twenty older shared-memory archives remain unavailable. Newly retired products/runtime payloads have verified workspace archives.',
        'Cargo intentionally retains the existing empty-encoded-Rustflags dependency cohort; normal future builds use restored tracked config.'
    ])
output = archive.with_suffix('').with_suffix('.json')
assert not output.exists(); output.write_text(json.dumps(receipt, indent=2) + '\\n')
print('Published', len(assets), 'verified members;', archive.stat().st_size, 'compressed bytes;', counts, replay['outcomes'])
'''
Path('/tmp/scriptw-performance-batch24/publish-string-hash.py').write_text(prefix+native+body+tail)
