from pathlib import Path
p=Path('/tmp/scriptw-performance-batch24/update-docs.py');s=p.read_text();prior=p.with_name('update-docs-before-fixture-repair.py');assert not prior.exists();prior.write_text(s)
s=s.replace("native=meta['native_counts']['passed'];", "repair_source=meta['native_repair_source']\nnative=meta['native_counts']['passed'];",1)
s=s.replace('Both source/linker fences hold. The 277 source-only guards pass as a fast diagnostic.', '''The original run caught eight stale test expectations: six RegExp fixture
constructors, one completion fixture and one runtime-cache trace assertion.
Their failed receipt remains in the archive. Complete engine-lib and runtime-cache
reruns at `{repair_source[:9]}` repair only those tests; the other ten scopes
retain their source `97036e5a8` results. Each run has its own source/linker fence,
and the exact three-file patch is retained. The mixed production/test file's
production prefix is byte-identical; its conservative compiler fingerprint does
change, so these are separately identified sources. The frozen measured product
and original Test262 replay remain `97036e5a8`. The 277 source-only guards pass
as a fast diagnostic.''',1)
s=s.replace('The next measured candidate is P067 resolved environment access; its earlier\ninline-payload experiment and P024\'s redundant equality guard remain rejected.', '''Before another P067 implementation, profile resolved environment/cell loads:
zero-hop and exact-hop traversal is already statically emitted. Hoisting a cached
handle would need lexical-instance, iteration and resume lifetime proofs. Its
earlier inline-payload experiment and P024's redundant equality guard remain rejected.''',1)
s=s.replace('below remains bound to `b9ecfe64b`.\n[Full-run evidence]', 'below remains bound to `b9ecfe64b`. Native acceptance includes two complete\ntarget reruns after test-only fixture/trace repairs.\n[Full-run evidence]',1)
s=s.replace('executions. No new failures appear. Exact runtime payload identities match.', '''executions. The initial eight stale test expectations are repaired in
`{repair_source[:9]}`; complete engine-lib/runtime-cache reruns pass, while ten
unaffected targets retain their source53 receipts. The measured product and
Test262 remain source53. Exact runtime payload identities match.''',1)
s=s.replace('''1. Evaluate P067 resolved environment depth/handle access using the original
   captured-read/update and closure-construction controls. Restore exact fixtures
   from the existing measured evidence before implementation. Do not repeat the''','''1. Profile P067 resolved environment/cell loads using the original captured-read,
   captured-update and closure-construction controls before proposing a cache:
   exact hop traversal is already unrolled. Restore original fixtures and verify
   receipt labels before comparison. Do not repeat the''',1)
s=s.replace('''277 fast source guards. The **13,104-case original Test262 replay** gives''','''277 fast source guards. Initial stale test expectations are retained in the
failed receipt; complete engine-lib/runtime-cache reruns use the test-only
repair `{repair_source[:9]}`, while the other ten native targets and measured
product retain source53. The **13,104-case original Test262 replay** gives''',1)
p.write_text(s);compile(s,str(p),'exec')
