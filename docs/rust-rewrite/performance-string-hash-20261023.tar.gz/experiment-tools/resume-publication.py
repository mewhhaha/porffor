from pathlib import Path
import json, hashlib, subprocess
root=Path('/workspace/lila-tooling-next');batch=Path('/tmp/scriptw-performance-batch24');base=root/'target/performance-hills-20261021-attribution'
receipt=json.loads((base/'candidate53-string-hash-replay-resume-verification.json').read_text())
assert receipt['summary_unchanged'] and receipt['completed_execution_count']==13104
assert hashlib.sha256((base/'candidate53-string-hash-replay/summary.json').read_bytes()).hexdigest()==receipt['summary_sha256']
for script in ['publish-string-hash.py', 'update-docs.py']:
    subprocess.run(['python3', '-B', str(batch / script)], cwd=root, check=True)
for args in [
    ['python3', '-B', 'scripts/generate-test-graph.py', '--check'],
    ['python3', '-B', 'scripts/status_publication.py', '--check-committed'],
    ['git', 'diff', '--check'],
]:
    subprocess.run(args, cwd=root, check=True)
paths = ['README.md', 'CONTINUE.md', 'docs/performance-hills.md',
         'docs/rust-rewrite/current-inventory.md', 'docs/rust-rewrite/v8-baseline.md',
         'docs/rust-rewrite/performance-string-hash-20261023.json',
         'docs/rust-rewrite/performance-string-hash-20261023.tar.gz']
subprocess.run(['git', 'add', '--sparse', '--', *paths], cwd=root, check=True)
subprocess.run(['git', 'commit', '-m', 'Accept cached String hashes with complete affected conformance evidence'], cwd=root, check=True)
subprocess.run(['bash', 'scripts/check-readme-status-artifacts.sh', 'HEAD^'], cwd=root, check=True)
subprocess.run(['git', 'push', 'origin', 'HEAD:main'], cwd=root, check=True)
subprocess.run(['git', 'ls-remote', 'origin', 'refs/heads/main'], cwd=root, check=True)
print('String-hash checkpoint published and pushed', flush=True)
