#!/bin/bash
set -euo pipefail
cd /workspace/lila-tooling-next
. /workspace/.scriptw-tools/activate.sh
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER SCRIPTW_TEST_NO_INCREMENTAL SCRIPTW_TEST_KEEP_INTL_INCREMENTAL
export TMPDIR=/tmp CARGO_TARGET_DIR=/workspace/porffor/target
# Reuse the prior measured product's exact dependency/codegen flags.
export CARGO_ENCODED_RUSTFLAGS=''
export SCRIPTW_BUILD_MODULE_CACHE_DIR=/tmp/scriptw-performance-build-module-cache
export SCRIPTW_TEST_CODEGEN_JOBS=auto
export RUSTC_WRAPPER=/workspace/lila-tooling-next/scripts/test-shared-runtime-images/preserve-output-rustc
export SCRIPTW_PRESERVED_OUTPUT_INVENTORY=/workspace/lila-tooling-next/target/performance-hills-20261021-attribution/candidate53-preserved-output-inventory.json
export SCRIPTW_OUTPUT_PROTECTION_LOG=/workspace/lila-tooling-next/target/performance-hills-20261021-attribution/candidate53-output-detach-intents.jsonl
python3 -B /tmp/scriptw-performance-batch24/prepare-product-build.py
python3 -B scripts/limited_verification.py --cloud --cloud-cpus auto -- cargo build --release --timings --locked --offline -p scriptw-cli --bin scriptw --example runtime_baseline --message-format=json-render-diagnostics > target/performance-hills-20261021-attribution/candidate53-product-cargo.jsonl 2> target/performance-hills-20261021-attribution/candidate53-product-build.log
