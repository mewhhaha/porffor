"""Freeze actual Cargo-produced static CLI/runner, retaining source and old bytes."""
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

root = Path('/workspace/lila-tooling-next')
base = root / 'target/performance-hills-20261021-attribution'
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True)
log = base / 'candidate53-product-cargo.jsonl'
rows = [json.loads(line) for line in log.read_text().splitlines()]
assert rows[-1]['reason'] == 'build-finished' and rows[-1]['success']
dest = Path('/tmp') / ('scriptw-performance-candidate-' + commit[:9])
dest.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen = []
for name, kind in [('scriptw', 'bin'), ('runtime_baseline', 'example')]:
    producers = [r for r in rows if r.get('reason') == 'compiler-artifact' and r.get('executable')
                 and r['target']['name'] == name and kind in r['target']['kind']]
    assert len(producers) == 1 and not producers[0]['fresh']
    p = Path(producers[0]['executable'])
    digest = sha(p)
    stat = p.stat()
    target = dest / name
    shutil.copy2(p, target)
    assert sha(target) == digest
    aliases = {p}
    parent = p.parent / 'deps' if kind == 'bin' else p.parent
    aliases.update(q for q in parent.glob(name + '-*') if q.is_file() and q.samefile(p))
    for alias in sorted(aliases):
        frozen.append(dict(original=str(alias), storage=str(target), bytes=stat.st_size,
                           sha256=digest, mtime_ns=stat.st_mtime_ns))
        alias.unlink()
        alias.symlink_to(target)
    sections = subprocess.check_output(['readelf', '--wide', '--sections', str(target)])
    assert b'.debug_info' not in sections and b'.symtab' in sections
    dynamic = subprocess.check_output(['readelf', '--wide', '--dynamic', str(target)])
    assert b'scriptw_runtime' not in dynamic
    (base / ('candidate53-' + name + '-readelf-sections.txt')).write_bytes(sections)
    (base / ('candidate53-' + name + '-readelf-dynamic.txt')).write_bytes(dynamic)
    print('Frozen', name, stat.st_size, digest, flush=True)
out = base / 'candidate53-product-frozen.json'
assert not out.exists()
out.write_text(json.dumps(frozen, indent=2) + '\n')
for row in json.loads((base / 'candidate53-preserved-output-inventory.json').read_text())['files']:
    assert sha(Path(row['storage'])) == row['sha256'], row
timing = max(Path('/workspace/porffor/target/cargo-timings').glob('cargo-timing-*.html'), key=lambda p: p.stat().st_mtime_ns)
shutil.copyfile(timing, base / 'candidate53-product-timings.html')
print('All inventoried older payloads remain exact; current source', commit, flush=True)
