from pathlib import Path
b=Path('/tmp/scriptw-performance-batch24')
s=(b/'prepare-native.py').read_text().replace('candidate53-native-preserved','candidate53b-native-preserved')
(b/'prepare-native-repair.py').write_text(s)
s=(b/'native-checkpoint.sh').read_text().replace('candidate53-native','candidate53b-native').replace('batch24/prepare-native.py','batch24/prepare-native-repair.py')
start=s.index(' --only-targets ');end=s.index(' --output ',start)
s=s[:start]+' --only-targets scriptw-engine:scriptw_engine scriptw-engine:runtime_cache'+s[end:]
s=s.replace(' --partition-cli --partition-native-target scriptw-aot-wasm:scriptw_aot_wasm','')
(b/'native-repair.sh').write_text(s)
s=(b/'watch-native-memory.py').read_text().replace('candidate53-native','candidate53b-native').replace('batch24/native-checkpoint.sh','batch24/native-repair.sh')
(b/'watch-native-repair.py').write_text(s)
print((b/'native-repair.sh').read_text())
