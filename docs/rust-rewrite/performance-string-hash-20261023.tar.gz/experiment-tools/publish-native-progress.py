"""Record native-verified progress while the frozen original-case replay runs."""
from pathlib import Path
import json
r=Path('/workspace/lila-tooling-next');base=r/'target/performance-hills-20261021-attribution'
a=json.loads((base/'candidate53-native-checkpoint/receipt.json').read_text());b=json.loads((base/'candidate53b-native-checkpoint/receipt.json').read_text())
scopes={('scriptw-engine','scriptw_engine'),('scriptw-engine','runtime_cache')}
assert a['head']=='97036e5a80c165067879cc2e407f15042d7f18d7'
assert all(x['source_unchanged'] and x['shared_runtime_linker_unchanged'] for x in [a,b])
assert len(b['cases'])==2 and {(c['package'],c['target']) for c in b['cases']}==scopes
cases=[c for c in a['cases'] if (c['package'],c['target']) not in scopes]+b['cases']
assert len(cases)==12 and all(c['state']=='passed' and c['inventory_matches'] and c['exit_code']==0 for c in cases)
counts={k:sum(o[k] for c in cases for o in c['outcomes']) for k in ['passed','failed','ignored']};assert counts==dict(passed=4083,failed=0,ignored=0)
repair=b['head'];print('Validated native union',counts,'repair',repair)
start='<!-- scriptw-string-hash-progress:start -->';end='<!-- scriptw-string-hash-progress:end -->'
def insert(path,anchor,body):
 p=r/path;s=p.read_text();assert start not in s and s.count(anchor)==1
 block=start+'\n'+body.strip()+'\n'+end+'\n\n'
 s=s.replace(anchor,block+anchor,1);p.write_text(s)
insert('README.md','The newer `5c63c6597` checkpoint passes',f'''The `97036e5a8` string-hash change has passed **4,083 native tests** across twelve
affected targets and eighteen compiled semantic families. Native acceptance
includes test-only repairs at `{repair[:9]}`. Its **13,104-case Test262 replay is
running**; the full-suite chart and published benchmark table below/above retain
their separately identified sources. [Progress](CONTINUE.md#next-performance-work).''')
insert('CONTINUE.md','The 160-hill backlog has',f'''Current batch awaiting Test262 acceptance: **`97036e5a8`**, cached raw String
hashes and runtime layout 16. Native verification is complete: **4,083 passed /
zero failed / zero ignored** across twelve affected release scopes. The initial
eight stale fixture/trace expectations remain recorded; test-only repair
**`{repair[:9]}`** passes the entire engine-lib and runtime-cache targets, joined
with the ten unchanged passing targets. Eighteen compiled semantic families pass.
The frozen product's **13,104 original Test262 executions are running** with four
workers and original budgets. P023/P112 stay pending and counts below remain the
last fully published checkpoint until the replay and portable evidence validate.

Active driver: `/tmp/scriptw-performance-batch24/repair-and-continue.py`.
Receipts and replay: `target/performance-hills-20261021-attribution/candidate53*`.
The complete new native result uses `candidate53b-native-checkpoint/receipt.json`
for the two repaired scopes and `candidate53-native-checkpoint/receipt.json` for
the other ten; never erase or reclassify the initial eight failures. Finish with
`publish-string-hash.py` and `update-docs.py` under the same batch directory,
validate generated status artifacts, then push the evidence/documentation update.
Product/benchmark/replay identity remains source53; native repair identity is
separate. Next attribution notes are in that directory's `next-batch-notes.md`.''')
p=r/'docs/rust-rewrite/current-inventory.md';s=p.read_text();anchor='## Current work\n';assert s.count(anchor)==1
s=s.replace(anchor,anchor+'\n'+start+f'''\n### Native-verified string-hash batch; original-case replay pending

Product `97036e5a8` adds cached raw String hashes (layout 16). All **4,083 tests**
across twelve affected native release scopes and eighteen compiled semantic
families pass. Two native scopes use test-only repair `{repair[:9]}` after eight
stale fixture/trace assertions; their original failed evidence is preserved.
The **13,104-case Test262 replay is running** on the unchanged frozen product.
P023/P112 and published ledger totals remain pending that acceptance and evidence
publication. [Continuation](../../CONTINUE.md#next-performance-work).
'''+end+'\n',1);p.write_text(s)
