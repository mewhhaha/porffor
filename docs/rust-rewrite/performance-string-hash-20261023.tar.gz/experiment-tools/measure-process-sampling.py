"""Compare read-only process discovery on this active native checkpoint."""
from pathlib import Path
import json,time,statistics
root=2590822

def status(pid):
 try:
  s=dict(line.split(':',1) for line in (Path('/proc')/str(pid)/'status').read_text().splitlines())
  return dict(pid=pid,ppid=int(s['PPid']),name=s['Name'].strip(),rss_bytes=int(s.get('VmRSS','0 kB').split()[0])*1024,threads=int(s['Threads']))
 except (OSError,KeyError,ValueError): return None

def all_processes():
 procs={int(p.name):v for p in Path('/proc').iterdir() if p.name.isdigit() and (v:=status(int(p.name))) is not None}
 owned={root}
 while True:
  n=owned|{pid for pid,v in procs.items() if v['ppid'] in owned}
  if n==owned:break
  owned=n
 return {pid:procs[pid] for pid in owned if pid in procs}

def descendants():
 pending=[root];seen=set();procs={}
 while pending:
  pid=pending.pop()
  if pid in seen: continue
  seen.add(pid)
  v=status(pid)
  if v is None:continue
  procs[pid]=v
  try:
   for task in (Path('/proc')/str(pid)/'task').iterdir():
    try:pending.extend(map(int,(task/'children').read_text().split()))
    except OSError:pass
  except OSError:pass
 return procs
rows=[]
for _ in range(5):
 row={}
 for name,fn in [('all',all_processes),('tree',descendants)]:
  t=time.perf_counter_ns();result=fn();row[name]=dict(ns=time.perf_counter_ns()-t,pids=sorted(result))
 row['same_members']=row['all']['pids']==row['tree']['pids'];rows.append(row)
out=dict(root=root,observations=rows,median_ns={k:statistics.median(x[k]['ns'] for x in rows) for k in ['all','tree']},boundary='Read-only process discovery only, not product performance; processes can enter/exit between snapshots.')
path=Path('/workspace/lila-tooling-next/target/performance-hills-20261021-attribution/candidate53-process-sampling-diagnostic.json');path.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
