"""Publish prose only after the complete source-bound evidence is validated."""
import json
from pathlib import Path
r=Path('/workspace/lila-tooling-next')
meta=json.loads((r/'docs/rust-rewrite/performance-string-hash-20261023.json').read_text());assert meta['complete'] and meta['measured_product_source']=='97036e5a80c165067879cc2e407f15042d7f18d7'
repair_source=meta['native_repair_source']
native=meta['native_counts']['passed'];assert meta['native_counts']['failed']==meta['native_counts']['ignored']==0
assert meta['test262']['outcomes']==dict(Success=13100,Bug=4,Crash=0,NotImplemented=0)
# Retire only the explicitly marked interim progress paragraphs.
for name in ['README.md', 'CONTINUE.md', 'docs/rust-rewrite/current-inventory.md']:
    p = r / name
    text = p.read_text()
    start = '<!-- scriptw-string-hash-progress:start -->'
    end = '<!-- scriptw-string-hash-progress:end -->'
    assert text.count(start) == text.count(end) == 1
    first = text.index(start)
    last = text.index(end, first) + len(end)
    text = text[:first] + text[last:].lstrip('\n')
    p.write_text(text)
link='docs/rust-rewrite/v8-baseline.md#cached-string-hash-checkpoint--published-2026-10-23'
cohort=meta['paired_cohorts']['candidate53-hash-confirm'];cases={x['file']:x for x in cohort}
def ms(v):return f"{v/1e6:,.3f}"
def change(row):return 100*(row['after']['median_ns']/row['before']['median_ns']-1)
rows='\n'.join(f"| `{x['file']}` | {ms(x['before']['median_ns'])} | {ms(x['after']['median_ns'])} | {change(x):+.1f}% |" for x in cohort)
startup=meta['startup_summaries']
def start(mode,side,key):return startup[mode][side][key]['median_of_round_medians']
section=f'''## Cached string-hash checkpoint — published 2026-10-23

Source `97036e5a8` closes **P023 and P112** against the frozen accepted
`5c63c6597` baseline. StringValue lazily stores the raw UTF-16 hash once, and
property/Map/Set users reuse it before their existing tag mixing. Pooled literals
and dynamically created strings share this path. First-use hashing still occurs;
equality still checks identity/content independently of the hash. A legitimate
zero hash is recomputed without changing the result. This is runtime metadata,
not an exposed property or a second string representation.

Layout **16** appends an i64 field to every StringValue, including strings never
used as keys. Compiler-owned publication and all three host syntax constructors
initialize it to zero; host admission checks its type/mutability and rejects
layout 15. Code-unit writes remain confined to private construction; publication
consumes that construction object. The Wasm array type itself remains mutable.

[Portable metadata](performance-string-hash-20261023.json) and the
[byte-verified raw archive](performance-string-hash-20261023.tar.gz) preserve
all screens, paired observations, exact product/source identities, native and
Test262 receipts, memory observations and storage histories. The benchmark code
is checked in under `v8_repeated_keys`, `v8_string_retention`,
`v8_property_definition` and `v8_baseline` in the CLI fixtures.

The idle-machine comparison pins both products to one CPU. Each ABBA round
uses seven measured invocations after ten warmups in fresh Stores/Realms;
Node checks the workload stdout. The table is the median of two round medians
per side, in milliseconds, and includes setup and checksums. It is descriptive,
not a statistical significance test or an isolated estimate of hash-loop cost.
The separate three-sample screen, including its slower observations, is retained.

| Workload | Before | After | Median change |
| --- | ---: | ---: | ---: |
{rows}

Repeated long property reads improve about 83%; long Map/Set lookups about
53–54%. Long-key define-own also benefits. Short/numeric controls have overlapping
rounds, so this does not establish a universal speedup. The retained-unhashed and
first-hash controls have **5.8% / 3.2% higher medians**, respectively, with overlapping
rounds; retained object rows have a **2.5% higher median**, also with overlapping rounds. These costs are retained
in the acceptance decision. Every string pays the added field cost even where
no speed benefit is possible.

The two 32,768-string controls grow reported GC capacity from 16 to 32 MiB on
both products. That coarse capacity is not live heap or allocation bytes, and
cannot establish zero memory overhead. The raw records include sampled invocation
RSS and whole-child peak RSS; they also include runtime/code/allocator overhead.
Wasmtime exposes no live-GC/allocation counter through this profiling boundary.

The CLI grows by **169,104 bytes (0.16 MiB)**. The separate 56-fresh-process
startup ABBA gives cold **{ms(start('cold','before','elapsed_ns'))} → {ms(start('cold','after','elapsed_ns'))} ms**
and cached **{ms(start('hot','before','elapsed_ns'))} → {ms(start('hot','after','elapsed_ns'))} ms**.
Cold rounds overlap; do not attribute those whole-process differences entirely
to hashing. Cold RSS medians are {start('cold','before','peak_rss_bytes')/2**20:.2f} → {start('cold','after','peak_rss_bytes')/2**20:.2f} MiB,
cached {start('hot','before','peak_rss_bytes')/2**20:.2f} → {start('hot','after','peak_rss_bytes')/2**20:.2f} MiB.
Application caches are empty/prewarmed as labelled; OS caches are not flushed.
The ordinary V8 comparison above remains the separately measured source50 cohort.

The release product builds in **6m23s**. All **18 compiled semantic families**
pass, including exact UTF-16, equal-but-distinct strings, cross-property/Map/Set
use, collisions, GC, deletion/reinsertion and descriptor semantics. All
**{native:,} native tests / zero failures / zero ignored** pass across the twelve
recorded affected release scopes, including GC entries, native program templates
and runtime-cache controls. The independent runtime producer matches all payload
bytes; its generated include wrapper differs only in the producer directory.
The original run caught eight stale test expectations: six RegExp fixture
constructors, one completion fixture and one runtime-cache trace assertion.
Their failed receipt remains in the archive. Complete engine-lib and runtime-cache
reruns at `{repair_source[:9]}` repair only those tests; the other ten scopes
retain their source `97036e5a8` results. Each run has its own source/linker fence,
and the exact three-file patch is retained. The mixed production/test file's
production prefix is byte-identical; its conservative compiler fingerprint does
change, so these are separately identified sources. The frozen measured product
and original Test262 replay remain `97036e5a8`. Both repaired runtime packages
have byte-identical full Wasm payloads/runtime keys and serialized native code;
only their source fields and dependent package/manifest checksums change. The 277 source-only guards pass
as a fast diagnostic.

The original **13,104-execution Test262 replay** covers complete Map, Set, String,
Object, Reflect, object-expression and string-literal families, plus all four
tracked failures: **13,100 Success / four known Bug / zero Crash /
zero NotImplemented**. It changes no case IDs, worker counts, deadlines or outcomes.
This is affected-family acceptance, not a new complete Test262 run; the README
full chart remains source `b9ecfe64b`.

One storage preparation attempt stopped before native compilation because its
inventory expected four old executables, but one old product contained a single
larger CLI; the exact three-file inventory corrected that bookkeeping assumption.
The failed launch/log and successful continuation remain in the raw archive.
The first publication check also stopped on changed native staging hashes.
The test-only repair had refreshed source metadata through two shared mutable
package aliases. Both repaired outputs were archived and verified; the original
product aliases were restored from their verified pre-build archive. Frozen
executables and all completed tests were unaffected. The source-transition
receipt validates complete payload identity and the precise header/checksum
differences. Atomic producer publication is the next tooling repair before any
new Cargo build; cached diagnostic linking runs no producer.

Closed products, runtime payloads, private measurement caches and diagnostic
executables are losslessly archived and all members verified before retirement.
Dependency libraries remain available through verified storage aliases, protected
against dirty rustc writers; the two-GiB Cargo reserve and 256-MiB-per-process
scratch requirements are unchanged. Twenty older shared-memory archives remain
unavailable as previously documented; none of these new archives uses that storage.

The ledger now has **25 terminal decisions, seven partial and 128 unresolved**.
Broader release/all-feature, retention and full-suite acceptance remain open.
Before another P067 implementation, profile resolved environment/cell loads:
zero-hop and exact-hop traversal is already statically emitted. Hoisting a cached
handle would need lexical-instance, iteration and resume lifetime proofs. Its
earlier inline-payload experiment and P024's redundant equality guard remain rejected.

'''
p=r/'docs/rust-rewrite/v8-baseline.md';s=p.read_text();anchor='## Prepared property-definition checkpoint';assert s.count(anchor)==1;s=s.replace(anchor,section+anchor,1);p.write_text(s)
p=r/'README.md';s=p.read_text();start=s.index('The newer `5c63c6597` property-definition change');end=s.index('[Prioritized performance backlog]',start)
s=s[:start]+'''The newer `97036e5a8` string-hash cache improves paired long-key property reads
about 83% and Map/Set lookups about 53–54%. Every string carries an extra i64 field;
two retention controls have 3–6% higher medians, with overlapping rounds.
[Measurements and tradeoffs](docs/rust-rewrite/v8-baseline.md#cached-string-hash-checkpoint--published-2026-10-23).
'''+s[end:]
start=s.index('The newer `5c63c6597` checkpoint passes');end=s.index('\n<!-- scriptw-test-graph:start -->',start)
s=s[:start]+f'''The newer `97036e5a8` checkpoint passes **{native:,} native tests** across twelve
affected targets and eighteen compiled semantic families. Its **13,104-case
Test262 replay** has **13,100 passes and the same four failures**; the full chart
below remains bound to `b9ecfe64b`. Native acceptance includes two complete
target reruns after test-only fixture/trace repairs.
[Full-run evidence](docs/rust-rewrite/test262-current.md) ·
[Latest checkpoint]({link}).
'''+s[end:];p.write_text(s)
p=r/'CONTINUE.md';s=p.read_text().replace('**23 terminal decisions, seven partial/open outcomes,\n130 proposed/unresolved**','**25 terminal decisions, seven partial/open outcomes,\n128 proposed/unresolved**',1)
start=s.index('Latest accepted product:');end=s.index('**The fresh full Test262 campaign',start)
s=s[:start]+f'''Latest accepted product: **`97036e5a8`**. Cached raw String hashes close P023/P112:
**{native:,} native passes / zero failures / zero ignored** across twelve affected
release scopes, eighteen compiled semantic families, and **13,100 Success / four
known Bug / zero Crash / zero NotImplemented** in 13,104 original affected Test262
executions. The initial eight stale test expectations are repaired in
`{repair_source[:9]}`; complete engine-lib/runtime-cache reruns pass, while ten
unaffected targets retain their source53 receipts. The measured product and
Test262 remain source53. Exact runtime payload identities match.
[Measurements and raw evidence]({link}) retain all slower/noisy controls:
long property reads improve about 83%, Map/Set long lookups 53–54%; every string
pays an extra i64 field and two retention medians rise 3–6% with overlapping rounds.
The CLI grows 0.16 MiB. Full-suite graph and V8 table remain their separate source50
cohorts. P020 was closed by the preceding property-definition checkpoint.

'''+s[end:]
s=s.replace('Source52 is the next direct baseline;', 'Source53 is the next direct baseline;')
start=s.index('1. Evaluate P023/P112');end=s.index('2. Promote the standalone emitter',start)
s=s[:start]+'''1. Complete P001/P002 retained-row attribution using the existing row-size,
   width and pass-count corpus. Align optional CPU sampling with the existing
   execution/completion span, outside setup and warmups. Measure any diagnostic
   boundary overhead. A named traversal function alone is not traversal-only
   elapsed time; keep construction in the published ordinary invocation score.
   Preserve fresh Stores. The existing 43-case attribution corpus already covers
   calls, properties, typed arrays and JSON; do not duplicate P011-P013 families.
   P067 already emits exact hop traversal; profile cell loads before caching
   handles across lexical/iteration/resume changes.
'''+s[end:]
s=s.replace('/tmp/scriptw-performance-batch23','/tmp/scriptw-performance-batch24');p.write_text(s)
p=r/'docs/performance-hills.md';s=p.read_text();intro=f'''The [cached string-hash checkpoint](rust-rewrite/v8-baseline.md#cached-string-hash-checkpoint--published-2026-10-23)
at `97036e5a8` closes **P023/P112**; including the separate completed P003\nanalysis, the ledger is **25 terminal / seven
partial / 128 unresolved**. Paired long property reads improve about 83% and
Map/Set long lookups about 53–54%. Every string carries an extra i64 field;
retention medians rise 3–6% with overlapping rounds and the CLI grows 0.16 MiB.
All {native:,} affected native tests, eighteen compiled semantic families and
13,104 original Test262 executions are verified, with exactly the same four
ordinary failures. Raw slower observations and costs remain in the linked evidence.

'''
s=s.replace('This separate diagnostic brings the ledger to\n**23 terminal / seven partial / 130 unresolved**; P023/P112 remain pending their\noriginal-case replay and final publication.', 'This separate diagnostic brought the ledger to\n**23 terminal / seven partial / 130 unresolved**, before the subsequent\nstring-hash checkpoint.')
s=s.replace('## Progress ledger\n\n','## Progress ledger\n\n'+intro,1).replace('The ledger is now **22 terminal /','That checkpoint brought the ledger to **22 terminal /',1)
row='| P023 / P112 | **Verified shared string-hash reuse with storage costs** | Layout 16 caches raw UTF-16 hashes for immutable pooled/dynamic strings across property and Map/Set users, leaving tag mixing and equality separate. Long property/Map/Set lookup medians fall about 83%/53%/54%; every string pays an i64 field and retention medians rise 3–6% with overlapping rounds. [Acceptance and raw evidence](rust-rewrite/v8-baseline.md#cached-string-hash-checkpoint--published-2026-10-23). |\n'
s=s.replace('| --- | --- | --- |\n','| --- | --- | --- |\n'+row,1)
s=s.replace('Existing immutable StoredValue snapshots and layout 15 remain; resolved depth/handle caching is still open.', 'Existing immutable StoredValue snapshots remain; resolved depth/handle caching is still open. The later unrelated string-hash change uses layout 16.')
s=s.replace('| P023 | A / E / M | Reuse precomputed hashes for static/interned property keys where absent. | Repeated fixed-key reads/writes; string/symbol equality and collisions stay correct. |','| P023 | A / E / M | **Verified:** reuse prepared raw hashes for pooled and other immutable property-key strings. | Shared lazy cache; first use computes the hash, equality stays independent. See the source53 checkpoint and its explicit storage/retention costs. |')
s=s.replace('| P112 | C / E / M | Reuse immutable string hashes across collection operations where not already retained. | Repeated key workloads; hashes are never equality and equal strings from distinct origins still match. |','| P112 | C / E / M | **Verified:** reuse immutable string hashes across Map/Set operations. | Long repeated lookups improve about 53–54%; equal-but-distinct content, GC and cross-property reuse pass. Storage/retention tradeoffs stay explicit in the source53 checkpoint. |');p.write_text(s)
p=r/'docs/rust-rewrite/current-inventory.md';s=p.read_text();anchor=s.index('## Current work\n')+len('## Current work\n')
entry=f'''
### Latest affected checkpoint — cached string hashes, 2026-10-23

Source **`97036e5a8`**, runtime layout **16**, passes **{native:,} native tests**
across twelve affected release scopes, eighteen compiled semantic families and
277 fast source guards. Initial stale test expectations are retained in the
failed receipt; complete engine-lib/runtime-cache reruns use the test-only
repair `{repair_source[:9]}`, while the other ten native targets and measured
product retain source53. The **13,104-case original Test262 replay** gives
**13,100 Success / four known Bug / zero Crash / zero NotImplemented**.
This closes P023/P112 with explicit string-storage and retention timing costs;
[measurements and exact evidence](v8-baseline.md#cached-string-hash-checkpoint--published-2026-10-23).
The ledger is **25 terminal / seven partial / 128 unresolved**. Broader acceptance
remains open. The full-suite chart and V8 comparison below remain source50;
source52 and earlier checkpoint details are historical evidence.
'''
s=s.replace('Latest accepted product: **`5c63c6597`**', 'Previous accepted product: **`5c63c6597`**', 1).replace('Counts are **22 terminal decisions / seven partial / 131 unresolved** of 160 hills.', 'At that preceding checkpoint, counts were **22 terminal / seven partial / 131 unresolved**.', 1)
s=s[:anchor]+entry+s[anchor:];p.write_text(s)
print('Updated current docs from completed source53 evidence; full chart/V8 cohort preserved')
