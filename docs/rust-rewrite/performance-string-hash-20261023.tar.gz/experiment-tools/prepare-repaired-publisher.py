from pathlib import Path
p=Path('/tmp/scriptw-performance-batch24/publish-string-hash.py');s=p.read_text();original=p.with_name('publish-string-hash-before-fixture-repair.py');assert not original.exists();original.write_text(s)
s=s.replace("assert all(c['state'] == 'passed' and c['exit_code'] == 0 and c['inventory_matches'] for c in native['cases'])",'''# Preserve the failed run; replace only the two complete repaired test scopes.
initial_native = native
repair = read('candidate53b-native-checkpoint/receipt.json')
assert repair['source_unchanged'] and repair['shared_runtime_linker_unchanged']
repair_source = repair['head']
repair_scopes = {('scriptw-engine', 'scriptw_engine'), ('scriptw-engine', 'runtime_cache')}
assert len(repair['cases']) == 2 and {(c['package'], c['target']) for c in repair['cases']} == repair_scopes
assert {(c['package'], c['target']) for c in initial_native['cases'] if c['state'] == 'failed'} == repair_scopes
assert sum(o['failed'] for c in initial_native['cases'] for o in c['outcomes']) == 8
native = dict(cases=[c for c in initial_native['cases'] if (c['package'], c['target']) not in repair_scopes] + repair['cases'])
assert len(native['cases']) == 12 and {(c['package'], c['target']) for c in native['cases']} == expected_scopes
assert all(c['state'] == 'passed' and c['exit_code'] == 0 and c['inventory_matches'] for c in native['cases'])
repair_paths = {
    'crates/scriptw-engine/src/runtime_regexp_compiler_tests.rs',
    'crates/scriptw-engine/src/wasm_gc_completion.rs',
    'crates/scriptw-engine/tests/runtime_cache/runtime_artifact_cache.rs',
}
changed = set(subprocess.check_output(['git', 'diff', '--name-only', SOURCE, repair_source], cwd=ROOT, text=True).splitlines())
assert changed == repair_paths
shared_path = 'crates/scriptw-engine/src/wasm_gc_completion.rs'
old = subprocess.check_output(['git', 'show', SOURCE + ':' + shared_path], cwd=ROOT)
new = subprocess.check_output(['git', 'show', repair_source + ':' + shared_path], cwd=ROOT)
assert old.split(b'#[cfg(test)]\\nmod tests {', 1)[0] == new.split(b'#[cfg(test)]\\nmod tests {', 1)[0]
assert b'#[cfg(test)]\\nmod runtime_regexp_compiler_tests;' in (ROOT / 'crates/scriptw-engine/src/lib.rs').read_bytes()
repair_patch = subprocess.check_output(['git', 'diff', SOURCE, repair_source, '--', *sorted(repair_paths)], cwd=ROOT)
assert repair_patch == (BASE / 'candidate53b-fixture-repair.patch').read_bytes()''',1)
s=s.replace("['git', 'diff', '--name-only', SOURCE, '--', 'crates'", "['git', 'diff', '--name-only', repair_source, '--', 'crates'",1)
s=s.replace("assert memory[-1]['type'] == 'completion' and memory[-1]['exit_code'] == 0", """assert memory[-1]['type'] == 'completion' and memory[-1]['exit_code'] != 0
repair_memory = [json.loads(line) for line in (BASE / 'candidate53b-native-memory.jsonl').read_text().splitlines()][-1]
assert repair_memory['type'] == 'completion' and repair_memory['exit_code'] == 0
assert all(repair_memory['memory_events_delta'].get(k, 0) == 0 for k in ['oom', 'oom_kill', 'oom_group_kill'])""",1)
s=s.replace("for directory in ['candidate53-native-checkpoint']:","for directory in ['candidate53-native-checkpoint', 'candidate53b-native-checkpoint']:")
s=s.replace("native_counts=counts, native_scopes=sorted(expected_scopes), compiled_semantic_families=18,", """native_counts=counts, native_scopes=sorted(expected_scopes), compiled_semantic_families=18,
    native_repair_source=repair_source, native_repair_scopes=sorted(repair_scopes),
    native_repair_patch_sha256=hashlib.sha256(repair_patch).hexdigest(),
    native_scope_sources=[dict(package=c['package'], target=c['target'], source=repair_source if (c['package'], c['target']) in repair_scopes else SOURCE) for c in native['cases']],""",1)
s=s.replace("source_equivalence='Product/compiler/fixtures remain exactly the measured source through native and original-case acceptance. Documentation may change after that checkpoint.',", """source_equivalence='Frozen product, benchmark and Test262 use the measured source. Ten native targets use that source; complete engine-lib and runtime-cache reruns use a separately recorded test-only repair. The three-file diff is preserved; the production prefix of the mixed test/production file is byte-identical. That mixed file conservatively changes the compiler fingerprint, so no equal-fingerprint claim is made.',""",1)
s=s.replace("native_memory_completion=memory[-1], replay_memory_completion=replay_memory,", "initial_native_memory_completion=memory[-1], native_repair_memory_completion=repair_memory, replay_memory_completion=replay_memory,",1)
s=s.replace("'.executions', '.attempts'}","'.executions', '.attempts', '.patch'}",1)
p.write_text(s)
compile(s,str(p),'exec')
