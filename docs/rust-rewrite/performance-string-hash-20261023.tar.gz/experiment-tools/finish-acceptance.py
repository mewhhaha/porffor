"""Run source-fenced acceptance after isolated product timing has completed."""
import json,os,subprocess,time
from pathlib import Path
root=Path('/workspace/lila-tooling-next');base=root/'target/performance-hills-20261021-attribution';batch=Path('/tmp/scriptw-performance-batch24')
gate=base/'candidate53-product-timing-gates-complete.json'
while not gate.exists():
 live=False
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   if str(batch/'product-and-timing-gates.py').encode() in (p/'cmdline').read_bytes().split(b'\0'):live=True;break
  except OSError:pass
 assert live,'Timing driver stopped; inspect preserved failure evidence'
 time.sleep(2)
assert json.loads(gate.read_text())['complete']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
def run(name):
 with (batch/(name+'.log')).open('x') as f:subprocess.run(['python3','-B',str(batch/(name+'.py'))],cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
run('preserve-runtime-space');run('prepare-native-storage');run('watch-native-memory')
r=json.loads((base/'candidate53-native-checkpoint/receipt.json').read_text())
assert r['head']=='97036e5a80c165067879cc2e407f15042d7f18d7' and r['source_unchanged'] and r['shared_runtime_linker_unchanged']
assert len(r['cases'])==12 and all(c['state']=='passed' and c['inventory_matches'] and c['exit_code']==0 for c in r['cases'])
assert all(o['failed']==o['ignored']==0 for c in r['cases'] for o in c['outcomes'])
print('Native acceptance complete:',sum(o['passed'] for c in r['cases'] for o in c['outcomes']),'tests; starting original-case replay',flush=True)
with (batch/'string-hash-replay.log').open('x') as f:
 code=subprocess.call(['python3','-B',str(batch/'watch-string-hash-replay.py')],cwd=root,stdout=f,stderr=subprocess.STDOUT)
assert code==1,('Expected four original ordinary failures; inspect exact receipt',code)
r=json.loads((base/'candidate53-string-hash-replay/summary.json').read_text())
assert r['total']==13104 and r['outcomes']==dict(Success=13100,Bug=4,Crash=0,NotImplemented=0)
print('13104-case affected replay complete; final identity/evidence validation pending',flush=True)
