from pathlib import Path
import difflib
root=Path('/workspace/lila-tooling-next')
changes={}
p='crates/scriptw-engine/src/runtime_regexp_compiler_tests.rs';old=(root/p).read_text();new=old.replace('use super::*;\n','use super::*;\nuse scriptw_aot_wasm::{GcHostField, GcHostLayout};\n',1).replace('        assert_eq!(string_type.fields().len(), 1);\n        let field = string_type.field(0).unwrap();','''        assert_eq!(
            Some(string_type.fields().len() as u32),
            GcHostLayout::String.field_count()
        );
        let cached_hash = string_type
            .field(GcHostField::StringRawKeyHash.definition().index() as usize)
            .unwrap();
        assert_eq!(cached_hash.mutability(), wasmtime::Mutability::Var);
        assert!(matches!(
            cached_hash.element_type(),
            wasmtime::StorageType::ValType(wasmtime::ValType::I64)
        ));
        let field = string_type
            .field(GcHostField::StringCodeUnits.definition().index() as usize)
            .unwrap();''',1).replace('&[WasmtimeVal::from(units)],','&[WasmtimeVal::from(units), WasmtimeVal::I64(0)],',1);assert new!=old;changes[p]=(old,new)
p='crates/scriptw-engine/src/wasm_gc_completion.rs';old=(root/p).read_text();start,tests=old.split('#[cfg(test)]\nmod tests {',1);updated=tests.replace('''            [FieldType::new(
                Mutability::Const,
                StorageType::ValType(ValType::Ref(RefType::new(
                    false,
                    HeapType::ConcreteArray(array_ty),
                ))),
            )],''','''            [
                FieldType::new(
                    Mutability::Const,
                    StorageType::ValType(ValType::Ref(RefType::new(
                        false,
                        HeapType::ConcreteArray(array_ty),
                    ))),
                ),
                FieldType::new(Mutability::Var, StorageType::ValType(ValType::I64)),
            ],''',1).replace('''        StructRef::new(&mut *store, &pre, &[WasmtimeVal::from(array)])''','''        StructRef::new(
            &mut *store,
            &pre,
            &[WasmtimeVal::from(array), WasmtimeVal::I64(0)],
        )''',1);assert updated!=tests;changes[p]=(old,start+'#[cfg(test)]\nmod tests {'+updated)
p='crates/scriptw-engine/tests/runtime_cache/runtime_artifact_cache.rs';old=(root/p).read_text();new=old.replace('(runtime: size-optimized, execution: fast)\")','(runtime: size-optimized, execution: fast, source: NativeHost)\")',1);assert new!=old;changes[p]=(old,new)
out=Path('/tmp/scriptw-performance-batch24/fixture-repair.patch');out.write_text(''.join(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+p,tofile='b/'+p)) for p,(a,b) in changes.items()))
print(out.read_text())
