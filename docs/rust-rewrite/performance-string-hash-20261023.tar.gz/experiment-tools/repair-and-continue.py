"""Wait for the sealed first run, repair test-only expectations, and verify them."""
from pathlib import Path
import json,subprocess,time
r=Path('/workspace/lila-tooling-next');b=Path('/tmp/scriptw-performance-batch24');base=r/'target/performance-hills-20261021-attribution'
def call(args): return subprocess.check_output(args,cwd=r,text=True)
while True:
 rows=(base/'candidate53-native-memory.jsonl').read_text().splitlines()
 last=json.loads(rows[-1])
 if last['type']=='completion': break
 assert Path('/proc/2590819').exists(),'Initial watcher exited without a sealed completion'
 time.sleep(2)
assert last['exit_code']==1 and all(last['memory_events_delta'].get(k,0)==0 for k in ['oom','oom_kill','oom_group_kill'])
receipt=json.loads((base/'candidate53-native-checkpoint/receipt.json').read_text())
source='97036e5a80c165067879cc2e407f15042d7f18d7'
assert receipt['head']==source and receipt['source_unchanged'] and receipt['shared_runtime_linker_unchanged']
assert len(receipt['cases'])==12 and all(c['state'] in ['passed','failed'] for c in receipt['cases'])
failed={c['target']:sum(o['failed'] for o in c['outcomes']) for c in receipt['cases'] if c['state']=='failed'}
assert failed=={'scriptw_engine':7,'runtime_cache':1},failed
assert call(['git','rev-parse','HEAD']).strip()==source and not call(['git','status','--porcelain'])
call(['git','apply','--check',str(b/'fixture-repair.patch')]);call(['git','apply',str(b/'fixture-repair.patch')])
paths=['crates/scriptw-engine/src/runtime_regexp_compiler_tests.rs','crates/scriptw-engine/src/wasm_gc_completion.rs','crates/scriptw-engine/tests/runtime_cache/runtime_artifact_cache.rs']
subprocess.run(['bash','-c','. /workspace/.scriptw-tools/activate.sh; rustfmt --edition 2021 --config skip_children=true "$@"','rustfmt',*paths],cwd=r,check=True)
call(['git','diff','--check'])
assert set(call(['git','diff','--name-only']).splitlines())==set(paths)
shared=paths[1];old=call(['git','show',source+':'+shared]);new=(r/shared).read_text();assert old.split('#[cfg(test)]\nmod tests {',1)[0]==new.split('#[cfg(test)]\nmod tests {',1)[0]
patch=call(['git','diff',source,'--',*sorted(paths)])
(base/'candidate53b-fixture-repair.patch').write_text(patch)
call(['git','add','--sparse','--',*paths]);print(call(['git','commit','-m','Align native test fixtures with cached String layout and runtime trace']),flush=True)
repair_source=call(['git','rev-parse','HEAD']).strip()
(base/'candidate53b-fixture-repair.json').write_text(json.dumps(dict(product_source=source,repair_source=repair_source,test_only_paths=paths,initial_failures=failed,production_prefix_unchanged=True),indent=2)+'\n')
with (b/'native-repair.log').open('x') as log:
 subprocess.run(['python3','-B',str(b/'watch-native-repair.py')],cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
receipt=json.loads((base/'candidate53b-native-checkpoint/receipt.json').read_text())
assert receipt['head']==repair_source and receipt['source_unchanged'] and receipt['shared_runtime_linker_unchanged']
assert len(receipt['cases'])==2 and all(c['state']=='passed' and c['inventory_matches'] for c in receipt['cases'])
print('Complete repaired native scopes passed; starting unchanged frozen-product Test262 replay',flush=True)
with (b/'string-hash-replay.log').open('x') as log:
 code=subprocess.call(['python3','-B',str(b/'watch-string-hash-replay.py')],cwd=r,stdout=log,stderr=subprocess.STDOUT)
assert code==1,('Expected four ordinary upstream failures; inspect receipt',code)
receipt=json.loads((base/'candidate53-string-hash-replay/summary.json').read_text())
assert receipt['total']==13104 and receipt['outcomes']==dict(Success=13100,Bug=4,Crash=0,NotImplemented=0)
print('Original-case replay complete; publication validation pending',flush=True)
