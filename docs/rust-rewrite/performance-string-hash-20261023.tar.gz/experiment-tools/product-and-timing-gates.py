"""Freeze one successful product; complete semantic and paired controls serially."""
import json,os,subprocess,time
from pathlib import Path
root=Path('/workspace/lila-tooling-next');base=root/'target/performance-hills-20261021-attribution';batch=Path('/tmp/scriptw-performance-batch24');log=base/'candidate53-product-cargo.jsonl'
while True:
 if log.exists():
  with log.open('rb') as f:
   f.seek(max(0,f.seek(0,os.SEEK_END)-16384));lines=f.read().splitlines()
  try:last=json.loads(lines[-1])
  except (ValueError,IndexError):last={}
  if last.get('reason')=='build-finished':assert last['success'],last;break
 live=False
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   if b'/tmp/scriptw-performance-batch24/build-product.sh' in (p/'cmdline').read_bytes().split(b'\0'):live=True;break
  except OSError:pass
 assert live,'Product stopped before completion; keep failure evidence'
 time.sleep(2)
def run(name,*args):
 with (batch/(name+'.log')).open('x') as out:subprocess.run(['python3','-B',str(batch/(name+'.py')),*args],cwd=root,stdout=out,stderr=subprocess.STDOUT,check=True)
run('freeze-product');run('product-controls')
# Build/verification is closed before ordinary untraced timing begins.
run('startup-paired')
for label,args in [('execution-screen',['--idle-machine']),('execution-confirm',['--idle-machine','--confirm'])]:
 with (batch/(label+'.log')).open('x') as out:subprocess.run(['python3','-B',str(batch/'execution-paired.py'),*args],cwd=root,stdout=out,stderr=subprocess.STDOUT,check=True)
(base/'candidate53-product-timing-gates-complete.json').write_text(json.dumps(dict(complete=True,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),compiled_semantic_families=18,startup_observations=56,execution_cases=16,native_acceptance=False,test262_acceptance=False),indent=2)+'\n')
print('Product controls and paired measurements complete; decision and native/original-suite checks pending',flush=True)
