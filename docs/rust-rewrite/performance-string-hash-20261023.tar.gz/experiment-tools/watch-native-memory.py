"""Observe verification memory without changing workers, deadlines or verdicts."""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

root = Path('/workspace/lila-tooling-next')
base = root / 'target/performance-hills-20261021-attribution'
sys.path.insert(0, str(root / 'scripts'))
from limited_verification import kernel_group

group = kernel_group()
limit = (group / 'memory.max').read_text().strip()
assert limit.isdecimal() and int(limit) > 0
event_file = group / 'memory.events'
events = lambda: {k: int(v) for line in event_file.read_text().splitlines() for k, v in [line.split()]}
before = events()
out = base / 'candidate53-native-memory.jsonl'
with out.open('x') as samples, (base / 'candidate53-native-checkpoint.log').open('x') as log:
    def emit(row):
        samples.write(json.dumps(row, separators=(',', ':')) + '\n')
        samples.flush()
    emit(dict(type='configuration', memory_max_bytes=int(limit), interval_seconds=2,
        harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        boundary='Whole inherited cgroup including tmp/workspace file pages and other processes; sampled current usage, not a kernel peak or JavaScript heap. Per-PID RSS double-counts shared mappings. No policy changes.'))
    child = subprocess.Popen(['bash', '/tmp/scriptw-performance-batch24/native-checkpoint.sh'], cwd=root,
                             stdout=log, stderr=subprocess.STDOUT)
    maximum = 0
    while True:
        usage = int((group / 'memory.current').read_text())
        maximum = max(maximum, usage)
        procs = {}
        for p in Path('/proc').iterdir():
            if not p.name.isdigit():
                continue
            try:
                status = dict(line.split(':', 1) for line in (p / 'status').read_text().splitlines())
                procs[int(p.name)] = dict(pid=int(p.name), ppid=int(status['PPid']), name=status['Name'].strip(),
                    rss_bytes=int(status.get('VmRSS', '0 kB').split()[0]) * 1024,
                    threads=int(status['Threads']))
            except (OSError, KeyError, ValueError):
                pass
        owned = {child.pid}
        while True:
            expanded = owned | {pid for pid, v in procs.items() if v['ppid'] in owned}
            if expanded == owned:
                break
            owned = expanded
        emit(dict(type='sample', monotonic_ns=time.monotonic_ns(), memory_current_bytes=usage,
                  processes=[procs[pid] for pid in sorted(owned) if pid in procs]))
        try:
            code = child.wait(timeout=2)
            break
        except subprocess.TimeoutExpired:
            pass
    after = events()
    emit(dict(type='completion', exit_code=code, sampled_maximum_group_bytes=maximum,
              memory_events_delta={k: v - before.get(k, 0) for k, v in after.items()}))
print('Native checkpoint exit:', code, '; sampled whole-group maximum bytes:', maximum, flush=True)
raise SystemExit(code)
