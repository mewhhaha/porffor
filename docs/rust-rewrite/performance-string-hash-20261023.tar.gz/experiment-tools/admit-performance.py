"""Record the reviewed speed/storage tradeoff before correctness acceptance."""
import hashlib,json,statistics,time
from pathlib import Path
b=Path('/workspace/lila-tooling-next/target/performance-hills-20261021-attribution')
gate=b/'candidate53-product-timing-gates-complete.json'
while not gate.exists():time.sleep(2)
r=json.loads((b/'candidate53-hash-confirm/receipt.json').read_text());assert r['complete'] and len(r['observations'])==64
values={}
for name in dict.fromkeys(x['file'] for x in r['observations']):
 rows=[x for x in r['observations'] if x['file']==name];assert len(rows)==4
 pair={side:statistics.median(x['median_ns'] for x in rows if x['side']==side) for side in ['before','after']}
 pair['change_percent']=100*(pair['after']/pair['before']-1);values[name]=pair
assert all(values[n]['change_percent'] < -40 for n in ['property-get-long.js','map-get-long.js','set-has-long.js'])
assert all(values[n]['change_percent'] < 10 for n in ['retained-unhashed.js','retained-first-hash.js','map-get-numeric.js','set-has-numeric.js','property-get-numeric.js'])
# These are post-measurement review guards, not preregistered significance tests.
receipt=dict(source='97036e5a80c165067879cc2e407f15042d7f18d7',proceed_to_correctness=True,retain_if_correct=True,review='Retain the broad repeated-long-key improvements with explicit per-string storage and overlapping retention timing costs, contingent on native and original-case correctness. This is a post-measurement engineering decision, not statistical significance or preregistered thresholds.',paired_confirmation=values,payload_cost='One additional i64 field per StringValue, including never-hashed strings; concrete heap alignment may add more. GC capacity/RSS are not live heap or allocation counters.',cli_size_increase_bytes=169104,limitations=['Retained never-hashed and first-hash medians are slower; before/after rounds overlap, so retain raw results and avoid isolated attribution.','Numeric/short controls overlap; no universal speedup claim.','README V8 comparison and full-suite graph remain their own source50 cohorts.'])
p=b/'candidate53-performance-admission.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n')
print('Performance tradeoff admitted to correctness acceptance',flush=True)
