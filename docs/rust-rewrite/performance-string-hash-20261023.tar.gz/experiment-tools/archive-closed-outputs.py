"""Verify a portable copy before retiring completed verification executables."""
import hashlib,json,os,shutil,stat,subprocess,tarfile
from pathlib import Path
root=Path('/workspace/lila-tooling-next');base=root/'target/performance-hills-20261021-attribution'
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
# Replay's private copy can share the exact accepted52 executable.
replay=base/'candidate52-definition-replay/compiler';live=Path('/tmp/scriptw-performance-candidate-5c63c6597/scriptw')
assert sha(replay)==sha(live) and replay.stat().st_size==live.stat().st_size
# Private diagnostic executables and obsolete measurement/test products only.
paths=[base/'candidate52-extended-source-guards'/target/'source-guards' for target in ['structure_builtins','structure_language']]
paths+=list(Path('/tmp/scriptw-performance-candidate-b9ecfe64b').iterdir())
release=Path('/workspace/porffor/target/release')
paths += [release/'deps'/name for name in ['scriptw_ir_integration-2b70635871a6d4e4','scriptw_ir-27212ef03112ea1a','scriptw-facd27755ce49795']]
paths += [release/'scriptw']
assert all(p.is_file() and not p.is_symlink() for p in paths)
assert (release/'scriptw').samefile(release/'deps/scriptw-facd27755ce49795')
assert all(p.open('rb').read(4)==b'\x7fELF' for p in paths)
selected=set(paths+[replay])
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  active={(proc/'exe').resolve()}
  for fd in (proc/'fd').iterdir():
   try:active.add(fd.resolve())
   except (OSError,RuntimeError):pass
  for line in (proc/'maps').read_text().splitlines():
   fields=line.split(maxsplit=5)
   if len(fields)==6 and fields[5].startswith('/'):active.add(Path(fields[5]))
  assert not selected & active, ('live consumer',proc.name,selected&active)
 except (OSError,RuntimeError):pass
rows=[];inodes={}
for p in paths:
 st=p.stat();inode=(st.st_dev,st.st_ino);member=inodes.setdefault(inode,str(p).lstrip('/'))
 rows.append(dict(original=str(p),member=member,sha256=sha(p),bytes=st.st_size,mode=stat.S_IMODE(st.st_mode),mtime_ns=st.st_mtime_ns))
out=base/'candidate53-closed-verification-archive';out.mkdir();packed=out/'payload.tar.zst'
before={str(p):shutil.disk_usage(p).free for p in ['/workspace','/tmp']}
unique={r['member']:r for r in rows}
with packed.open('xb') as f:
 child=subprocess.Popen(['zstd','-q','-1','-T1','--long=27','-c'],stdin=subprocess.PIPE,stdout=f)
 with tarfile.open(fileobj=child.stdin,mode='w|',format=tarfile.PAX_FORMAT) as tar:
  for r in unique.values():tar.add(r['original'],arcname=r['member'],recursive=False)
 child.stdin.close();assert child.wait()==0
child=subprocess.Popen(['zstd','-q','--long=27','-dc',str(packed)],stdout=subprocess.PIPE);actual=[]
with tarfile.open(fileobj=child.stdout,mode='r|') as tar:
 for m in tar:
  assert m.isfile();actual.append((m.name,m.size,hashlib.file_digest(tar.extractfile(m),'sha256').hexdigest()))
assert child.wait()==0 and actual==[(r['member'],r['bytes'],r['sha256']) for r in unique.values()]
assert all(sha(Path(r['original']))==r['sha256'] for r in rows)
receipt=dict(complete=True,archive=str(packed),archive_bytes=packed.stat().st_size,archive_sha256=sha(packed),original_unique_bytes=sum(r['bytes'] for r in unique.values()),files=rows,free_before=before,policy='Completed test/measurement executables only. Source52 baseline and all build dependency libraries retained. Verified every member before retiring originals. Restore members under / and recreate additional original aliases with recorded mode/mtime before reusing historical executables.',replay_shared_copy=dict(original=str(replay),storage=str(live),sha256=sha(live),bytes=live.stat().st_size))
(out/'inventory.json').write_text(json.dumps(receipt,indent=2)+'\n')
for p in paths:p.unlink()
replay.unlink();replay.symlink_to(live)
receipt['free_after']={str(p):shutil.disk_usage(p).free for p in ['/workspace','/tmp']}
(out/'inventory.json').write_text(json.dumps(receipt,indent=2)+'\n')
print({k:receipt[k] for k in ['original_unique_bytes','archive_bytes','free_before','free_after']},flush=True)
