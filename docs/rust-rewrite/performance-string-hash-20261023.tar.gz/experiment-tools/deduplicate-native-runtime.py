"""Compare independently completed producer bytes, then share exact working files."""
import hashlib,json,time,gzip
from pathlib import Path
r=Path('/workspace/lila-tooling-next');b=r/'target/performance-hills-20261021-attribution';run=b/'candidate53-native-checkpoint'
while not (b/'candidate53-runtime-images-preserved-before-native.json').exists():time.sleep(2)
product=json.loads((b/'candidate53-runtime-images-preserved-before-native.json').read_text());expected={Path(x['original']).name:x for x in product['files']};wanted='/workspace/porffor/target/release/build/scriptw-runtime-image-68ca4074ffcd8759/out';seen={}
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
while True:
 event=None
 for p in sorted(list(run.glob('*.build.jsonl'))+list(run.glob('*.build.jsonl.gz'))):
  old=seen.get(str(p),0)
  try:
   with (gzip.open(p,'rb') if p.suffix=='.gz' else p.open('rb')) as stream:
    stream.seek(old)
    for line in stream:
     if not line.endswith(b'\n'):break
     old+=len(line)
     row=json.loads(line)
     if row.get('reason')=='build-script-executed' and row.get('out_dir')==wanted:event=row
   seen[str(p)]=old
  except FileNotFoundError:continue
  if event:break
 if event:break
 done=b/'candidate53-native-memory.jsonl'
 if done.exists() and json.loads(done.read_text().splitlines()[-1]).get('type')=='completion':raise RuntimeError('No completed independent native runtime producer found')
 time.sleep(2)
out=Path(wanted);rows=[]
assert set(p.name for p in out.iterdir())==set(expected)
for p in sorted(out.iterdir()):
 row=expected[p.name];assert not p.is_symlink() and p.stat().st_size==row['bytes']
 digest=sha(p)
 if p.name=='image_data.rs':
  original=Path(row['original']);assert p.read_text().replace(wanted,str(original.parent))==original.read_text(), 'Generated wrapper differs beyond producer directory'
 else:assert digest==row['sha256'],(p,digest,row['sha256'])
 rows.append(dict(native=str(p),product=row['original'],bytes=row['bytes'],sha256=digest,product_sha256=row['sha256'],exact_bytes=digest==row['sha256'],producer_path_only_difference=p.name=='image_data.rs',working=row.get('working')))
receipt=dict(complete=True,source='97036e5a80c165067879cc2e407f15042d7f18d7',producer=event,files=rows,policy='Independent Cargo native producer completed before comparison; all runtime payload, manifest, binding and archive bytes match the archived ordinary product producer. The generated Rust include wrapper differs only in its separately recorded producer directory; it is retained separately and not shared. Only identical completed data files share a mutable working alias; immutable original bytes remain in the verified product archive.')
(b/'candidate53-independent-native-runtime-identity.json').write_text(json.dumps(receipt,indent=2)+'\n')
for row in rows:
 if not row['working']:continue
 p=Path(row['native']);target=Path(row['working']);assert sha(target)==row['sha256']
 p.unlink();p.symlink_to(target)
print('Independent native/product identity verified for all',len(rows),'files (wrapper normalized only for producer paths); shared',sum(x['bytes'] for x in rows if x['working']),'bytes',flush=True)
