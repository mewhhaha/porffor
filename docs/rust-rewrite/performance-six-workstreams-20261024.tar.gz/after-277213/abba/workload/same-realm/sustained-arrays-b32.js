(function () {

function batch(seed) {
var a=[];for(var i=0;i<128;i++)a.push(i+seed);var s=0;for(var i=0;i<a.length;i++)s+=a[i];return s;
}
var checksum = 0;
for (var round = 0; round < 32; round++) checksum += batch(round % 8);
print(checksum);
})();
