(function () {
function step(x) { return x + 1; }
function batch(seed) {
var s=0; for(var i=0;i<64;i++) s+=step(i+seed); return s;
}
var checksum = 0;
for (var round = 0; round < 32; round++) checksum += batch(round % 8);
print(checksum);
})();
