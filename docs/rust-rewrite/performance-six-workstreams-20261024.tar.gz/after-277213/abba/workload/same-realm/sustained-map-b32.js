(function () {

function batch(seed) {
var m=new Map();for(var i=0;i<32;i++)m.set('k'+i,i+seed);var s=0;for(var i=0;i<32;i++)s+=m.get('k'+i);return s;
}
var checksum = 0;
for (var round = 0; round < 32; round++) checksum += batch(round % 8);
print(checksum);
})();
