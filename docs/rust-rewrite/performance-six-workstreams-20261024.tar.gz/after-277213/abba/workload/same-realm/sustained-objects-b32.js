(function () {

function batch(seed) {
var a=[];for(var i=0;i<32;i++)a.push({x:i+seed,y:2*i+1});var s=0;for(var i=0;i<a.length;i++)s+=a[i].x+a[i].y;return s;
}
var checksum = 0;
for (var round = 0; round < 32; round++) checksum += batch(round % 8);
print(checksum);
})();
