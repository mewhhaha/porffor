(function () {
var fs=[function(x){return x+1;},function(x){return x+2;}];
function batch(seed) {
var s=0;for(var i=0;i<48;i++)s+=fs[i%2](i+seed);return s;
}
var checksum = 0;
for (var round = 0; round < 32; round++) checksum += batch(round % 8);
print(checksum);
})();
