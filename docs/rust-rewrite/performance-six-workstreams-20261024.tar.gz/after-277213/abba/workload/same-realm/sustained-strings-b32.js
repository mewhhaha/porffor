(function () {

function batch(seed) {
var s='a'.repeat(64)+seed;return s.slice(1).length+s.indexOf(String(seed));
}
var checksum = 0;
for (var round = 0; round < 32; round++) checksum += batch(round % 8);
print(checksum);
})();
