(function () {

function batch(seed) {
var a={x:seed,y:7};var s=0;for(var i=0;i<32;i++){a.x=i+seed;delete a.y;a.y=i+1;s+=a.x+a.y;}return s;
}
var checksum = 0;
for (var round = 0; round < 32; round++) checksum += batch(round % 8);
print(checksum);
})();
