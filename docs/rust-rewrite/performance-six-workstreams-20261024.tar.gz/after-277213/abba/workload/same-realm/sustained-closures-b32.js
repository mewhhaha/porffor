(function () {
var next=(function(){var n=0;return function(){return ++n;};})();
function batch(seed) {
var s=0; for(var i=0;i<32;i++) s+=next(); return s;
}
var checksum = 0;
for (var round = 0; round < 32; round++) checksum += batch(round % 8);
print(checksum);
})();
