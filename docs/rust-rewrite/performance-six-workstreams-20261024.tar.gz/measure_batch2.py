"""Serial idle measurements, admitted only after a complete native checkpoint."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
source=base/'source'
sys.path.insert(0,str(source/'scripts'))
from limited_verification import require_kernel_budget
from verification_identity import source_map
parser=argparse.ArgumentParser();parser.add_argument('--checkpoint',type=Path,required=True)
parser.add_argument('--stage',choices=('ordinary','abba','scaling','boundaries','ssr-smoke','policy','gc-large','retention','hash-abba'),required=True)
args=parser.parse_args();require_kernel_budget(4096*1024**2)
checkpoint=args.checkpoint.resolve();identity=source_map(source)
for scope in ('focused','broad'):
 row=json.loads((checkpoint/scope/'receipt.json').read_text())
 assert row['complete'] and row['source_unchanged'] and row.get('selection_start_index',0)==0
 assert row['source']==identity, 'native checkpoint source differs'
build=json.loads((checkpoint/'build/receipt.json').read_text());assert build['complete'] and build['source']==identity
bins=checkpoint/'build/bin';live=base/'build/release';gnu=Path('/tmp/scriptw-performance-tools/bin/time')
for record in build['binaries']:
 saved=bins/record['file'];assert hashlib.file_digest(saved.open('rb'),'sha256').hexdigest()==record['sha256']
 if record['file'] in ('scriptw','runtime_baseline'):
  path=live/('scriptw' if record['file']=='scriptw' else 'examples/runtime_baseline')
  assert hashlib.file_digest(path.open('rb'),'sha256').hexdigest()==record['sha256'], 'live Cargo producer changed'
commands=[]
if args.stage=='ordinary':
 for partition in ('baseline','tuning','holdout'):
  command=[sys.executable,'-B','scripts/benchmark-v8.py','--scriptw',str(live/'scriptw'),
   '--runtime-runner',str(live/'examples/runtime_baseline'),'--build-log',str(checkpoint/'build/cargo.jsonl'),
   '--time',str(gnu),'--output-dir',str(checkpoint/'measurements'/partition),'--samples','7','--warmups','10',
   '--execution-cache',str(base/'execution-cache'),'--baseline',str(base/'before'/partition/'report.json'),
   '--first-runtime','v8','--idle-machine']
  if partition!='baseline':command+=['--fixtures',str(base/'same-realm-corpus'),'--partition',partition,'--skip-startup']
  commands.append((partition,command,{}))
elif args.stage in ('abba','scaling'):
 command=[sys.executable,str(base/'run_batch2_abba.py'),'--after-bin',str(bins),
  '--output-dir',str(checkpoint/'measurements'/args.stage),'--time',str(gnu),'--idle-machine']
 if args.stage=='abba':
  for name in ['integer.js','objects.js','retained-objects.js']+['sustained-'+name+'-b32.js' for name in ('calls','closures','objects','arrays','strings','map','json')]:command+=['--case',name]
 else:command+=['--fixtures',str(base/'storage-scaling'),'--before-commit','30fc1931471646253e339100a6d392b2337a373b','--before-bin',str(base/'after/bin')]
 commands.append((args.stage,command,{}))
elif args.stage in ('boundaries','ssr-smoke'):
 command=[sys.executable,'-B','scripts/benchmark_boundaries.py','--runner',str(bins/'runtime_boundaries'),
  '--time',str(gnu),'--output-dir',str(checkpoint/'measurements'/args.stage),'--samples','7',
  '--call-sessions','1' if args.stage=='ssr-smoke' else '2','--timeout','900']
 cases=('react-ssr-synchronous',) if args.stage=='ssr-smoke' else ('calls','closures','objects','arrays','strings','map','json','polymorphic-calls','array-holes','object-mutation','react-ssr-synchronous')
 if args.stage=='ssr-smoke':command+=['--boundary','calls']
 for name in cases:
  command+=['--case',name]
 commands.append(('boundaries',command,{}))
elif args.stage=='policy':
 commands.append(('policy',[sys.executable,'-B','scripts/policy_break_even.py','--runner',str(bins/'runtime_policy_break_even'),
  '--time',str(gnu),'--output-dir',str(checkpoint/'measurements/policy'),'--idle-machine'],{}))
elif args.stage=='gc-large':
 commands.append(('gc-large',[sys.executable,'-B',str(base/'run_large_gc_cohort.py'),
  '--runner',str(bins/'runtime_policy_break_even'),'--time',str(gnu),
  '--output-dir',str(checkpoint/'measurements/gc-large'),'--idle-machine'],{}))
elif args.stage=='retention':
 commands.append(('retention',[sys.executable,'-B','scripts/startup_retention_cohort.py','--runner',str(base/'after/bin/runtime_baseline'),
  '--fixtures',str(base/'after/baseline/workload'),'--source-commit','30fc1931471646253e339100a6d392b2337a373b',
  '--time',str(gnu),'--output-dir',str(checkpoint/'measurements/retention')],{}))
else:
 for index,algorithm in enumerate(('sha256','blake3','blake3','sha256')):
  commands.append((f'hash-{index}-{algorithm}',[sys.executable,'-B','scripts/benchmark_boundaries.py',
   '--runner',str(bins/'runtime_boundaries'),'--time',str(gnu),'--output-dir',str(checkpoint/'measurements'/f'hash-{index}-{algorithm}'),
   '--case','calls','--boundary','source','--samples','7','--timeout','900'],{'SCRIPTW_COMPILER_CACHE_IMAGE_HASH':algorithm}))
(checkpoint/'measurements').mkdir(exist_ok=True)
receipt=checkpoint/'measurements'/(args.stage+'-driver.json')
assert not receipt.exists()
report=dict(source=identity,complete=False,stage=args.stage,commands=[])
def save():receipt.write_text(json.dumps(report,indent=2)+'\n')
save()
for name,command,extra in commands:
 assert source_map(source)==identity
 row=dict(label=name,command=command,environment_overrides=extra,state='running',started_unix=time.time())
 report['commands'].append(row);save();print('Measure',name,flush=True)
 result=subprocess.run(command,cwd=source,env=dict(os.environ,**extra))
 row.update(state='closed',exit_code=result.returncode,finished_unix=time.time());save()
 if result.returncode:raise RuntimeError(name)
assert source_map(source)==identity
report['complete']=True;save()
