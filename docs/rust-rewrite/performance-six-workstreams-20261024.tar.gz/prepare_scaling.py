"""Predeclared storage-size controls; no compiler or timing runs."""
import hashlib
import json
from pathlib import Path
base=Path(__file__).resolve().parent
output=base/'storage-scaling'
output.mkdir(exist_ok=False)
entries=[]
for width in (1,4,16,32):
    for count in (128,512,2048):
        fields=','.join(f'p{index}:i+{index}' for index in range(width))
        scan='+'.join(f'rows[j].p{index}' for index in range(width))
        source=f'(function(){{var rows=[];for(var i=0;i<{count};i++)rows.push({{{fields}}});var sum=0;for(var j=0;j<rows.length;j++)sum+={scan};print(sum);}})();\n'
        expected=sum(width*index+width*(width-1)//2 for index in range(count))
        name=f'object-fields-{width}-rows-{count}.js'
        (output/name).write_text(source)
        entries.append(dict(file=name,stdout=f'{expected}\n',work='retained own-data construction and traversal scaling',parameters=dict(fields=width,rows=count),source_sha256=hashlib.sha256(source.encode()).hexdigest()))
for count in (128,512,2048):
    source=f'(function(){{var a=[];for(var i=0;i<{count};i++)a.push(i);var sum=0;for(var j=0;j<a.length;j++)sum+=a[j];print(sum);}})();\n'
    name=f'packed-numbers-{count}.js';(output/name).write_text(source)
    entries.append(dict(file=name,stdout=f'{count*(count-1)//2}\n',work='numeric append and traversal scaling',parameters=dict(elements=count),source_sha256=hashlib.sha256(source.encode()).hexdigest()))
(output/'startup.js').write_text("print('scaling-control');\n")
manifest=dict(schema='scriptw-v8-workloads-v1',startup=dict(file='startup.js',stdout='scaling-control\n'),execution=entries)
(output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(output/'declaration.json').write_text(json.dumps(dict(role='mechanism scaling controls, not unseen application holdout; no measurements examined when generated',counts='source/layout record accounting in contracts; dynamic allocation totals unavailable',cases=[e['file'] for e in entries]),indent=2)+'\n')
print(output)
