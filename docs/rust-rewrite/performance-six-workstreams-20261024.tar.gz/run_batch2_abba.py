#!/usr/bin/env python3
"""Task-owned, serial confirmation of three frozen compiler workloads.

Run inside scripts/limited_verification.py's local 4-GiB/one-CPU scope, after
native verification stops. This script stages no binaries and changes no source.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys

BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'source'
BEFORE = 'd89fd40689f60d94f14fa7800c180be89cfdd66a'
BEFORE_BIN = BASE / 'before/bin'
CASES = {
    'integer.js': ('baseline', SOURCE / 'crates/scriptw-cli/tests/fixtures/v8_baseline'),
    'objects.js': ('baseline', SOURCE / 'crates/scriptw-cli/tests/fixtures/v8_baseline'),
    'retained-objects.js': ('baseline', SOURCE / 'crates/scriptw-cli/tests/fixtures/v8_baseline'),
    'sustained-arrays-b32.js': ('same-realm', BASE / 'same-realm-corpus'),
}
CASES.update({f'sustained-{name}-b32.js': ('same-realm', BASE / 'same-realm-corpus')
              for name in ('calls', 'closures', 'objects', 'strings', 'map', 'json')})
HARNESSES = (
    'scripts/benchmark_metrics.py', 'scripts/benchmark-v8.py',
    'scripts/performance_corpus.py',
    'crates/scriptw-cli/examples/runtime_baseline.rs',
    'crates/scriptw-cli/examples/runtime_baseline/policy_options.rs',
    'crates/scriptw-cli/examples/runtime_baseline/phase_observer.rs',
)
sys.path.insert(0, str(SOURCE / 'scripts'))
from benchmark_metrics import digest, measure_process
from limited_verification import kernel_group, limited_environment, require_kernel_budget


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(value):
    return isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--case', action='append', dest='cases')
    parser.add_argument('--before-commit', default=BEFORE)
    parser.add_argument('--before-bin', type=Path, default=BEFORE_BIN)
    parser.add_argument('--after-bin', type=Path, required=True)
    parser.add_argument('--fixtures', type=Path)
    parser.add_argument('--time', type=Path, default=Path('/tmp/scriptw-performance-tools/bin/time'))
    parser.add_argument('--execution-cache', type=Path, default=BASE / 'execution-cache')
    parser.add_argument('--timeout', type=int, choices=range(1, 3601), default=900)
    parser.add_argument('--idle-machine', action='store_true', required=True)
    args = parser.parse_args()
    if args.fixtures:
        manifest = json.loads((args.fixtures / 'manifest.json').read_text())
        for entry in manifest['execution']:
            CASES[entry['file']] = ('storage-scaling', args.fixtures)
    selected = args.cases or ([entry['file'] for entry in manifest['execution']] if args.fixtures else ['objects.js', 'retained-objects.js', 'sustained-arrays-b32.js'])
    require(all(name in CASES for name in selected), 'unknown selected cases')
    require(len(set(selected)) == len(selected), 'cases must be distinct')
    require_kernel_budget(4096 * 1024**2)
    require(len(os.sched_getaffinity(0)) == 1, 'one inherited CPU is required')
    environment = limited_environment()
    environment['SCRIPTW_CACHE_DIR'] = str(args.execution_cache.resolve())
    for key in ('SCRIPTW_WASM_TRACE', 'SCRIPTW_WASM_TRACE_DUMP'):
        require(not environment.get(key), f'unset diagnostic instrumentation {key}')
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=False)
    report = dict(schema='scriptw-frozen-paired-diagnostic-v1', complete=False,
        started_at=stamp(), configuration=dict(samples=7, warmups=10,
            rounds_per_side=2, order=['before', 'after', 'after', 'before'],
            timeout_seconds=args.timeout, execution_cache=environment['SCRIPTW_CACHE_DIR'],
            scope='ordinary Portable execution/completion; fresh Store each invocation; no explicit native policy'),
        cpu=min(os.sched_getaffinity(0)), identities={}, runners={}, commands=[],
        workloads=[], observations=[], harness_sha256={}, linked_runtime_comparisons=[],
        script_sha256=digest(Path(__file__)),
        resources=dict(cgroup=str(kernel_group()),
            memory_max=(kernel_group() / 'memory.max').read_text().strip(),
            memory_swap_max=(kernel_group() / 'memory.swap.max').read_text().strip(),
            memory_oom_group=(kernel_group() / 'memory.oom.group').read_text().strip(),
            affinity=sorted(os.sched_getaffinity(0)),
            worker_environment={key: environment[key] for key in (
                'CARGO_BUILD_JOBS', 'SCRIPTW_JOBS', 'RUST_TEST_THREADS', 'RAYON_NUM_THREADS',
                'SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES', 'SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES')}))

    def save():
        pending = output / 'receipt.pending'
        pending.write_text(json.dumps(report, indent=2) + '\n')
        pending.replace(output / 'receipt.json')

    def invoke(label, command):
        row = dict(label=label, command=list(map(str, command)), cwd=str(SOURCE),
                   state='running', started_at=stamp(), timeout_seconds=args.timeout)
        report['commands'].append(row)
        save()
        stdout, stderr = output / (label + '.json'), output / (label + '.stderr')
        try:
            with stdout.open('xb') as out, stderr.open('xb') as err:
                row['process'] = measure_process(command, cwd=SOURCE, env=environment,
                    stdout=out, stderr=err, timeout=args.timeout, time_binary=str(args.time.resolve()))
            row['state'] = 'closed'
            require(row['process']['exit_code'] == 0 and not row['process']['timed_out'],
                    f'{label}: failed child; retained stdout/stderr and accounting')
            return row, stdout
        except BaseException as error:
            row.update(state='failed', error=f'{type(error).__name__}: {error}')
            raise
        finally:
            row['finished_at'] = stamp()
            row['logs'] = [dict(path=path.name, sha256=digest(path), bytes=path.stat().st_size)
                           for path in (stdout, stderr) if path.exists()]
            save()

    save()
    try:
        candidate_origin = BASE / 'candidate-commit.json'
        candidate_bytes = candidate_origin.read_bytes()
        candidate_path = output / 'candidate-commit.json'
        with candidate_path.open('xb') as stream:
            stream.write(candidate_bytes)
        candidate = json.loads(candidate_bytes)['commit']
        require(isinstance(candidate, str) and len(candidate) == 40
                and all(c in '0123456789abcdef' for c in candidate), 'invalid frozen candidate commit')
        revisions = {'before': args.before_commit, 'after': candidate}
        report['candidate_proof'] = dict(path=candidate_path.name,
            sha256=hashlib.sha256(candidate_bytes).hexdigest(), commit=candidate,
            original_path=str(candidate_origin), path_scope='relative to receipt directory; immutable proof snapshot')
        report['expected_source_commits'] = revisions
        for name in HARNESSES:
            contents = [subprocess.check_output(['git', 'show', revision + ':' + name], cwd=SOURCE)
                        for revision in revisions.values()]
            require(contents[0] == contents[1] == (SOURCE / name).read_bytes(),
                    f'measurement harness changed between frozen products: {name}')
            report['harness_sha256'][name] = hashlib.sha256(contents[0]).hexdigest()
        report['time_binary'] = dict(path=str(args.time.resolve()), sha256=digest(args.time))
        _, version = invoke('gnu-time-version', [str(args.time.resolve()), '--version'])
        report['time_binary']['version'] = version.read_text().strip()
        require('GNU Time' in report['time_binary']['version'], 'actual child accounting requires GNU time')
        for side, revision in revisions.items():
            binary_root = args.before_bin if side == 'before' else args.after_bin
            runner, cli = binary_root / 'runtime_baseline', binary_root / 'scriptw'
            report['runners'][side] = dict(path=str(runner), sha256=digest(runner), bytes=runner.stat().st_size)
            event, path = invoke('identity-' + side, [str(cli), 'compiler-identity'])
            identity = json.loads(path.read_text())
            require(identity['source_revision'] == dict(kind='git-commit', commit=revision)
                    and identity['executable_sha256'] == digest(cli)
                    and sha256(identity['source_fingerprint']), f'{side}: archived CLI/source identity differs')
            report['identities'][side] = identity
            event['validation'] = 'loaded CLI bytes and frozen source revision match'
        fixtures = {}
        plans = {}
        for name in selected:
            family, root = CASES[name]
            if family not in fixtures:
                destination = output / 'workload' / family
                destination.mkdir(parents=True)
                manifest_path = root / 'manifest.json'
                require(manifest_path.stat().st_size <= 1024**2, 'unexpectedly large workload manifest')
                manifest_bytes = manifest_path.read_bytes()
                manifest = json.loads(manifest_bytes)
                require(manifest['schema'] == 'scriptw-v8-workloads-v1', 'unexpected workload manifest schema')
                entries = [manifest['startup'], *manifest['execution']]
                require(0 < len(entries) <= 128, 'workload source inventory exceeds bounded task corpus')
                names = [entry['file'] for entry in entries]
                require(len(set(names)) == len(names), 'duplicate workload basename')
                for entry in entries:
                    filename = entry['file']
                    require(Path(filename).name == filename and filename.endswith('.js')
                            and isinstance(entry['stdout'], str), 'invalid workload filename or stdout')
                    source = (root / filename).resolve()
                    require(source.is_relative_to(root.resolve()) and source.stat().st_size <= 1024**2,
                            'workload source escapes its root or exceeds the bounded task corpus')
                    with (destination / filename).open('xb') as stream:
                        stream.write(source.read_bytes())
                with (destination / 'manifest.json').open('xb') as stream:
                    stream.write(manifest_bytes)
                fixtures[family] = destination
                plans[family] = manifest
                report['workloads'].append(dict(family=family, source_root=str(root),
                    manifest_sha256=hashlib.sha256(manifest_bytes).hexdigest(),
                    snapshot_manifest=str((destination / 'manifest.json').relative_to(output)),
                    sources=[dict(file=entry['file'], sha256=digest(destination / entry['file']),
                                  stdout=entry['stdout']) for entry in entries]))
            matches = [entry for entry in plans[family]['execution'] if entry['file'] == name]
            require(len(matches) == 1, f'{name}: source manifest must select exactly one execution')
        save()
        source_bindings = {}
        for name in selected:
            family, _ = CASES[name]
            fixture = fixtures[family]
            entry = next(entry for entry in plans[family]['execution'] if entry['file'] == name)
            source_hash = digest(fixture / name)
            _, oracle_path = invoke('oracle-' + name, ['node', '-e', "const fs=require('node:fs'),vm=require('node:vm');vm.runInNewContext(fs.readFileSync(process.argv[1],'utf8'),{print:x=>process.stdout.write(String(x)+'\\n')});", str(fixture / name)])
            require(oracle_path.read_text() == entry['stdout'], 'independent Node output differs')
            policies = set()
            for index, side in enumerate(('before', 'after', 'after', 'before')):
                label = f'{name}-{index}-{side}'
                artifacts = output / (label + '-wasm')
                artifacts.mkdir()
                runner = Path(report['runners'][side]['path'])
                print('Running bounded ABBA:', label, flush=True)
                event, raw_path = invoke(label, [str(runner), str(fixture), '7', '10', name, str(artifacts)])
                raw = json.loads(raw_path.read_text())
                identity = report['identities'][side]
                require(raw['schema'] == 'scriptw-wasmtime-baseline-v2'
                        and raw.get('requested_native_policy') is None
                        and raw['samples'] == 7 and raw['warmups'] == 10,
                        f'{label}: runtime wire mode/sample plan differs')
                require(raw['source_commit'] == revisions[side]
                        and raw['source_fingerprint'] == identity['source_fingerprint']
                        and raw['executable_sha256'] == report['runners'][side]['sha256'],
                        f'{label}: runtime loaded source/executable identity differs')
                require(len(raw['cases']) == 1, f'{label}: runtime returned a different case inventory')
                case = raw['cases'][0]
                wasm = artifacts / (name + '.wasm')
                require(case['file'] == name and case['source_sha256'] == source_hash
                        and case['source_compilation_profile'] == 'portable', f'{label}: source identity/profile differs')
                require(wasm.is_file() and case['wasm_bytes'] == wasm.stat().st_size
                        and case['wasm_sha256'] == digest(wasm), f'{label}: retained program Wasm differs')
                with wasm.open('rb') as stream:
                    require(stream.read(8) == b'\0asm\x01\0\0\0', f'{label}: invalid program Wasm header')
                runtime = case['linked_runtime']
                require(isinstance(runtime, dict) and sha256(runtime['key']) and sha256(runtime['wasm_sha256'])
                        and type(runtime['wasm_bytes']) is int and runtime['wasm_bytes'] > 0,
                        f'{label}: invalid linked-runtime identity')
                rows = case['observations']
                require(len(rows) == 17, f'{label}: truncated warmup/measurement inventory')
                for ordinal, row in enumerate(rows):
                    require(type(row['warmup']) is bool and row['warmup'] == (ordinal < 10)
                            and row['stdout'] == entry['stdout'] and type(row['execution_ns']) is int
                            and row['execution_ns'] > 0 and isinstance(row['runtime_policy'], str)
                            and row['runtime_policy'], f'{label}: checksum, timing or warmup order differs')
                    require('actual_native_policy' not in row and 'row_phases' not in row,
                            f'{label}: ordinary round unexpectedly used diagnostic policy/observers')
                    if ordinal >= 10:
                        require(row['module_cache'] == 'Hit' and row['host_import_cache'] == 'Hit',
                                f'{label}: measured module or host-import template was not warm')
                    policies.add(row['runtime_policy'])
                require(len(policies) == 1, f'{name}: compared rounds changed the runtime capability policy')
                binding = dict(source_commit=raw['source_commit'], source_fingerprint=raw['source_fingerprint'],
                    runner_sha256=raw['executable_sha256'], wasm_sha256=case['wasm_sha256'], linked_runtime=runtime)
                require(source_bindings.setdefault((side, name), binding) == binding,
                        f'{label}: same-source rounds changed program/runtime artifact identity')
                elapsed = [row['execution_ns'] for row in rows[10:]]
                report['observations'].append(dict(file=name, label=label, side=side,
                    raw=raw_path.name, raw_sha256=digest(raw_path), source_sha256=source_hash,
                    process=event['process'], execution_ns=elapsed, median_ns=statistics.median(elapsed),
                    wasm_path=str(wasm.relative_to(output)), wasm_bytes=case['wasm_bytes'],
                    **{key: value for key, value in binding.items() if key != 'linked_runtime'}))
                event['validation'] = 'source/executable/Wasm/output/mode/warmup/cache-hit identities match'
                save()
            before_runtime = source_bindings[('before', name)]['linked_runtime']
            after_runtime = source_bindings[('after', name)]['linked_runtime']
            report['linked_runtime_comparisons'].append(dict(file=name,
                before=before_runtime, after=after_runtime,
                runtime_key_equal=before_runtime['key'] == after_runtime['key'],
                reported_wasm_sha256_equal=before_runtime['wasm_sha256'] == after_runtime['wasm_sha256'],
                reported_wasm_bytes_equal=before_runtime['wasm_bytes'] == after_runtime['wasm_bytes'],
                reported_wasm_payload_identical=(before_runtime['wasm_sha256'] == after_runtime['wasm_sha256']
                    and before_runtime['wasm_bytes'] == after_runtime['wasm_bytes']),
                scope='Compared product-reported linked R digest and byte length; raw R payload is not separately retained by this runner.'))
            save()
        for side, runner in report['runners'].items():
            require(digest(runner['path']) == runner['sha256'], f'{side}: archived runner changed during confirmation')
        require(digest(candidate_path) == report['candidate_proof']['sha256'], 'candidate source proof changed during confirmation')
        report.update(complete=True, finished_at=stamp(), limitations=[
            'Ordinary fresh-Store execution/completion; setup remains included and no isolated steady-state timer is claimed.',
            'Each side has two process round medians, not confidence intervals or a future-noise bound.',
            'P bytes are retained and hashed; linked R identity comes from the product admission path and its raw runtime metadata.',
            'This task receipt is neither a complete V8 report nor conformance acceptance.'])
        save()
        print('Complete bounded ABBA receipt:', output / 'receipt.json', flush=True)
    except BaseException as error:
        report.update(complete=False, failed_at=stamp(), failure=f'{type(error).__name__}: {error}')
        save()
        raise


if __name__ == '__main__':
    main()
