"""Sequential source-bound batch verification inside the local kernel budget."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
source = base / 'source'
sys.path.insert(0, str(source / 'scripts'))
from limited_verification import kernel_group, require_kernel_budget
from native_test_protocol import parse_inventory, result_summaries
from verification_identity import source_map

parser = argparse.ArgumentParser()
parser.add_argument('stage', choices=('build', 'focused', 'broad', 'python'))
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--start-at', type=int, default=0)
parser.add_argument('--continue-after-failures', action='store_true')
args = parser.parse_args()
require_kernel_budget(4096 * 1024**2)
args.output.mkdir(parents=True, exist_ok=False)
identity = source_map(source)
if identity['tracked_patch_sha256'] != hashlib.sha256(b'').hexdigest() or identity['untracked']:
    raise RuntimeError('frozen source must be clean')
report = dict(stage=args.stage, complete=False, source=identity, commands=[], selection_start_index=args.start_at)

def save():
    (args.output / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')

def invoke(command, label, allow_failure=False):
    assert source_map(source) == identity, 'source changed before verification'
    row = dict(command=command, label=label, state='running', started_unix=time.time())
    report['commands'].append(row); save()
    log_path = args.output / (label + '.log')
    print(label, flush=True)
    with log_path.open('x') as log:
        process = subprocess.Popen(command, cwd=source, stdout=log, stderr=subprocess.STDOUT)
        previous_size = 0
        while True:
            try:
                code = process.wait(timeout=15)
                break
            except subprocess.TimeoutExpired:
                size = log_path.stat().st_size
                if size > previous_size:
                    print(f'{label}: {size} diagnostic bytes', flush=True)
                    previous_size = size
        result = subprocess.CompletedProcess(command, code)
    row.update(exit_code=result.returncode, finished_unix=time.time(), state='closed',
        log_sha256=hashlib.sha256(log_path.read_bytes()).hexdigest())
    save()
    if result.returncode and not allow_failure:
        print(log_path.read_text()[-15000:], flush=True)
        raise RuntimeError(f'{label}: exit {result.returncode}')
    assert source_map(source) == identity, 'source changed during verification'
    return log_path, row

save()
if args.stage == 'build':
    command = ['cargo', 'build', '--locked', '--offline', '--release', '--jobs', '1',
        '-p', 'scriptw-cli', '--bin', 'scriptw', '--example', 'runtime_baseline',
        '--example', 'runtime_boundaries', '--example', 'runtime_policy_break_even',
        '--message-format=json']
    invoke(command, 'cargo-build')
    (args.output / 'bin').mkdir()
    report['binaries'] = []
    for name, path in [('scriptw', 'scriptw'), ('runtime_baseline', 'examples/runtime_baseline'),
                       ('runtime_boundaries', 'examples/runtime_boundaries'),
                       ('runtime_policy_break_even', 'examples/runtime_policy_break_even')]:
        original = base / 'build/release' / path
        saved = args.output / 'bin' / name
        subprocess.run(['cp', '--reflink=auto', '--preserve=mode,timestamps', str(original), str(saved)], check=True)
        report['binaries'].append(dict(file=name, sha256=hashlib.file_digest(saved.open('rb'), 'sha256').hexdigest()))
elif args.stage == 'python':
    modules = ['test_benchmark_metrics', 'test_performance_corpus', 'test_performance_study',
        'test_limited_verification', 'test_benchmark_boundaries', 'test_boundary_corpus',
        'test_boundary_process', 'test_policy_break_even', 'test_startup_retention_cohort']
    invoke([sys.executable, '-B', '-m', 'unittest', *['scripts.tests.' + m for m in modules], '-v'], 'python-performance')
else:
    if args.stage == 'focused':
        selections = [
            ('scriptw-ir', ['--lib'], 'tests::strict_'),
            ('scriptw-aot-wasm', ['--lib'], 'gc_types::type_registration_tests::'),
            ('scriptw-aot-wasm', ['--lib'], 'strict_public_portable_package_codec'),
            ('scriptw-aot-wasm', ['--lib'], 'unobserved_arguments::'),
            ('scriptw-aot-wasm', ['--lib'], 'array_data_producers::'),
            ('scriptw-aot-wasm', ['--lib'], 'call_arity::'),
            ('scriptw-aot-wasm', ['--test', 'emission'], 'property_read_plans::'),
            ('scriptw-aot-wasm', ['--test', 'emission'], 'packed_array_storage::'),
            ('scriptw-engine', ['--lib'], 'compiler_cache_identity::'),
            ('scriptw-engine', ['--lib'], 'compiler_identity::'),
            ('scriptw-engine', ['--lib'], 'runtime_profile::'),
            ('scriptw-engine', ['--lib'], 'portable_bundle::'),
            ('scriptw-engine', ['--lib'], 'embedded_runtime::matched_capacity::'),
            ('scriptw-engine', ['--test', 'aot_gc_entries'], 'aot_gc_compact_data_storage::'),
            ('scriptw-engine', ['--test', 'aot_gc_entries'], 'aot_gc_packed_array_storage::'),
            ('scriptw-engine', ['--test', 'aot_language'], 'aot_unobserved_arguments::'),
            ('scriptw-engine', ['--test', 'aot_language'], 'aot_packed_array_producers::'),
            ('scriptw-cli', ['--example', 'runtime_boundaries'], ''),
        ]
    else:
        plan = json.loads((base / 'after/affected-native-plan/receipt.json').read_text())
        selections = [(row['package'], row['selector'], '') for row in plan['cases']]
        selections += [('scriptw-ir', ['--lib'], ''),
                       ('scriptw-cli', ['--example', 'runtime_baseline'], ''),
                       ('scriptw-cli', ['--example', 'runtime_boundaries'], '')]
    report['total_passed'] = 0
    for index, (package, selector, selected) in enumerate(selections[args.start_at:], start=args.start_at):
        label = f'{index:02}-{package}-{selector[-1]}-{selected.replace(":", "_") or "all"}'
        command = ['cargo', 'test', '--locked', '--offline', '--release', '--jobs', '1', '-p', package,
                   *selector, *([selected] if selected else [])]
        inventory_log, inventory_row = invoke(command + ['--', '--list', '--include-ignored'], label + '-inventory')
        names = parse_inventory(inventory_log.read_text())
        inventory_row['inventory'] = names; save()
        run_log, run_row = invoke(command + ['--', '--test-threads=1', '--include-ignored'], label + '-run', allow_failure=args.stage == 'focused' or args.continue_after_failures)
        summaries = result_summaries(run_log.read_text())
        if len(summaries) != 1 or summaries[0][:5] != ('ok', str(len(names)), '0', '0', '0'):
            run_row['summaries'] = summaries
            report.setdefault('failures', []).append(label)
            save()
            if args.stage != 'focused' and not args.continue_after_failures:
                raise RuntimeError(f'wrong executed inventory: {label}: {summaries}')
            print('FAILED focused scope; retained logs:', label, flush=True)
            continue
        if not selected and summaries[0][5] != '0':
            raise RuntimeError('full target unexpectedly filtered tests')
        run_row.update(inventory=names, summaries=summaries)
        report['total_passed'] += len(names); save()
report.update(complete=not report.get('failures'), source_unchanged=source_map(source) == identity,
    resources={name:(kernel_group() / name).read_text().strip() for name in
        ('memory.max', 'memory.peak', 'memory.swap.max', 'memory.oom.group')},
    affinity=sorted(os.sched_getaffinity(0)))
save()
print('Completed', args.stage, report.get('total_passed', ''), 'failed scopes', report.get('failures', []), flush=True)
if report.get('failures'):
    raise SystemExit(1)
