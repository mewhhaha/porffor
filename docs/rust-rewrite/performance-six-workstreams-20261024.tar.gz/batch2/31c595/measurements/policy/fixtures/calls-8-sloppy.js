(function(){function consume(a0,a1,a2,a3,a4,a5,a6,a7){return 1;}var sum=0;for(var i=0;i<1024;i++)sum+=consume(i+0,i+1,i+2,i+3,i+4,i+5,i+6,i+7);print(sum);})();
