(function(){function take(o){return o.a+o.b+o.c;}var sum=0;for(var i=0;i<1024;i++){sum+=take({a:i,b:i+1,c:i+2});}print(sum);})();
