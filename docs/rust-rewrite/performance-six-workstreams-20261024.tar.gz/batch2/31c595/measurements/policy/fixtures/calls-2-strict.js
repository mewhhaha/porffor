(function(){"use strict";function consume(a0,a1){return 1;}var sum=0;for(var i=0;i<1024;i++)sum+=consume(i+0,i+1);print(sum);})();
