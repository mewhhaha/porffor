(function(){function consume(){return 1;}var sum=0;for(var i=0;i<1024;i++)sum+=consume();print(sum);})();
