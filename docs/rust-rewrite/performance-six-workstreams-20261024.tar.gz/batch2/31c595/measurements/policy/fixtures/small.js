print(42);
