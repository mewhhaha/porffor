(function(){var rows=[];var sum=0;for(var i=0;i<1024;i++){rows.push({a:i,b:i+1,c:i+2});}for(var j=0;j<rows.length;j++)sum+=rows[j].a+rows[j].b+rows[j].c;print(sum);})();
