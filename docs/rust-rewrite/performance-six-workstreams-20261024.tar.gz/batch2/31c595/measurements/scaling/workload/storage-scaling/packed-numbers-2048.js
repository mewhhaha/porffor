(function(){var a=[];for(var i=0;i<2048;i++)a.push(i);var sum=0;for(var j=0;j<a.length;j++)sum+=a[j];print(sum);})();
