(function(){var rows=[];for(var i=0;i<512;i++)rows.push({p0:i+0,p1:i+1,p2:i+2,p3:i+3});var sum=0;for(var j=0;j<rows.length;j++)sum+=rows[j].p0+rows[j].p1+rows[j].p2+rows[j].p3;print(sum);})();
