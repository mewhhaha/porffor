(function(){var rows=[];for(var i=0;i<2048;i++)rows.push({p0:i+0});var sum=0;for(var j=0;j<rows.length;j++)sum+=rows[j].p0;print(sum);})();
