print('scaling-control');
