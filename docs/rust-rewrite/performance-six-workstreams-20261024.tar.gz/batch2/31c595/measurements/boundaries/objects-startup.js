(function () {

function batch(seed) {
var a=[];for(var i=0;i<512;i++)a.push({x:i+seed,y:2*i+1});var s=0;for(var i=0;i<a.length;i++)s+=a[i].x+a[i].y;return s;
}
print(batch(0));
})();
