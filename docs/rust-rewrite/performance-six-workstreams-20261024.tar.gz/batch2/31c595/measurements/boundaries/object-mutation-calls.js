(function () {

function batch(seed) {
var a={x:seed,y:7};var s=0;for(var i=0;i<512;i++){a.x=i+seed;delete a.y;a.y=i+1;s+=a.x+a.y;}return s;
}
var result;
for (var warmup = 0; warmup < 10; warmup++) {
  result = batch(warmup % 8);
  print('warmup:' + warmup + ':' + result);
}
print('scriptw:call:ready');
for (var sample = 0; sample < 7; sample++) {
  print('scriptw:call:start:' + sample);
  result = batch(sample % 8);
  print('scriptw:call:end:' + sample);
  print('sample:' + sample + ':' + result);
}
})();
