(function () {

function batch(seed) {
var a=[];for(var i=0;i<256;i++)a.push({x:i+seed,y:i*2});var b=JSON.parse(JSON.stringify(a));var s=0;for(var i=0;i<b.length;i++)s+=b[i].x+b[i].y;return s;
}
print(batch(0));
})();
