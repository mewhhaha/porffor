(function () {

function batch(seed) {
var a={x:seed,y:7};var s=0;for(var i=0;i<512;i++){a.x=i+seed;delete a.y;a.y=i+1;s+=a.x+a.y;}return s;
}
print(batch(0));
})();
