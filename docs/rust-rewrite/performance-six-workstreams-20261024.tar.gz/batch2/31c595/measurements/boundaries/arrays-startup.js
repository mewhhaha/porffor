(function () {

function batch(seed) {
var a=[];for(var i=0;i<2048;i++)a.push(i+seed);var s=0;for(var i=0;i<a.length;i++)s+=a[i];return s;
}
print(batch(0));
})();
