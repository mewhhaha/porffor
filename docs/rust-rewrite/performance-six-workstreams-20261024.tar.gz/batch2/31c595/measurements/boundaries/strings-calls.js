(function () {

function batch(seed) {
var n=0;for(var i=0;i<128;i++){var s='a'.repeat(64)+seed;n+=s.slice(1).length+s.indexOf(String(seed));}return n;
}
var result;
for (var warmup = 0; warmup < 10; warmup++) {
  result = batch(warmup % 8);
  print('warmup:' + warmup + ':' + result);
}
print('scriptw:call:ready');
for (var sample = 0; sample < 7; sample++) {
  print('scriptw:call:start:' + sample);
  result = batch(sample % 8);
  print('scriptw:call:end:' + sample);
  print('sample:' + sample + ':' + result);
}
})();
