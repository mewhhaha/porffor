(function () {

function batch(seed) {
var m=new Map();for(var i=0;i<512;i++)m.set('k'+i,i+seed);var s=0;for(var i=0;i<512;i++)s+=m.get('k'+i);return s;
}
var result;
for (var warmup = 0; warmup < 10; warmup++) {
  result = batch(warmup % 8);
  print('warmup:' + warmup + ':' + result);
}
print('scriptw:call:ready');
for (var sample = 0; sample < 7; sample++) {
  print('scriptw:call:start:' + sample);
  result = batch(sample % 8);
  print('scriptw:call:end:' + sample);
  print('sample:' + sample + ':' + result);
}
})();
