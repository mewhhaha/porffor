(function () {
function step(x) { return x + 1; }
function batch(seed) {
var s=0;for(var i=0;i<1024;i++)s+=step(i+seed);return s;
}
print(batch(0));
})();
