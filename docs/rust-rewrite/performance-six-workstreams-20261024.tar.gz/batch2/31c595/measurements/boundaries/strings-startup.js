(function () {

function batch(seed) {
var n=0;for(var i=0;i<128;i++){var s='a'.repeat(64)+seed;n+=s.slice(1).length+s.indexOf(String(seed));}return n;
}
print(batch(0));
})();
