(function () {

function batch(seed) {
var a=[];for(var i=0;i<256;i++)a.push({x:i+seed,y:i*2});var b=JSON.parse(JSON.stringify(a));var s=0;for(var i=0;i<b.length;i++)s+=b[i].x+b[i].y;return s;
}
var result;
for (var warmup = 0; warmup < 10; warmup++) {
  result = batch(warmup % 8);
  print('warmup:' + warmup + ':' + result);
}
print('scriptw:call:ready');
for (var sample = 0; sample < 7; sample++) {
  print('scriptw:call:start:' + sample);
  result = batch(sample % 8);
  print('scriptw:call:end:' + sample);
  print('sample:' + sample + ':' + result);
}
})();
