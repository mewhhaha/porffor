import React from 'react';
import {renderToString} from 'react-dom/server.browser';
const e = React.createElement;
function App({name, items}) {
  const [count] = React.useState(() => items.length);
  return e('section', {className:'greeting', 'data-count':count},
    e('h1', null, 'Hello ', name),
    e('ul', null, items.map((item, i) => e('li', {key:i}, item))));
}
const Theme = React.createContext('light');
function Themed() { return e('span', {className:React.useContext(Theme), style:{marginTop:2,color:'red'}}, 'context'); }
const cases = [
  ['element', e('h1', {id:'hello'}, 'Hello Wasm')],
  ['component-state-list-escaping', e(App, {name:'<Wasm>', items:['<one>', 'two & three']})],
  ['context-style-fragment', e(React.Fragment, null, e(Theme.Provider, {value:'dark'}, e(Themed)), e('input', {disabled:true, defaultValue:'a"b'}))]
];
for (const [name, tree] of cases) print(JSON.stringify({react:React.version, name, html:renderToString(tree)}));
