(function () {
var fs=[function(x){return x+1;},function(x){return x+2;}];
function batch(seed) {
var s=0;for(var i=0;i<768;i++)s+=fs[i%2](i+seed);return s;
}
print(batch(0));
})();
