(function () {

function batch(seed) {
var a=[];for(var i=0;i<768;i++)a[i*2]=i+seed;var s=0;for(var i=0;i<a.length;i++)if(i in a)s+=a[i];return s;
}
print(batch(0));
})();
