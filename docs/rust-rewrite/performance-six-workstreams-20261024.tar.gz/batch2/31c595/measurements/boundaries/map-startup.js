(function () {

function batch(seed) {
var m=new Map();for(var i=0;i<512;i++)m.set('k'+i,i+seed);var s=0;for(var i=0;i<512;i++)s+=m.get('k'+i);return s;
}
print(batch(0));
})();
