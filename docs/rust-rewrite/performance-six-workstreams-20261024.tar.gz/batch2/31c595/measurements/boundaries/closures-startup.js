(function () {
var next=(function(){var n=0;return function(){return ++n;};})();
function batch(seed) {
var s=0;for(var i=0;i<512;i++)s+=next();return s;
}
print(batch(0));
})();
