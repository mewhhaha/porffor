"""Keep a resource receipt outside a potentially OOM-killed bounded scope."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
source = base / 'source'
if len(sys.argv) > 1 and sys.argv[1] == '--payload':
    marker = Path(sys.argv[2])
    sys.path.insert(0, str(source / 'scripts'))
    from limited_verification import kernel_group, require_kernel_budget
    require_kernel_budget(4096 * 1024**2)
    assert len(os.sched_getaffinity(0)) == 1
    marker.write_text(json.dumps(dict(cgroup=str(kernel_group()), affinity=sorted(os.sched_getaffinity(0)))))
    os.execvp(sys.argv[3], sys.argv[3:])

parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ['--'] else args.command
assert command
args.output.mkdir(parents=True, exist_ok=False)
marker = args.output / 'scope.json'
invocation = [sys.executable, '-B', str(source / 'scripts/limited_verification.py'), '--',
              sys.executable, '-B', str(Path(__file__).resolve()), '--payload', str(marker), *command]
report = dict(complete=False, invocation=invocation, started_unix=time.time(), resource_samples=[])
def save():
    pending = args.output / 'receipt.pending'
    pending.write_text(json.dumps(report, indent=2) + '\n')
    pending.replace(args.output / 'receipt.json')
save()
with (args.output / 'stdout.log').open('x') as stdout, (args.output / 'stderr.log').open('x') as stderr:
    child = subprocess.Popen(invocation, cwd=source, stdout=stdout, stderr=stderr)
    previous = None
    while True:
        if marker.exists():
            scope = json.loads(marker.read_text())
            group = Path(scope['cgroup'])
            values = dict(scope)
            for filename in ('memory.max', 'memory.peak', 'memory.swap.max', 'memory.oom.group', 'memory.events'):
                try:
                    values[filename] = (group / filename).read_text().strip()
                except FileNotFoundError:
                    pass
            if values != previous:
                report['resource_samples'].append(dict(unix=time.time(), **values))
                previous = values
                save()
        code = child.poll()
        if code is not None:
            break
        time.sleep(1)
report.update(complete=True, exit_code=code, finished_unix=time.time(),
              limitation='Last observed kernel counters retained outside the kill group; a disappearing scope may prevent a terminal counter read.')
save()
print(json.dumps(dict(exit_code=code, receipt=str(args.output / 'receipt.json'))), flush=True)
raise SystemExit(code)
