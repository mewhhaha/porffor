"""Publish sealed, source-bound performance evidence after the final replay."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

base = Path(__file__).resolve().parent
root = base.parent.parent
checkpoint = base / 'batch2/31c595'
read = lambda path: json.loads(path.read_text())
digest = lambda path: hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
native = {stage: read(checkpoint / stage / 'receipt.json')
          for stage in ('build', 'focused', 'broad', 'python')}
assert all(row['complete'] and row['source_unchanged'] for row in native.values())
identity = native['build']['source']
assert all(row['source'] == identity for row in native.values())
assert identity['head'] == '31c5958d2dc60dcd3e20fdb8bd00a6821d63fb03'
replay = read(checkpoint / 'original-replay/verified-summary.json')
assert replay['source_commit'] == identity['head'] and replay['passed'] == 5583
snapshots = list((checkpoint / 'original-replay/snapshots').glob('exact-batch-*.json'))
assert len(snapshots) == 1
snapshot = read(snapshots[0])
assert snapshot['execution_backend'] == 'wasm-aot' and snapshot['timeout_test_ids'] == []
assert snapshot['total'] == 5587 and snapshot['passed'] == 5583
assert snapshot['counts_per_outcome'] == dict(Success=5583, Bug=4, Crash=0, NotImplemented=0)
assert set(snapshot['completed_test_ids']) == {
    row['execution_id'] for row in read(checkpoint / 'original-replay/summary.json')['results']}
replay = dict(replay, timeouts=0, native_snapshot=dict(path=snapshots[0].name,
    sha256=digest(snapshots[0]), compiler_identity=snapshot['compiler_identity'],
    pinned_revisions=snapshot['pinned_revisions']))
closed = read(checkpoint / 'closed-measurements-summary.json')
policy = read(checkpoint / 'policy-gc-startup-summary.json')
assert policy['complete']
verdict = read(checkpoint / 'inlining-admission-verdict.json')
assert verdict['admitted'] is False and verdict['supervisor_exit'] == -9
for stage in ('ssr-smoke', 'retention', 'ordinary', 'abba', 'scaling', 'boundaries', 'policy', 'gc-large', 'hash-abba'):
    assert read(checkpoint / 'measurements' / (stage + '-driver.json'))['complete']

patch = base / 'frozen-source-31c595.patch'
with patch.open('wb') as output:
    subprocess.run(['git', 'diff', '--binary', '8d24976c64432a5edd712e4fb91e58cac78db7ed', identity['head']],
                   cwd=root, stdout=output, check=True)
selected = set()
for name in ('first-batch-portable-summary.json', 'frozen-source-31c595.patch',
             'run_batch2_abba.py', 'prepare_scaling.py', 'measure_batch2.py',
             'run_all_measurements.py', 'run_large_gc_cohort.py', 'supervised_scope.py',
             'run_final_original_replay.py', 'run_final_checkpoint.py', 'verify_batch2.py',
             'publish_final_evidence.py', 'original-core-ids.txt', 'final-root-code-equivalence.json'):
    selected.add(base / name)
selected.update(base.glob('original*.json'))
selected.update(base.glob('original*.txt'))
selected.update(base.glob('*-commit.json'))
selected.add(base / 'after/first-batch-test-only-fix.patch')
for directory in (checkpoint, base / 'storage-scaling', base / 'same-realm-corpus',
                  base / 'before', base / 'after-d9e639', base / 'after-277213', base / 'after'):
    for path in directory.rglob('*'):
        if not path.is_file() or any(part in {'bin', 'native-cache', 'execution-cache', 'runtime-cache'}
                                     for part in path.relative_to(directory).parts):
            continue
        if path.suffix in {'.json', '.jsonl', '.log', '.stdout', '.stderr', '.snapshot', '.js', '.cjs', '.expected', '.txt'} or path.name in {'executions', 'LICENSE'}:
            selected.add(path)
for directory in (base / 'batch2/42f03c/regexp-memory-isolation',
                  base / 'batch2/42f03c/regexp-memory-trace',
                  base / 'batch2/99b8c0/regexp-memory-replay'):
    selected.update(directory.glob('*.json'))
    selected.update(directory.glob('*.log'))
selected.add(base / 'batch2/42f03c/confirmed-oom-systemd.log')
bundle = base / 'frozen-performance-sources.bundle'
refs = ['refs/codex/performance-20261024/' + name for name in (
    'control', 'initial-array-guard', 'array-ablation', 'first-batch',
    'pre-publication-outline', 'publication-outline', 'final')]
assert subprocess.check_output(['git', 'rev-parse', refs[-1]], cwd=root, text=True).strip() == identity['head']
subprocess.run(['git', '-c', 'pack.threads=1', 'bundle', 'create', str(bundle),
                *refs, '^8d24976c64432a5edd712e4fb91e58cac78db7ed'], cwd=root, check=True)
selected.add(bundle)
assert all(path.is_file() and path.is_relative_to(base) for path in selected)
assert all(path.stat().st_size < 64 * 1024**2 for path in selected)
manifest = [dict(path=str(path.relative_to(base)), sha256=digest(path), bytes=path.stat().st_size)
            for path in sorted(selected)]
manifest_path = base / 'portable-evidence-manifest.json'
manifest_path.write_text(json.dumps(dict(schema='scriptw-performance-evidence-files-v1', files=manifest,
    exclusions='Compiler executables, native images/caches, P/R Wasm and V8 cachedData payloads are excluded. Their identities remain in the raw receipts; the frozen source patch and exact fixture bytes support regeneration.'), indent=2) + '\n')
selected.add(manifest_path)
destination = root / 'docs/rust-rewrite'
archive = destination / 'performance-six-workstreams-20261024.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as output:
    for path in sorted(selected):
        output.add(path, arcname=str(path.relative_to(base)), recursive=False)
summary = dict(schema='scriptw-six-workstreams-checkpoint-v1', complete=True, refresh_date='2026-10-24',
    source=identity, control_commit='d89fd40689f60d94f14fa7800c180be89cfdd66a',
    storage_control_commit='30fc1931471646253e339100a6d392b2337a373b',
    verification=dict(focused_passed=70, full_affected_native_passed=5633, python_passed=93,
        overlap='The focused tests and 28-test emission target are included in the full affected scopes; do not add them.',
        original_selected_replay=replay, full_suite='Historical102994-suite result remains bound to b9ecfe64b; not refreshed.'),
    resources=dict(kernel_memory_max_bytes=4096*1024**2, swap_max_bytes=0, cpus=1, serial_workers=True,
        native_checkpoint=read(checkpoint / 'native-checkpoint-supervision/receipt.json'),
        measurements=read(checkpoint / 'measurement-supervision/receipt.json')),
    tables=closed['tables'], measured_tradeoffs=closed['tradeoffs'],
    policy=policy['policy'], large_gc=policy['large_gc'],
    compiler_cache_hash_startup=policy['compiler_cache_hash_startup'],
    policy_conclusions=[row for row in policy['conclusions'] if row['topic'] != 'Native inlining'] + [
        dict(topic='Native inlining', finding=verdict['reason'],
             default_decision='Keep native inlining disabled; bounded whole-program admission failed at4GiB.')],
    inlining=verdict,
    archive=dict(file=archive.name, sha256=digest(archive), bytes=archive.stat().st_size,
                 manifest_sha256=digest(manifest_path), frozen_patch_sha256=digest(patch)),
    limitations=closed['limitations'])
(destination / 'performance-six-workstreams-20261024.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(dict(archive=str(archive), bytes=archive.stat().st_size, files=len(selected))))
