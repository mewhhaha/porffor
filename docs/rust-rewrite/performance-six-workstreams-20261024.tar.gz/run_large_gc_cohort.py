#!/usr/bin/env python3
"""Predeclared 8192-retained workload: Fast/SP/Disabled GC16/64/64/16.

Launch only after the final native checkpoint, under the existing 4-GiB,
zero-swap, one-CPU scope. Each child owns fresh Stores and Realms. This task
driver neither builds a binary nor changes product defaults or cache limits.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import sys

BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'source'
FIXTURES = BASE / 'after/baseline/workload'
CASE = 'retained-objects.js'
EXPECTED_COMMIT = '31c5958d2dc60dcd3e20fdb8bd00a6821d63fb03'
SAMPLES = 7
WARMUPS = 10
TIMEOUT = 900
ORDER = (16, 64, 64, 16)
sys.path.insert(0, str(SOURCE / 'scripts'))
from policy_break_even import validate
from benchmark_metrics import digest, measure_process, summary
from limited_verification import kernel_group, limited_environment, require_kernel_budget
from verification_identity import source_map


def require(condition, message):
    if not condition:
        raise ValueError(message)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def sha256(value):
    return isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def nonnegative(value):
    return type(value) is int and value >= 0


def resources():
    group = kernel_group()
    return dict(cgroup=str(group), affinity=sorted(os.sched_getaffinity(0)),
                **{name: (group / name).read_text().strip() for name in (
                    'memory.max', 'memory.swap.max', 'memory.oom.group',
                    'memory.peak', 'memory.events')})


def admit_identity(raw, artifacts, expected_source, executable, fixture, previous):
    require(raw.get('source_commit') == EXPECTED_COMMIT == expected_source['head'],
            'payload must be the final verified source commit')
    require(raw.get('executable_sha256') == executable and sha256(raw.get('source_fingerprint')),
            'loaded executable/compiler evidence differs')
    require(raw.get('source_sha256') == fixture, 'payload workload bytes differ')
    program = artifacts / 'program.wasm'
    require(program.is_file() and raw.get('program_sha256') == digest(program),
            'retained actual P bytes differ')
    require(type(raw.get('program_bytes')) is int and raw['program_bytes'] == program.stat().st_size > 0,
            'retained P extent differs')
    runtime = raw.get('linked_runtime')
    require(isinstance(runtime, dict) and set(runtime) == {'key', 'sha256', 'bytes'}
            and sha256(runtime.get('key')) and sha256(runtime.get('sha256'))
            and type(runtime.get('bytes')) is int and runtime['bytes'] > 0,
            'linked R identity is missing or malformed')
    require('native_inlining_limits' in raw and raw['native_inlining_limits'] is None,
            'this capacity experiment must keep native inlining disabled')
    boundaries = raw.get('boundaries')
    require(isinstance(boundaries, dict) and set(boundaries) == {'cold_compilation', 'execution', 'memory'}
            and all(isinstance(value, str) and value for value in boundaries.values()),
            'measurement boundary declarations are incomplete')
    identity = {name: raw[name] for name in (
        'source_commit', 'source_fingerprint', 'executable_sha256', 'source_sha256',
        'program_sha256', 'program_bytes', 'linked_runtime', 'boundaries')}
    require(previous is None or identity == previous, 'ABBA changed compiler/source/P/R identity or boundary')
    return identity


def admit_heap_and_loading(raw, capacity):
    for index, row in enumerate(raw['execution']):
        before, after = row.get('gc_capacity_before_bytes'), row.get('gc_capacity_after_bytes')
        require(nonnegative(before) and nonnegative(after) and after >= capacity * 1024**2,
                f'observation {index}: invalid actual GC capacity telemetry')
        loading = row.get('module_loading_ns')
        require(isinstance(loading, dict) and set(loading) == {'runtime', 'program', 'runtime_module_cache'}
                and nonnegative(loading['runtime']) and nonnegative(loading['program'])
                and loading['runtime_module_cache'] in ('Hit', 'Miss')
                and row['total_invocation_ns'] >= loading['runtime'] + loading['program'],
                f'observation {index}: invalid distinct R/P loading evidence')
        memory = row.get('process_memory')
        require(isinstance(memory, dict), f'observation {index}: missing process RSS status')
        if memory.get('status') == 'sampled':
            require(set(memory) == {'status', 'maximum_rss_bytes'}
                    and type(memory.get('maximum_rss_bytes')) is int and memory['maximum_rss_bytes'] > 0,
                    f'observation {index}: invalid sampled process RSS')
        else:
            require(memory.get('status') == 'unavailable' and set(memory) == {'status', 'reason'}
                    and isinstance(memory.get('reason'), str) and memory['reason'],
                    f'observation {index}: unavailable RSS must have an explicit reason')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runner', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--time', type=Path, required=True)
    parser.add_argument('--node', default='node')
    parser.add_argument('--idle-machine', action='store_true', required=True)
    args = parser.parse_args()
    require_kernel_budget(4096 * 1024**2)
    require(len(os.sched_getaffinity(0)) == 1, 'one inherited CPU is required')
    environment = limited_environment()
    for key in ('NODE_OPTIONS', 'SCRIPTW_WASM_TRACE', 'SCRIPTW_WASM_TRACE_DUMP'):
        require(not environment.get(key), f'unset unrelated instrumentation {key}')
    require(environment.get('SCRIPTW_COMPILER_CACHE_IMAGE_HASH', 'sha256') == 'sha256',
            'this experiment requires the default SHA256 compiler-cache cohort')
    runner, time_binary, output = args.runner.resolve(), args.time.resolve(), args.output_dir.resolve()
    require(runner.is_file() and runner.name == 'runtime_policy_break_even' and time_binary.is_file(),
            'existing frozen policy runner and GNU time are required')
    checkpoint = runner.parent.parent.parent
    require(checkpoint == BASE / 'batch2' / EXPECTED_COMMIT[:6]
            and runner.parent == checkpoint / 'build/bin', 'runner must come from the final sealed checkpoint')
    source = source_map(SOURCE)
    require(source['head'] == EXPECTED_COMMIT and source['tracked_patch_sha256'] == hashlib.sha256(b'').hexdigest()
            and not source['untracked'], 'final frozen source is not clean')
    checkpoint_proof = {}
    for stage in ('build', 'focused', 'broad', 'python'):
        path = checkpoint / stage / 'receipt.json'
        receipt = json.loads(path.read_text())
        require(receipt.get('complete') is True and receipt.get('source_unchanged') is True
                and receipt.get('source') == source and receipt.get('selection_start_index', 0) == 0,
                f'final {stage} checkpoint is incomplete or differs')
        checkpoint_proof[stage] = dict(path=str(path), sha256=digest(path))
    executable = digest(runner)
    build = json.loads((checkpoint / 'build/receipt.json').read_text())
    binary = [entry for entry in build['binaries'] if entry.get('file') == runner.name]
    require(len(binary) == 1 and binary[0]['sha256'] == executable, 'frozen runner differs from build receipt')
    fixture_path, manifest_path = FIXTURES / CASE, FIXTURES / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    require(manifest.get('schema') == 'scriptw-v8-workloads-v1', 'unsupported existing fixture manifest')
    selected = [entry for entry in manifest.get('execution', []) if entry.get('file') == CASE]
    require(len(selected) == 1 and isinstance(selected[0].get('stdout'), str), 'existing fixture output is missing')
    expected, fixture_hash, manifest_hash = selected[0]['stdout'], digest(fixture_path), digest(manifest_path)
    node_path = shutil.which(args.node)
    require(node_path is not None, 'independent Node reference is required')
    node = Path(node_path).resolve()
    output.mkdir(parents=True, exist_ok=False)
    report = dict(schema='scriptw-large-retained-gc-abba-v1', complete=False, started_at=stamp(),
        source=source, checkpoint_receipts=checkpoint_proof, script_sha256=digest(Path(__file__)),
        runner=dict(path=str(runner), sha256=executable), gnu_time=dict(path=str(time_binary), sha256=digest(time_binary)),
        fixture=dict(path=str(fixture_path), sha256=fixture_hash, manifest_path=str(manifest_path),
                     manifest_sha256=manifest_hash, case=CASE, expected_stdout=expected,
                     retained_rows=8192, indexed_reads=32768),
        tooling_sha256={name: digest(SOURCE / 'scripts' / name) for name in (
            'policy_break_even.py', 'benchmark_metrics.py', 'limited_verification.py', 'verification_identity.py')},
        configuration=dict(samples=SAMPLES, warmups=WARMUPS, order_mib=list(ORDER),
            native_mode='fast', register_allocation='single-pass', native_inlining='disabled',
            timeout_seconds=TIMEOUT, experiment='predeclared large-GC capacity observation, not a short screen'),
        resources_before=resources(), worker_environment={name: environment[name] for name in (
            'CARGO_BUILD_JOBS', 'SCRIPTW_JOBS', 'RUST_TEST_THREADS', 'RAYON_NUM_THREADS',
            'SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES', 'SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES')},
        limitations=[
            'GC initial capacity and post-execution capacity are not live bytes, allocation counts or collection counts.',
            'Explicit cohorts share matching optimized-R production/host ISA/storage treatment; they cannot be compared with ordinary embedded-R timings to isolate GC effects.',
            'R serialized image digest/occupancy is not exposed by this runner; linked R source identity and actual matched-image outcomes are retained.',
            'Observed ABBA pairs are descriptive and are not confidence intervals or default-policy acceptance.',
            'Fresh Store/Realm execution includes bootstrap and completion. Whole-child RSS includes cold P/R compiler/image allocator retention.'],
        reference={}, runs=[], paired_observations=[])

    def save():
        pending = output / 'receipt.pending'
        pending.write_text(json.dumps(report, indent=2) + '\n')
        pending.replace(output / 'receipt.json')

    def unchanged():
        require(source_map(SOURCE) == source and digest(runner) == executable
                and digest(fixture_path) == fixture_hash and digest(manifest_path) == manifest_hash,
                'frozen source, executable, fixture or manifest changed')

    save()
    try:
        reference_env = dict(environment, NODE_DISABLE_COMPILE_CACHE='1')
        reference_env.pop('NODE_COMPILE_CACHE', None)
        reference_command = [str(node), '-e',
            "const fs=require('node:fs'),vm=require('node:vm');vm.runInNewContext(fs.readFileSync(process.argv[1],'utf8'),{print:x=>process.stdout.write(String(x)+'\\n')});",
            str(fixture_path)]
        report['reference'] = dict(state='running', command=reference_command, executable_sha256=digest(node))
        save()
        with (output / 'node.stdout').open('xb') as out, (output / 'node.stderr').open('xb') as err:
            account = measure_process(reference_command, cwd=SOURCE, env=reference_env,
                stdout=out, stderr=err, timeout=30, time_binary=str(time_binary))
        report['reference'].update(state='closed', accounting=account,
            stdout_sha256=digest(output / 'node.stdout'), stderr_sha256=digest(output / 'node.stderr'))
        save()
        require(account['exit_code'] == 0 and not account['timed_out']
                and (output / 'node.stdout').read_bytes() == expected.encode('utf-8'),
                'independent Node checksum differs from existing manifest')
        version = subprocess.run([str(node), '--version'], cwd=SOURCE, env=reference_env,
                                 capture_output=True, timeout=30, check=True)
        report['reference']['version'] = version.stdout.decode().strip()
        payload_environment = dict(environment, SCRIPTW_CACHE_DIR=str(output / 'native-cache'))
        identity = None
        for index, capacity in enumerate(ORDER):
            unchanged()
            label = f'{index:02}-gc{capacity}'
            artifacts = output / (label + '-artifacts')
            policy = dict(native_mode='fast', gc_initial_mib=capacity,
                          register_allocation='single-pass', native_inlining='disabled')
            command = [str(runner), str(FIXTURES), CASE, str(SAMPLES), str(WARMUPS),
                       'fast', str(capacity), 'single-pass', 'disabled', str(artifacts)]
            row = dict(label=label, policy=policy, command=command, cwd=str(SOURCE),
                       state='running', started_at=stamp(), timeout_seconds=TIMEOUT,
                       payload_environment_overrides={'SCRIPTW_CACHE_DIR': payload_environment['SCRIPTW_CACHE_DIR']})
            report['runs'].append(row)
            save()
            print('Large retained GC cohort:', label, flush=True)
            with (output / (label + '.json')).open('xb') as out, (output / (label + '.stderr')).open('xb') as err:
                row['accounting'] = measure_process(command, cwd=SOURCE, env=payload_environment,
                    stdout=out, stderr=err, timeout=TIMEOUT, time_binary=str(time_binary))
            row.update(state='closed', finished_at=stamp(),
                raw_sha256=digest(output / (label + '.json')), stderr_sha256=digest(output / (label + '.stderr')))
            save()
            require(row['accounting']['exit_code'] == 0 and not row['accounting']['timed_out'],
                    f'{label}: failed child; raw output and accounting retained')
            raw = json.loads((output / (label + '.json')).read_text())
            row['policy_summary'] = validate(raw, policy, CASE, expected, SAMPLES, WARMUPS)
            identity = admit_identity(raw, artifacts, source, executable, fixture_hash, identity)
            admit_heap_and_loading(raw, capacity)
            measured = raw['execution'][WARMUPS:]
            row.update(identity=identity,
                execution_ns=summary([entry['execution_and_completion_ns'] for entry in measured]),
                total_invocation_ns=summary([entry['total_invocation_ns'] for entry in measured]),
                gc_capacity_after_bytes=summary([entry['gc_capacity_after_bytes'] for entry in measured]),
                matched_runtime_image_cache=[entry['matched_runtime_image_cache'] for entry in raw['execution']],
                runtime_module_cache=[entry['module_loading_ns']['runtime_module_cache'] for entry in raw['execution']],
                process_memory=[entry['process_memory'] for entry in measured])
            unchanged()
            save()
        for a, b in ((0, 1), (3, 2)):
            before, after = report['runs'][a], report['runs'][b]
            report['paired_observations'].append(dict(gc16_run=before['label'], gc64_run=after['label'],
                saved_execution_ns=before['execution_ns']['median'] - after['execution_ns']['median'],
                saved_total_invocation_ns=before['total_invocation_ns']['median'] - after['total_invocation_ns']['median'],
                additional_whole_child_peak_rss_bytes=after['accounting']['peak_rss_bytes'] - before['accounting']['peak_rss_bytes']))
        report['observed_capacity_medians'] = {
            str(capacity): dict(execution_ns=statistics.median(
                row['execution_ns']['median'] for row in report['runs'] if row['policy']['gc_initial_mib'] == capacity),
                total_invocation_ns=statistics.median(
                row['total_invocation_ns']['median'] for row in report['runs'] if row['policy']['gc_initial_mib'] == capacity))
            for capacity in (16, 64)}
        report.update(complete=True, finished_at=stamp())
    except BaseException as error:
        report.update(failure=str(error), failed_at=stamp())
        raise
    finally:
        report['resources_after'] = resources()
        save()
    print(output / 'receipt.json')


if __name__ == '__main__':
    main()
