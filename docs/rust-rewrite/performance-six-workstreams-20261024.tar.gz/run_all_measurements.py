"""Run the admitted measurement stages in series, idle of native verification."""
import argparse
from pathlib import Path
import subprocess
import sys

base = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--checkpoint', type=Path, required=True)
args = parser.parse_args()
for stage in ('ssr-smoke', 'retention', 'ordinary', 'abba', 'scaling', 'boundaries', 'policy', 'gc-large', 'hash-abba'):
    print('Begin measurement stage', stage, flush=True)
    subprocess.run([sys.executable, '-B', str(base / 'measure_batch2.py'),
                    '--checkpoint', str(args.checkpoint.resolve()), '--stage', stage],
                   cwd=base / 'source', check=True)
    print('Passed measurement stage', stage, flush=True)
print('Complete all serial measurement stages', flush=True)
