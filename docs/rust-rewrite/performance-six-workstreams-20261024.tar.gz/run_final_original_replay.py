"""Replay the original exact selected IDs; retain the real known-failure exit."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

base = Path(__file__).resolve().parent
source = base / 'source'
sys.path.insert(0, str(source / 'scripts'))
from limited_verification import require_kernel_budget
from verification_identity import source_map

require_kernel_budget(4096 * 1024**2)
assert len(os.sched_getaffinity(0)) == 1
identity = source_map(source)
checkpoint = base / 'batch2' / identity['head'][:6]
for stage in ('build', 'focused', 'broad', 'python'):
    row = json.loads((checkpoint / stage / 'receipt.json').read_text())
    assert row['complete'] and row['source_unchanged'] and row['source'] == identity
    assert row.get('selection_start_index', 0) == 0
for stage in ('ssr-smoke', 'retention', 'ordinary', 'abba', 'scaling', 'boundaries', 'policy', 'gc-large', 'hash-abba'):
    assert json.loads((checkpoint / 'measurements' / (stage + '-driver.json')).read_text())['complete']
binary = checkpoint / 'build/bin/scriptw'
build = json.loads((checkpoint / 'build/receipt.json').read_text())
expected_hash = next(row['sha256'] for row in build['binaries'] if row['file'] == 'scriptw')
assert hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest() == expected_hash
selection = base / 'original-core-ids.txt'
list_hash = hashlib.sha256(selection.read_bytes()).hexdigest()
assert list_hash == '3ea8f95719876987e83739c20c1353fe63744ffee0031b913b355aa0a2022e76'
requested = {line for line in selection.read_text().splitlines() if line and not line.startswith('#')}
assert len(requested) == 5587
output = checkpoint / 'original-replay'
assert not output.exists()
# Only the payload's retention budget changes, after the unchanged kernel cap.
# The same-binary ABBA observed a large warm total-invocation improvement.
environment = dict(os.environ, SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES='2',
                   SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES=str(128 * 1024**2))
command = [sys.executable, '-B', 'scripts/replay-test262-executions.py', str(selection),
           '--binary', str(binary), '--suite-root', 'test262/vendor/test262',
           '--output-dir', str(output), '--workers', '1', '--reuse-case-workers']
print('Final exact original-ID replay', identity['head'], flush=True)
result = subprocess.run(command, cwd=source, env=environment)
assert result.returncode in (0, 1), f'incomplete replay: exit {result.returncode}'
summary = json.loads((output / 'summary.json').read_text())
assert summary['binary_sha256'] == expected_hash and summary['execution_list_sha256'] == list_hash
assert summary['total'] == len(requested)
records = summary['results']
assert len(records) == len(requested) and {row['execution_id'] for row in records} == requested
assert all('infrastructure_error' not in row for row in records)
previous = json.loads((base / 'after/original-replay/verified-summary.json').read_text())
failures = sorted(row['execution_id'] for row in records if row['outcome'] != 'Success')
assert failures == previous['known_failures'], f'changed failure set: {failures}'
assert summary['outcomes'] == dict(Success=5583, NotImplemented=0, Crash=0, Bug=4)
assert result.returncode == 1 and source_map(source) == identity
proof = dict(source_commit=identity['head'], source=identity,
             compiler_sha256=expected_hash, execution_list_sha256=list_hash,
             selected_total=len(requested), passed=summary['outcomes']['Success'],
             known_failures=failures, new_failures=[], crashes=0, unsupported=0,
             actual_command_exit=result.returncode,
             payload_cache_environment={key: environment[key] for key in (
                 'SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES', 'SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES')},
             cache_scope='Measured payload-only retention override under unchanged kernel4GiB/CPU1; no inferred R-hit/occupancy count.',
             scope='Exact native-inventory-bound selected executions; not a fresh full102994-suite result.')
(output / 'verified-summary.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof), flush=True)
raise SystemExit(result.returncode)
