import hashlib
import json
from pathlib import Path
import subprocess
import sys
base=Path(__file__).resolve().parent
source=base/'source'
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
checkpoint=base/'batch2'/commit[:6]
print('Final coherent native checkpoint',commit,flush=True)
for stage in ('build','focused','broad','python'):
 command=[sys.executable,str(base/'verify_batch2.py'),stage,'--output',str(checkpoint/stage)]
 print('Begin checkpoint stage',stage,flush=True)
 subprocess.run(command,cwd=source,check=True)
 receipt=json.loads((checkpoint/stage/'receipt.json').read_text())
 assert receipt['complete'] and receipt['source_unchanged'] and receipt['source']['head']==commit
 if stage=='build':
  full=checkpoint/'build/cargo-build.log';lines=[]
  for line in full.read_text().splitlines():
   try:json.loads(line)
   except ValueError:continue
   lines.append(line)
  assert json.loads(lines[-1])==dict(reason='build-finished',success=True)
  derived=checkpoint/'build/cargo.jsonl';derived.write_text('\n'.join(lines)+'\n')
  (checkpoint/'build/cargo-jsonl-proof.json').write_text(json.dumps(dict(source=full.name,source_sha256=hashlib.sha256(full.read_bytes()).hexdigest(),derived=derived.name,derived_sha256=hashlib.sha256(derived.read_bytes()).hexdigest(),description='Unchanged valid Cargo JSON records extracted after completion; full original retained.'),indent=2)+'\n')
 print('Passed checkpoint stage',stage,receipt.get('total_passed',''),flush=True)
print('Complete final coherent native and tooling checkpoint',commit,flush=True)
