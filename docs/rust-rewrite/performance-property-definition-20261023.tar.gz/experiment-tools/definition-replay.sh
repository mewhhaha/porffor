#!/bin/bash
set -euo pipefail
cd /workspace/lila-tooling-next
. /workspace/.scriptw-tools/activate.sh
export TMPDIR=/tmp
python3 -B scripts/limited_verification.py --cloud --cloud-cpus auto -- python3 -B scripts/replay-test262-executions.py target/performance-hills-20261021-attribution/candidate52-definition.executions --binary /tmp/scriptw-performance-candidate-5c63c6597/scriptw --suite-root /workspace/lila-tooling-next/test262/vendor/test262 --output-dir target/performance-hills-20261021-attribution/candidate52-definition-replay --workers 4 --reuse-case-workers
