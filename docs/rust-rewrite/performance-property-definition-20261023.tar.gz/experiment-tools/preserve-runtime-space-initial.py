"""Preserve closed histories and current producer bytes before native verification."""
import hashlib,json,os,shutil,stat,subprocess,tarfile
from pathlib import Path
r=Path('/workspace/lila-tooling-next');b=r/'target/performance-hills-20261021-attribution';release=Path('/workspace/porffor/target/release')
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
assert json.loads((b/'candidate52-product-timing-gates-complete.json').read_text())['complete']
def active_paths():
 paths=set()
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   paths.add((proc/'exe').resolve())
   for fd in (proc/'fd').iterdir():
    try:paths.add(fd.resolve())
    except OSError:pass
   for line in (proc/'maps').read_text().splitlines():
    fields=line.split(maxsplit=5)
    if len(fields)==6 and fields[5].startswith('/'):paths.add(Path(fields[5]))
  except (OSError,RuntimeError):pass
 return paths

def archive(name,paths):
 assert all(p.is_file() and not p.is_symlink() for p in paths)
 out=b/name;out.mkdir(exist_ok=False);rows=[]
 for p in paths:
  s=p.stat();rows.append(dict(original=str(p),member=str(p).lstrip('/'),bytes=s.st_size,sha256=sha(p),mode=stat.S_IMODE(s.st_mode),mtime_ns=s.st_mtime_ns))
 packed=out/'payload.tar.zst'
 with packed.open('xb') as stream:
  child=subprocess.Popen(['zstd','-q','-1','-T1','--long=29','-c'],stdin=subprocess.PIPE,stdout=stream)
  with tarfile.open(fileobj=child.stdin,mode='w|',format=tarfile.PAX_FORMAT) as tar:
   for row in rows:tar.add(row['original'],arcname=row['member'],recursive=False)
  child.stdin.close();assert child.wait()==0
 child=subprocess.Popen(['zstd','-q','--long=29','-dc',str(packed)],stdout=subprocess.PIPE)
 with tarfile.open(fileobj=child.stdout,mode='r|') as tar:
  actual=[(m.name,m.size,hashlib.file_digest(tar.extractfile(m),'sha256').hexdigest()) for m in tar]
 assert child.wait()==0 and actual==[(x['member'],x['bytes'],x['sha256']) for x in rows]
 assert all(sha(x['original'])==x['sha256'] for x in rows)
 receipt=dict(complete=True,archive=str(packed),archive_sha256=sha(packed),archive_bytes=packed.stat().st_size,files=rows,policy='One lossless tar/zstd archive shares repeated payload bytes; every extracted member and original verified before any retirement. No shared-memory storage.')
 (out/'inventory.json').write_text(json.dumps(receipt,indent=2)+'\n');return receipt

old_dir=Path('/tmp/scriptw-performance-native-working-candidate50');cli_record=json.loads((b/'candidate52-preserved-current-cli.json').read_text());old=[*sorted(old_dir.iterdir()),Path(cli_record['storage'])]
assert not set(old)&active_paths()
# The historical CLI aliases were superseded by the candidate52 product. Old
# runtime writer aliases were detached before regeneration. No consumer remains.
for parent in [release,release/'deps',release/'examples',*list((release/'build').glob('scriptw-runtime-image-*/out'))]:
 for p in parent.iterdir():
  if p.is_symlink():assert p.resolve() not in old,('live alias',p)
closed=archive('candidate52-closed-source50-runtime-and-cli-archive',old)
for p in old:p.unlink()
print('Closed source50 exact history archived:',sum(x['bytes'] for x in closed['files']),'->',closed['archive_bytes'],flush=True)
events=[json.loads(x) for x in (b/'candidate52-product-cargo.jsonl').read_text().splitlines()]
producer,=[x for x in events if x.get('reason')=='build-script-executed' and 'scriptw-runtime-image#' in x['package_id']]
out=Path(producer['out_dir']);receipt=archive('candidate52-frozen-runtime-image-archive',sorted(out.iterdir()))
working=Path('/tmp/scriptw-performance-native-working-candidate52');working.mkdir(exist_ok=False)
large=[x for x in receipt['files'] if x['bytes']>=16_000_000];required=sum(x['bytes'] for x in large)
assert shutil.disk_usage('/tmp').free-required>=512*1024**2
for row in large:
 p=Path(row['original']);q=working/(row['sha256']+'-'+p.name);shutil.copy2(p,q);assert sha(q)==row['sha256'];row['working']=str(q)
for row in large:
 p=Path(row['original']);p.unlink();p.symlink_to(row['working'])
receipt['producer']=producer;receipt['working_bytes']=required
(b/'candidate52-runtime-images-preserved-before-native.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Current product R archived and staged:',required,'bytes; archive',receipt['archive_bytes'],flush=True)
print('Free bytes:',{x:shutil.disk_usage(x).free for x in ['/workspace','/tmp']},flush=True)
