"""Select complete original property families from the portable full campaign."""
import base64,gzip,hashlib,json,sys
from pathlib import Path
r=Path('/workspace/lila-tooling-next');b=r/'target/performance-hills-20261021-attribution';sys.path.insert(0,str(r/'scripts'))
from status_publication import load_publication
from test262_chart_evidence import checked_full_outcomes,FULL_EVIDENCE
record=json.loads((r/FULL_EVIDENCE).read_text());real=load_publication(r)[0]['real_suite'];snapshots={}
for row in record['native_snapshots']:
 payload=gzip.decompress(base64.b64decode(row['data'],validate=True));assert len(payload)==row['bytes'] and hashlib.sha256(payload).hexdigest()==row['sha256'];snapshots[row['name']]=json.loads(payload)
name=Path(real['snapshot_paths']['json']).name;outcomes=checked_full_outcomes(real,snapshots[name],snapshots)
prefixes=['built-ins/Object/defineProperty/','built-ins/Object/defineProperties/','built-ins/Reflect/defineProperty/','built-ins/Object/getOwnPropertyDescriptor/','built-ins/Object/getOwnPropertyDescriptors/','built-ins/Object/getOwnPropertyNames/','built-ins/Object/getOwnPropertySymbols/','built-ins/Object/keys/','built-ins/Object/assign/','built-ins/Object/freeze/','built-ins/Object/seal/','built-ins/Object/preventExtensions/','built-ins/Proxy/defineProperty/','language/expressions/object/']
failures={k for k,v in outcomes.items() if v!='Success'};assert len(failures)==4
selected=sorted({x for x in outcomes if any(x.split(':',1)[1].startswith(p) for p in prefixes)}|failures)
target=b/'candidate52-definition.executions';target.write_text('\n'.join(selected)+'\n')
report=dict(total=len(selected),full_evidence=FULL_EVIDENCE,full_evidence_sha256=hashlib.sha256((r/FULL_EVIDENCE).read_bytes()).hexdigest(),execution_list_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),family_counts={p:sum(x.split(':',1)[1].startswith(p) for x in selected) for p in prefixes},known_failures=sorted(failures),boundary='Complete original mode-specific affected families plus all four tracked failures; no fixture rewrites, skips, timeout changes or reclassification. Broader native acceptance remains required; this is not a new full suite.')
assert all(report['family_counts'].values()),report
(b/'candidate52-definition-selection.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
