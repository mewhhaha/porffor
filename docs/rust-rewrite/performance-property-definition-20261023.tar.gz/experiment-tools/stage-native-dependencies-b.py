import hashlib,json,os,shutil,sys
from pathlib import Path
r=Path('/workspace/lila-tooling-next');b=r/'target/performance-hills-20261021-attribution';release=Path('/workspace/porffor/target/release');stage=Path('/tmp/scriptw-performance-completed-product-libraries52');sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
files=[release/'deps'/name for name in ['libscriptw_intl-173aa706835fb879.rlib','libscriptw_intl-ee910b258edc7082.rlib','libscriptw_ir-82a11df9ee7fd1bd.rlib']];rows=[]
before={x:shutil.disk_usage(x).free for x in ['/workspace','/tmp']}
for p in files:
 assert p.is_file() and not p.is_symlink()
 digest=sha(p);q=stage/(digest+'-'+p.name);assert not q.exists();shutil.copy2(p,q);assert sha(q)==digest
 aliases=[p]+[x for x in release.glob(p.name.split('-')[0]+'.*') if x.is_file() and not x.is_symlink() and x.samefile(p)]
 rows.append(dict(original=str(p),storage=str(q),sha256=digest,bytes=p.stat().st_size,aliases=list(map(str,aliases))))
record=dict(files=rows,free_before=before)
(b/'candidate52-native-staged-dependencies-b.json').write_text(json.dumps(record,indent=2)+'\n')
for row in rows:
 for name in row['aliases']:
  p=Path(name);p.unlink();p.symlink_to(row['storage'])
record['free_after']={x:shutil.disk_usage(x).free for x in ['/workspace','/tmp']};(b/'candidate52-native-staged-dependencies-b.json').write_text(json.dumps(record,indent=2)+'\n')
sys.path.insert(0,str(r/'scripts'));from workspace_test_storage import storage_snapshot
receipt=storage_snapshot(release.parent,b/'candidate52b-native-checkpoint',dict(os.environ,TMPDIR='/tmp',CARGO_TARGET_DIR=str(release.parent)),native_processes=2,building=True)
(b/'candidate52b-pre-native-storage.json').write_text(json.dumps(receipt,indent=2)+'\n');assert receipt['sufficient'],receipt
assert shutil.disk_usage('/tmp').free>=449334638+2*256*1024**2
print('Native admission passes with preserved source/fixtures/dependencies:',record['free_after'])
