"""Actual emitted-Wasm correctness, with Node expected output; timing excluded."""
import hashlib
import json
import os
import subprocess
from pathlib import Path

root = Path('/workspace/lila-tooling-next')
base = root / 'target/performance-hills-20261021-attribution'
frozen = json.loads((base / 'candidate52-product-frozen.json').read_text())
binary = Path(next(r['storage'] for r in frozen if Path(r['storage']).name == 'scriptw'))
digest = hashlib.sha256(binary.read_bytes()).hexdigest()
assert digest == next(r['sha256'] for r in frozen if r['storage'] == str(binary))
out = base / 'candidate52-product-semantic-controls-final'
out.mkdir(exist_ok=False)
names = ['wasm_numeric_array_own_data_read', 'wasm_single_character_string_reads', 'wasm_string_char_at_core', 'wasm_string_at_core', 'wasm_for_of_string_iterator_protocol', 'wasm_numeric_imul_guard', 'wasm_numeric_imul_realms', 'wasm_map_get_or_insert_value_source', 'wasm_prepared_collection_hash', 'wasm_prepared_property_hash', 'wasm_runtime_empty_argument_storage', 'wasm_replacement_piece_assembly', 'wasm_replacement_aggregate_overflow',
         'wasm_regexp_runtime_constructor_program', 'wasm_string_symbol_hooks',
         'wasm_string_batched_concat', 'wasm_shared_empty_storage']
rows = []
for name in names:
    fixture = root / 'crates/scriptw-cli/tests/fixtures' / (name + '.js')
    node = subprocess.run(['node', *(['--expose-gc'] if name in ('wasm_replacement_piece_assembly','wasm_prepared_collection_hash','wasm_prepared_property_hash','wasm_runtime_empty_argument_storage') else []), '-e', 'globalThis.print=console.log;'+('globalThis.__scriptwCreateRealm=()=>({global:require("node:vm").runInNewContext("globalThis")});' if name == 'wasm_numeric_imul_realms' else '')+'require(process.argv[1])', str(fixture)],
                          cwd=root, capture_output=True, text=True, timeout=120)
    (out / (name + '.node.stdout')).write_text(node.stdout)
    (out / (name + '.node.stderr')).write_text(node.stderr)
    if name == 'wasm_map_get_or_insert_value_source':
        assert node.returncode == 1 and 'getOrInsert is not a function' in node.stderr
        oracle = 'existing repository assertions and boolean(true); stock Node lacks proposal methods'
    elif name == 'wasm_string_symbol_hooks':
        # Existing repo fixture requires a real HTMLDDA host intrinsic. Node
        # cannot supply it; use its existing CLI completion oracle, never fake it.
        assert node.returncode == 1 and '__scriptwCreateHTMLDDA is not defined' in node.stderr
        oracle = 'existing repository CLI fixture: native HTMLDDA, completion number262; Node unavailable'
    else:
        assert node.returncode == 0, (name, node.stderr)
        oracle = 'Node stdout plus existing fixture completion' + ('; real collection with --expose-gc' if name == 'wasm_replacement_piece_assembly' else '')
    env = dict(os.environ, SCRIPTW_CACHE_DIR=str(base / 'candidate52-semantic-cache'), SCRIPTW_WASM_TRACE='1')
    command = [str(binary), '--jobs', '1']
    if name in ('wasm_string_symbol_hooks', 'wasm_numeric_imul_realms'):
        # Match the existing CLI integration harness's explicit authority.
        command += ['--host-surface', 'test262']
    command += ['run', '--execution-backend', 'wasm', str(fixture)]
    run = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True, timeout=180)
    (out / (name + '.stdout')).write_text(run.stdout)
    (out / (name + '.stderr')).write_text(run.stderr)
    completions = ['undefined(undefined)']
    if name in ('wasm_string_char_at_core','wasm_string_at_core','wasm_for_of_string_iterator_protocol','wasm_numeric_imul_guard','wasm_numeric_imul_realms','wasm_regexp_runtime_constructor_program', 'wasm_map_get_or_insert_value_source'):
        completions = ['boolean(true)']
    elif name == 'wasm_string_symbol_hooks':
        completions = ['number(262)', 'number(262.0)']
    expected = [node.stdout + 'run outcome: RunOutcome { backend_used: WasmAot, note: "wasm-aot completion: ' + value + '" }\n'
                for value in completions]
    assert run.returncode == 0 and run.stdout in expected, (name, run.returncode, run.stdout, run.stderr[-5000:])
    assert 'runtime-native-bundle hit:' in run.stderr
    rows.append(dict(fixture=str(fixture.relative_to(root)), source_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),
                     command=command, exit_code=0, oracle=oracle, node_exit_code=node.returncode,
                     node_stdout=node.stdout, native_image_hit=True))
    print(name, 'PASS', flush=True)
(out / 'receipt.json').write_text(json.dumps(dict(complete=True, cli_sha256=digest,
    source_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    boundary='Compiled NativeHost ordinary-definition/prepared-key/runtime-empty-argv controls plus prior accepted-family regression controls; not performance observations.', cases=rows), indent=2) + '\n')
