from pathlib import Path
import hashlib,json,shutil
r=Path('/workspace/lila-tooling-next');b=r/'target/performance-hills-20261021-attribution';deps=Path('/workspace/porffor/target/release/deps')
names=['libscriptw_intl-4205c2381d33d731.rmeta','libscriptw_aot_wasm-4964bea01e9dc431.rmeta','libscriptw_ir-dc8b8508b93b5ed0.rmeta','libwasmparser-dd907eb4be34c8fd.rmeta','libscriptw_intl_collator_data-1cb40d042c39c661.rmeta']
d=Path('/tmp/scriptw-performance-check-metadata52');d.mkdir(exist_ok=False);rows=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={x:shutil.disk_usage(x).free for x in ['/workspace','/tmp']}
for name in names:
 p=deps/name;assert not p.is_symlink() and p.stat().st_nlink==1
 digest=sha(p);q=d/(digest+'-'+name);shutil.copy2(p,q);assert sha(q)==digest
 rows.append(dict(original=str(p),storage=str(q),sha256=digest,bytes=p.stat().st_size))
(b/'candidate52-preserved-check-metadata.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:
 p=Path(row['original']);p.unlink();p.symlink_to(row['storage'])
print('Preserved check-only metadata with identical logical inputs',sum(x['bytes'] for x in rows),'bytes',before,{x:shutil.disk_usage(x).free for x in ['/workspace','/tmp']})
