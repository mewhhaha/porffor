"""Preserve source48 images, reusing exact immutable archives across producers."""
import hashlib,json,os,shutil,stat,subprocess
from pathlib import Path
root=Path('/workspace/lila-tooling-next');base=root/'target/performance-hills-20261021-attribution'
events=[json.loads(x) for x in (base/'candidate52-product-cargo.jsonl').read_text().splitlines()]
record,=[r for r in events if r.get('reason')=='build-script-executed' and 'scriptw-runtime-image#' in r['package_id']]
out=Path(record['out_dir']);assert out.is_relative_to(Path('/workspace/porffor/target/release/build'))
archive=base/'candidate52-frozen-runtime-image-archive';archive.mkdir(exist_ok=False)
working=Path('/tmp/scriptw-performance-native-working-candidate52');working.mkdir(exist_ok=False)
small=base/'candidate52-product-producer-small-files';small.mkdir(exist_ok=False)
receipt=base/'candidate52-runtime-images-preserved-before-native.json';assert not receipt.exists()
prior={'files':[]}  # New exact archives; old shared-memory archives are unavailable.
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
rows=[]
for p in sorted(out.iterdir()):
 assert p.is_file() and not p.is_symlink(),p
 st=p.stat();digest=sha(p)
 row=dict(original=str(p),bytes=st.st_size,sha256=digest,mode=stat.S_IMODE(st.st_mode),mtime_ns=st.st_mtime_ns)
 if st.st_size<16_000_000:
  dest=small/p.name;shutil.copy2(p,dest);assert sha(dest)==digest
  row.update(storage=str(dest),preservation='raw frozen copy')
 else:
  matches=[r for r in prior['files'] if r['sha256']==digest and r.get('archive')]
  if matches:
   old,=matches;packed=Path(old['archive']);assert sha(packed)==old['archive_sha256']
  else:
   packed=archive/(digest+'-'+p.name+'.zst')
   subprocess.run(['zstd','-q','-1','-T1',str(p),'-o',str(packed)],check=True)
  child=subprocess.Popen(['zstd','-q','-dc',str(packed)],stdout=subprocess.PIPE)
  with child.stdout as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
  assert child.wait()==0 and actual==digest
  row.update(archive=str(packed),archive_sha256=sha(packed),working=str(working/(digest+'-'+p.name)),
             reused_immutable_archive=bool(matches),preservation='immutable exact archive plus separate mutable working alias')
 rows.append(row)
# Admission checks all copies together before staging any; compression is closed.
remaining=sum(r['bytes'] for r in rows if 'working' in r)
free=shutil.disk_usage('/tmp').free
assert free-remaining>=536_870_912,dict(free=free,all_staging_bytes=remaining,reserve=536_870_912)
receipt.write_text(json.dumps(dict(complete=False,producer=record,files=rows,aggregate_tmp_free_before_staging=free,aggregate_staging_bytes=remaining),indent=2)+'\n')
for row in rows:
 if 'working' not in row:continue
 p=Path(row['original']);dest=Path(row['working'])
 shutil.copy2(p,dest);assert sha(dest)==row['sha256'] and sha(p)==row['sha256']
 p.unlink();p.symlink_to(dest)
receipt.write_text(json.dumps(dict(complete=True,producer=record,files=rows,aggregate_tmp_free_before_staging=free,aggregate_staging_bytes=remaining,
 policy='Aggregate scratch admission before staging; exact archive reuse avoids redundant storage. Seven images remain independently comparable to later native producer.'),indent=2)+'\n')
print('Preserved all',len(rows),'product files; staged',remaining,'bytes; TMP free',shutil.disk_usage('/tmp').free,flush=True)
