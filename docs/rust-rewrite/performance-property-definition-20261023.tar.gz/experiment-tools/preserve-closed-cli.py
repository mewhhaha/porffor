import hashlib,json,os,shutil,subprocess
from pathlib import Path
r=Path('/workspace/lila-tooling-next');b=r/'target/performance-hills-20261021-attribution';p=Path('/workspace/porffor/target/release/scriptw')
assert not p.is_symlink();info=p.stat()
for entry in Path('/proc').iterdir():
 if not entry.name.isdigit():continue
 try: assert not (entry/'exe').samefile(p),f'running executable: {entry.name}'
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
digest=sha(p);d=Path('/tmp/scriptw-performance-retained-current-cli52');d.mkdir(exist_ok=False);q=d/(digest+'-scriptw')
identity=json.loads(subprocess.check_output([str(p),'compiler-identity'],cwd=r,text=True))
aliases=[p]+[x for x in p.parent.joinpath('deps').glob('scriptw-*') if x.is_file() and x.samefile(p)]
assert len(aliases)==info.st_nlink
shutil.copy2(p,q);assert sha(q)==digest
record=dict(before_free={x:shutil.disk_usage(x).free for x in ['/workspace','/tmp']},identity=identity,storage=str(q),sha256=digest,bytes=info.st_size,aliases=list(map(str,aliases)))
(b/'candidate52-preserved-current-cli.json').write_text(json.dumps(record,indent=2)+'\n')
for alias in aliases:alias.unlink();alias.symlink_to(q)
record['after_free']={x:shutil.disk_usage(x).free for x in ['/workspace','/tmp']}
(b/'candidate52-preserved-current-cli.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
