"""Compare independently completed producer bytes, then share exact working files."""
import hashlib,json,time
from pathlib import Path
r=Path('/workspace/lila-tooling-next');b=r/'target/performance-hills-20261021-attribution';run=b/'candidate52b-native-checkpoint'
product=json.loads((b/'candidate52-runtime-images-preserved-before-native.json').read_text());expected={Path(x['original']).name:x for x in product['files']};wanted='/workspace/porffor/target/release/build/scriptw-runtime-image-68ca4074ffcd8759/out';seen={}
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
while True:
 event=None
 for p in sorted(run.glob('*.build.jsonl')):
  old=seen.get(str(p),0)
  try:
   with p.open('rb') as stream:
    stream.seek(old)
    for line in stream:
     if not line.endswith(b'\n'):break
     old+=len(line)
     row=json.loads(line)
     if row.get('reason')=='build-script-executed' and row.get('out_dir')==wanted:event=row
   seen[str(p)]=old
  except FileNotFoundError:continue
  if event:break
 if event:break
 done=b/'candidate52b-native-memory.jsonl'
 if done.exists() and json.loads(done.read_text().splitlines()[-1]).get('type')=='completion':raise RuntimeError('No completed independent native runtime producer found')
 time.sleep(2)
out=Path(wanted);rows=[]
assert set(p.name for p in out.iterdir())==set(expected)
for p in sorted(out.iterdir()):
 row=expected[p.name];assert not p.is_symlink() and p.stat().st_size==row['bytes']
 digest=sha(p);assert digest==row['sha256'],(p,digest,row['sha256'])
 rows.append(dict(native=str(p),product=row['original'],bytes=row['bytes'],sha256=digest,working=row.get('working')))
receipt=dict(complete=True,source='5c63c6597383ba4d6f56e0780daac922798b1033',producer=event,files=rows,policy='Independent Cargo native producer completed before comparison; every byte matches the archived ordinary product producer. Only identical completed data files share a mutable working alias; immutable original bytes remain in the verified product archive.')
(b/'candidate52-independent-native-runtime-identity.json').write_text(json.dumps(receipt,indent=2)+'\n')
for row in rows:
 if not row['working']:continue
 p=Path(row['native']);target=Path(row['working']);assert sha(target)==row['sha256']
 p.unlink();p.symlink_to(target)
print('Independent native/product identity verified for all',len(rows),'files; shared',sum(x['bytes'] for x in rows if x['working']),'bytes',flush=True)
