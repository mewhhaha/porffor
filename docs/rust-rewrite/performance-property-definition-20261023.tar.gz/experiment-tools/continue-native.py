"""Continue only the never-started storage-deferred original native target."""
import json
import subprocess
import time
from pathlib import Path

base = Path('/workspace/lila-tooling-next/target/performance-hills-20261021-attribution')
memory = base / 'candidate52b-native-memory.jsonl'
while True:
    last = json.loads(memory.read_text().splitlines()[-1])
    if last.get('type') == 'completion': break
    time.sleep(2)
receipt = json.loads((base / 'candidate52b-native-checkpoint/receipt.json').read_text())
assert receipt['source_unchanged'] and receipt['shared_runtime_linker_unchanged']
assert [(c['target'], c['state']) for c in receipt['cases'] if c.get('state') != 'passed'] == [
    ('structure_language', 'failed'), ('scriptw_runtime_image', 'storage-deferred')]
assert all(last['memory_events_delta'].get(k, 0) == 0 for k in ['oom', 'oom_kill', 'oom_group_kill'])
print('Continuing original unexecuted runtime-image target; completed outcomes remain immutable', flush=True)
raise SystemExit(subprocess.call(['python3', '-B', '/tmp/scriptw-performance-batch23/watch-native-memory-d.py']))
