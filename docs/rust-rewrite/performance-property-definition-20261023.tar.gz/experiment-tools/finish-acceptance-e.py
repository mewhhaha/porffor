"""After the frozen native continuation, repair diagnostics and run original cases."""
import hashlib
import json
import subprocess
import time
from pathlib import Path

root = Path('/workspace/lila-tooling-next')
base = root / 'target/performance-hills-20261021-attribution'
batch = Path('/tmp/scriptw-performance-batch23')
memory = base / 'candidate52e-native-memory.jsonl'
while True:
    if memory.exists():
        last = json.loads(memory.read_text().splitlines()[-1])
        if last.get('type') == 'completion': break
    time.sleep(2)
assert last['exit_code'] == 0, last
receipt = json.loads((base / 'candidate52e-native-checkpoint/receipt.json').read_text())
assert receipt['source_unchanged'] and receipt['shared_runtime_linker_unchanged']
case, = receipt['cases']
assert case['target'] == 'scriptw_runtime_image' and case['state'] == 'passed'
assert case['outcomes'] == [dict(passed=3, failed=0, ignored=0)]
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
plan = json.loads((batch / 'guard-repair-plan.json').read_text())
for row in plan:
    assert sha(Path(row['target'])) == row['before_sha256']
    assert sha(Path(row['draft'])) == row['after_sha256']
for row in plan: Path(row['target']).write_bytes(Path(row['draft']).read_bytes())
print('Frozen native work complete; installed only the reviewed diagnostic/guard repair', flush=True)
def run(name, command):
    with (batch / (name + '.log')).open('x') as out:
        subprocess.run(command, cwd=root, stdout=out, stderr=subprocess.STDOUT, check=True)
run('source-guard-tooling-final', ['python3', '-B', 'scripts/tests/test_source_guard_runner.py'])
run('source-guards-final', ['bash', '-c', '. /workspace/.scriptw-tools/activate.sh && python3 -B scripts/limited_verification.py --cloud --cloud-cpus auto -- python3 -B scripts/check-source-guards.py --output target/performance-hills-20261021-attribution/candidate52-extended-source-guards'])
run('structural-checkpoint-c', ['python3', '-B', str(batch / 'watch-structural-memory-c.py')])
corrected = json.loads((base / 'candidate52c-structural-checkpoint/receipt.json').read_text())
assert corrected['source_unchanged'] and corrected['shared_runtime_linker_unchanged']
assert corrected['cases'][0]['outcomes'] == [dict(passed=151, failed=0, ignored=0)]
print('Both diagnostic targets and full Cargo language guards pass; starting 7174 original Test262 executions', flush=True)
with (batch / 'definition-replay.log').open('x') as out:
    code = subprocess.call(['python3', '-B', str(batch / 'watch-definition-replay.py')], cwd=root, stdout=out, stderr=subprocess.STDOUT)
assert code == 1, ('Expected original four ordinary failures; inspect exact receipt', code)
summary = json.loads((base / 'candidate52-definition-replay/summary.json').read_text())
assert summary['total'] == 7174 and summary['outcomes'] == dict(Success=7170, Bug=4, Crash=0, NotImplemented=0)
print('Affected original-case replay complete; exact identities and final evidence publication pending', flush=True)
