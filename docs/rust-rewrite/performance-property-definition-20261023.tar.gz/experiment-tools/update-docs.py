"""Apply current-state documentation only after validated evidence publication."""
import json
from pathlib import Path

root = Path('/workspace/lila-tooling-next')
evidence = json.loads((root / 'docs/rust-rewrite/performance-property-definition-20261023.json').read_text())
assert evidence['complete'] and evidence['native_counts'] == dict(passed=3893, failed=0, ignored=0)
assert evidence['test262']['outcomes'] == dict(Success=7170, Bug=4, Crash=0, NotImplemented=0)
section = Path('/tmp/scriptw-performance-batch23/definition-checkpoint.md').read_text()
section = section.replace(' There are no repeated favorable-only retests.', '')
baseline = root / 'docs/rust-rewrite/v8-baseline.md'
text = baseline.read_text()
text = text.replace('# Local Wasmtime versus V8 baseline\n\n', '# Local Wasmtime versus V8 baseline\n\n' + section + '\n', 1)
baseline.write_text(text)

ledger = root / 'docs/performance-hills.md'
text = ledger.read_text()
intro = '''The [property-definition checkpoint](rust-rewrite/v8-baseline.md#prepared-property-definition-checkpoint--published-2026-10-23)
at `5c63c6597` completes **P020**: ordinary define-own now carries its prepared
hash through lookup and insertion. Long/short missing-key confirmation medians
fall 7.1%/5.5%, with an explicit 26.5-ms cold-start and 0.85-MiB CLI-size cost.
All **3,893 affected native tests** and seventeen compiled semantic families
pass. The original **7,174-case Test262 replay** returns **7,170 Success / four
known Bug / zero Crash / zero NotImplemented**. The ledger is now **22 terminal /
seven partial / 131 unresolved**. Full-suite chart and V8 table remain bound to
their separate source50 reports; slower initial measurements remain in the
[portable evidence](rust-rewrite/performance-property-definition-20261023.json).

'''
text = text.replace('## Progress ledger\n\n', '## Progress ledger\n\n' + intro, 1)
text = text.replace('the ledger remains **21 terminal / eight partial / 131 unresolved**.',
                    'that earlier ledger had **21 terminal / eight partial / 131 unresolved**.', 1)
lines = text.splitlines()
old = [line for line in lines if line.startswith('| P020 |')]
assert len(old) == 2 and old[0] == old[1]
new = '| P020 | **Verified improvement with startup/image tradeoffs** | Prepared hashes now span collection callbacks/kernels/deletion and ordinary define-own lookup/insertion, preserving fresh-empty rejection and descriptor identity. Long/short missing-key medians fall 7.1%/5.5%; cold startup adds 26.5 ms and CLI size 0.85 MiB. Seventeen compiled families, 3,893 native passes and 7,170/7,174 original Test262 successes; exactly four known failures remain. [Evidence](rust-rewrite/v8-baseline.md#prepared-property-definition-checkpoint--published-2026-10-23). |'
text = text.replace(old[0], new)
ledger.write_text(text)

inventory = root / 'docs/rust-rewrite/current-inventory.md'
text = inventory.read_text()
intro = '''Latest accepted product: **`5c63c6597`**, the
[prepared property-definition checkpoint](v8-baseline.md#prepared-property-definition-checkpoint--published-2026-10-23).
It closes **P020** with **3,893 native passes / zero failures / zero ignored**
across nine complete affected targets and seventeen compiled semantic families.
The **7,174 original affected Test262 executions** return **7,170 Success /
four known Bug / zero Crash / zero NotImplemented**. No new failures appear.
All source/linker fences and independent runtime-payload identities pass.
The stale language source-count guard is repaired and its entire 151-test target
rerun; the original failure, storage deferrals and rejected continuation launch
remain in [portable evidence](performance-property-definition-20261023.json).

Missing long/short-key definitions have paired medians 60.357→56.084 ms and
28.359→26.802 ms. Existing-key updates are flat; object/retained-row rounds
overlap. Cold startup rises 1,035.635→1,062.143 ms; the CLI grows 893,104 bytes
and process peak RSS roughly 1–1.5 MiB. Slower initial screens remain visible.
These measurements do not replace the separate source50 V8 table or full-suite
chart. Layout15 and the helper ABI are unchanged.

The early source check now covers both structural targets: **277 tests across
94 complete source-only modules in about ten seconds**. Eight typed modules
remain in the mandatory full Cargo targets; nine tooling controls pass.
Counts are **22 terminal decisions / seven partial / 131 unresolved** of 160 hills.
Broader release/all-feature, retention and remaining performance gates stay open.

'''
text = text.replace('## Current work\n\n', '## Current work\n\n' + intro, 1)
text = text.replace('Latest affected native checkpoint: **`b9ecfe64b`**', 'Previous affected native checkpoint: **`b9ecfe64b`**', 1)
text = text.replace('The new source-only early check runs **143 guards in about five seconds**,',
                    'The earlier source-only early check ran **143 guards in about five seconds**,', 1)
text = text.replace('Hill counts stay **21 terminal / eight partial / 131 unresolved**. This full\nrun closes',
                    'The full run retained **21 terminal / eight partial / 131 unresolved**; the\nnew property-definition checkpoint closes one more hill. This full run closes', 1)
inventory.write_text(text)

continuation = root / 'CONTINUE.md'
text = continuation.read_text().replace('**21 terminal decisions, eight partial/open outcomes,', '**22 terminal decisions, seven partial/open outcomes,', 1)
start = text.index('Latest accepted product:')
end = text.index('**The fresh full Test262 campaign', start)
text = text[:start] + '''Latest accepted product: **`5c63c6597`**. Prepared ordinary definitions close
P020 and pass **3,893 native tests / zero failures / zero ignored** across nine
affected targets and seventeen compiled semantic families. The **7,174 original
affected Test262 executions** give **7,170 Success / four known Bug / zero Crash /
zero NotImplemented**. No new failures appear. Runtime payload identities match.
[Measurements and raw evidence](docs/rust-rewrite/v8-baseline.md#prepared-property-definition-checkpoint--published-2026-10-23)
retain slower screens and the cold-start/image/RSS tradeoffs: roughly 7.1% faster
long-key insertion, 26.5-ms slower cold startup and 0.85-MiB larger CLI.
The README V8 table remains the separate source50 ordinary comparison.

''' + text[end:]
text = text.replace('README graph now bind this product directly.', 'README graph bind source50 (`b9ecfe64b`) directly.', 1)
start = text.index('The additive `scripts/check-source-guards.py`')
end = text.index('Tracked Cargo config is restored.', start)
text = text[:start] + '''The additive `scripts/check-source-guards.py` covers both structural targets:
277 source-only checks in about ten seconds, with nine tooling controls. Eight
typed modules remain in full Cargo; all 166 builtin and 151 language tests pass.
''' + text[end:]
start = text.index('1. Close remaining P020')
end = text.index('2. Evaluate P023/P112', start)
text = text[:start] + text[end:]
text = text.replace('2. Evaluate P023/P112', '1. Evaluate P023/P112', 1)
text = text.replace('3. Promote the standalone emitter', '2. Promote the standalone emitter', 1)
text = text.replace('4. Finish broader default/release', '3. Finish broader default/release', 1)
text = text.replace('Source50 is the next direct baseline;', 'Source52 is the next direct baseline;', 1)
text = text.replace('The new\n   all-feature native checkpoint is complete;', 'The earlier\n   maintenance all-feature checkpoint is complete;', 1)
text = text.replace('`/tmp/scriptw-performance-batch20`; raw results', '`/tmp/scriptw-performance-batch23`; raw results', 1)
marker = '\nCandidate47 compiled all12semantic families'
assert marker in text
text = text[:text.index(marker)].rstrip() + '\n'
continuation.write_text(text)

readme = root / 'README.md'
text = readme.read_text()
text = text.replace('[Prioritized performance backlog](docs/performance-hills.md).',
'''The newer `5c63c6597` property-definition change improves paired long-key
insertion by about 7%, with a 26.5-ms cold-start and 0.85-MiB CLI-size cost.
[Measurements and tradeoffs](docs/rust-rewrite/v8-baseline.md#prepared-property-definition-checkpoint--published-2026-10-23).
[Prioritized performance backlog](docs/performance-hills.md).''', 1)
start = text.index('The same compiler also passes **3,742 native tests**')
end = text.index('\n\n<!-- scriptw-test-graph:start -->', start)
text = text[:start] + '''The newer `5c63c6597` checkpoint passes **3,893 native tests** across nine
affected targets and seventeen compiled semantic families. Its **7,174-case
Test262 replay** has **7,170 passes and the same four failures**; the full chart
below remains bound to `b9ecfe64b`.
[Full-run evidence](docs/rust-rewrite/test262-current.md) ·
[Latest checkpoint](docs/rust-rewrite/v8-baseline.md#prepared-property-definition-checkpoint--published-2026-10-23).''' + text[end:]
readme.write_text(text)

workflow = root / 'docs/rust-rewrite/batch-workflow.md'
text = workflow.read_text()
start = text.index('The first command compiles an independent Rust test harness')
end = text.index('\nThe runner rejects', start)
text = text[:start] + '''The first command compiles independent Rust test harnesses without Cargo's
dependency graph. It reads both structural targets' actual module lists:
55 builtin source-only modules (143 tests) and 39 language modules (134 tests).
The eight complete typed IR/Wasm modules remain deferred to Cargo. Combined
compilation/execution took about ten seconds on this cloud checkout. Nine
tooling controls pass. Use `--target structure_builtins` or
`--target structure_language` for a focused diagnostic; the default runs both
and retains a failing first target while still checking the second.

This diagnostic does not replace the complete 166-test and 151-test Cargo
targets. The language target caught a stale exact API-call count left behind
by string optimizations. Its repaired check requires a live definition and
caller instead of a frozen number of references; obsolete APIs must still have
zero occurrences. Original native failures and all repaired-target results are
retained in [the checkpoint evidence](performance-property-definition-20261023.json).
''' + text[end:]
workflow.write_text(text)
print('Updated README, current inventory, continuation, hill ledger, measurement record and verification workflow')
