"""Validate and preserve the prepared ordinary-definition performance checkpoint."""
import gzip
import hashlib
import io
import json
from datetime import datetime, timezone
from pathlib import Path
from statistics import median
import subprocess
import tarfile

ROOT = Path('/workspace/lila-tooling-next')
BASE = ROOT / 'target/performance-hills-20261021-attribution'
SOURCE = '5c63c6597383ba4d6f56e0780daac922798b1033'
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
read = lambda name: json.loads((BASE / name).read_text())
native = read('candidate52b-native-checkpoint/receipt.json')
continued = read('candidate52e-native-checkpoint/receipt.json')
corrected = read('candidate52c-structural-checkpoint/receipt.json')
assert native['head'] == continued['head'] == corrected['head'] == SOURCE
assert all(r['source_unchanged'] and r['shared_runtime_linker_unchanged'] for r in [native, continued, corrected])
assert len(native['cases']) == len({(c['package'], c['target']) for c in native['cases']}) == 9
deferred, = [c for c in native['cases'] if c['state'] == 'storage-deferred']
assert deferred['target'] == 'scriptw_runtime_image' and 'outcomes' not in deferred
resumed, = continued['cases']
assert resumed['target'] == deferred['target'] and resumed['state'] == 'passed'
assert read('candidate52e-native-checkpoint/source-start.json') == read('candidate52b-native-checkpoint/source-start.json')
kept = [c for c in native['cases'] if c['state'] == 'passed'] + [resumed]
assert len(kept) == 8
assert all(c['state'] == 'passed' and c['exit_code'] == 0 and c['inventory_matches'] for c in kept)
old, = [c for c in native['cases'] if c['target'] == 'structure_language']
assert old['state'] == 'failed' and old['outcomes'] == [dict(passed=150, failed=1, ignored=0)]
new, = corrected['cases']
assert new['target'] == 'structure_language' and new['state'] == 'passed'
assert new['inventory_matches'] and new['exit_code'] == 0
assert new['outcomes'] == [dict(passed=151, failed=0, ignored=0)]
counts = {key: sum(o[key] for c in kept + [new] for o in c['outcomes']) for key in ['passed', 'failed', 'ignored']}
assert counts == dict(passed=3893, failed=0, ignored=0), counts
changes = subprocess.check_output(['git', 'diff', '--name-only', SOURCE, '--', 'crates', 'Cargo.toml', 'Cargo.lock', 'vendor'], cwd=ROOT, text=True).splitlines()
assert changes == ['crates/scriptw-aot-wasm/tests/structure_language/obsolete_core_backend_api_absence_structure.rs'], changes

controls = read('candidate52-product-semantic-controls-final/receipt.json')
assert controls['complete'] and controls['source_commit'] == SOURCE
assert len(controls['cases']) == 17 and all(c['exit_code'] == 0 and c['native_image_hit'] for c in controls['cases'])
guard_set = read('candidate52-extended-source-guards/receipt.json')
assert guard_set['passed'] and guard_set['exit_code'] == 0
assert {r['target'] for r in guard_set['targets']} == {'structure_builtins', 'structure_language'}
guards = {}
for row in guard_set['targets']:
    guard = read('candidate52-extended-source-guards/' + row['receipt'])
    assert guard['passed'] and guard['result_summaries'] == [['ok', str(len(guard['test_inventory'])), '0', '0', '0', '0']]
    assert len(guard['full_cargo_only_modules']) == 4
    guards[row['target']] = {k: guard[k] for k in ['compile_ns', 'execute_ns', 'result_summaries', 'source_modules', 'full_cargo_only_modules']}
frozen = read('candidate52-product-frozen.json')
for row in frozen:
    assert Path(row['storage']).stat().st_size == row['bytes'] and sha(row['storage']) == row['sha256']
images = read('candidate52-independent-native-runtime-identity.json')
assert images['complete'] and images['source'] == SOURCE and len(images['files']) == 10
for row in images['files']:
    assert sha(row['native']) == row['sha256']
    if not row['producer_path_only_difference']:
        assert row['exact_bytes'] and row['sha256'] == row['product_sha256']

replay = read('candidate52-definition-replay/summary.json')
requested = (BASE / 'candidate52-definition.executions').read_text().splitlines()
assert replay['total'] == len(requested) == len(set(requested)) == 7174
assert replay['binary_sha256'] == controls['cli_sha256']
assert replay['execution_list_sha256'] == sha(BASE / 'candidate52-definition.executions')
assert replay['outcomes'] == dict(Success=7170, Bug=4, Crash=0, NotImplemented=0)
assert {r['execution_id'] for r in replay['results']} == set(requested)
assert not any('infrastructure_error' in r for r in replay['results'])
known = {
    'sloppy-script:annexB/language/function-code/block-decl-func-skip-arguments.js',
    'sloppy-script:intl402/Temporal/ZonedDateTime/links.js',
    'strict-script:intl402/Temporal/ZonedDateTime/links.js',
    'sloppy-script:staging/sm/lexical-environment/block-scoped-functions-annex-b-label.js',
}
assert {r['execution_id'] for r in replay['results'] if r['outcome'] != 'Success'} == known
replay_memory = [json.loads(line) for line in (BASE / 'candidate52-definition-replay-memory.jsonl').read_text().splitlines()][-1]
assert replay_memory['type'] == 'completion' and replay_memory['exit_code'] == 1
assert all(replay_memory['memory_events_delta'].get(k, 0) == 0 for k in ['oom', 'oom_kill', 'oom_group_kill'])

cohorts = {}
for name in ['candidate52-definition-screen', 'candidate52-definition-confirm']:
    report = read(name + '/receipt.json')
    assert report['complete'] and report['source_commit'] == SOURCE
    assert report['identities']['after']['executable_sha256'] == controls['cli_sha256']
    for row in report['observations']:
        assert row['process']['exit_code'] == 0 and not row['process']['timed_out']
        assert len(row['execution_ns']) == report['configuration']['samples']
        assert row['median_ns'] == median(row['execution_ns'])
        raw_path = BASE / name / row['raw']
        assert sha(raw_path) == row['raw_sha256']
        raw = json.loads(raw_path.read_text())
        case, = raw['cases']
        samples = [r for r in case['observations'] if not r['warmup']]
        assert [r['execution_ns'] for r in samples] == row['execution_ns']
        expected = next(c['stdout'] for c in json.loads((Path(row['command'][1]) / 'manifest.json').read_text())['execution'] if c['file'] == row['file'])
        assert all(r['stdout'] == expected for r in case['observations'])
        assert all(r['module_cache'] == 'Hit' for r in samples)
        assert row['source_fingerprint'] == report['identities'][row['side']]['source_fingerprint']
        assert row['runner_sha256'] == raw['executable_sha256'] == report['runners'][row['side']]['sha256']
    rows = []
    for file in dict.fromkeys(r['file'] for r in report['observations']):
        row = dict(file=file)
        for side in ['before', 'after']:
            values = [r['median_ns'] for r in report['observations'] if r['file'] == file and r['side'] == side]
            row[side] = dict(round_medians_ns=values, median_ns=median(values))
        rows.append(row)
    cohorts[name] = rows
startup = read('candidate52-startup-paired/receipt.json')
assert startup['complete'] and startup['source_commit'] == SOURCE and len(startup['observations']) == 56
for event in startup['observations']:
    assert event['exit_code'] == 0 and not event['timed_out']
    for stream in ['stdout', 'stderr']:
        assert sha(BASE / 'candidate52-startup-paired' / event[stream]) == event[stream + '_sha256']
for mode, groups in startup['summaries'].items():
    for side, metrics in groups.items():
        rows = [r for r in startup['observations'] if r['mode'] == mode and r['side'] == side]
        for metric, values in metrics.items():
            medians = [median(r[metric] for r in rows if r['round'] == n) for n in sorted({r['round'] for r in rows})]
            assert values == dict(round_medians=medians, median_of_round_medians=median(medians))
memory = [json.loads(line) for line in (BASE / 'candidate52b-native-memory.jsonl').read_text().splitlines()]
assert memory[-1]['type'] == 'completion' and memory[-1]['exit_code'] == 1
assert all(memory[-1]['memory_events_delta'].get(k, 0) == 0 for k in ['oom', 'oom_kill', 'oom_group_kill'])

assets = {}
def add(path, name):
    assert name not in assets and not Path(name).is_absolute() and '..' not in Path(name).parts
    raw = path.read_bytes()
    assert not raw.startswith(b'\x7fELF'), path
    assets[name] = raw

allowed = {'.json', '.jsonl', '.log', '.txt', '.stdout', '.stderr', '.wasm', '.rs', '.js', '.gz', '.html', '.executions', '.attempts'}
for path in sorted(BASE.glob('candidate52*')):
    if path.is_file() and path.suffix in allowed:
        add(path, 'evidence/' + path.name)
    elif path.is_dir():
        for child in sorted(path.rglob('*')):
            relative = child.relative_to(path)
            if not child.is_file() or any('cache' in part or part.startswith(('cold-', 'hot-')) for part in relative.parts[:-1]):
                continue
            if child.suffix in allowed:
                add(child, 'evidence/' + str(child.relative_to(BASE)))
for path in sorted((ROOT / 'target/watched').glob('workspace-candidate52*.log')):
    add(path, 'watched/' + path.name)
def capture_transcripts(value):
    if isinstance(value, dict):
        for child in value.values(): capture_transcripts(child)
    elif isinstance(value, list):
        for child in value: capture_transcripts(child)
    elif isinstance(value, str) and value.endswith('.log'):
        path = ROOT / value
        if path.is_file() and path.resolve().is_relative_to(ROOT / 'target/watched'):
            name = 'watched/' + path.name
            if name not in assets: add(path, name)
for directory in ['candidate52b-native-checkpoint', 'candidate52c-structural-checkpoint', 'candidate52e-native-checkpoint']:
    for path in (BASE / directory).rglob('*.json'):
        capture_transcripts(json.loads(path.read_text()))
for path in sorted(Path('/tmp/scriptw-performance-batch23').iterdir()):
    if path.is_file() and path.suffix in {'.py', '.sh', '.rs', '.md', '.json', '.patch', '.log'}:
        add(path, 'experiment-tools/' + path.name)
for row in images['files']:
    assert sha(row['product']) == row['product_sha256']
    if row['bytes'] < 10000:
        for producer in ['native', 'product']:
            path = Path(row[producer])
            add(path, 'runtime-producers/' + producer + '/' + path.name)
for folder in ['v8_property_definition', 'v8_baseline', 'v8_key_arguments']:
    for path in sorted((ROOT / 'crates/scriptw-cli/tests/fixtures' / folder).glob('*')):
        if path.is_file(): add(path, 'workloads/' + folder + '/' + path.name)
for row in controls['cases']:
    path = ROOT / row['fixture']
    assert sha(path) == row['source_sha256']
    add(path, 'semantic-fixtures/' + path.name)
for name in ['scripts/check-source-guards.py', 'scripts/tests/test_source_guard_runner.py',
             'crates/scriptw-aot-wasm/tests/structure_language/obsolete_core_backend_api_absence_structure.rs', '.cargo/config.toml']:
    add(ROOT / name, 'repair/' + name)
inventory = [dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) for name, raw in sorted(assets.items())]
add_raw = json.dumps(inventory, indent=2).encode() + b'\n'
assets['inventory.json'] = add_raw
archive = ROOT / 'docs/rust-rewrite/performance-property-definition-20261023.tar.gz'
assert not archive.exists()
with archive.open('xb') as output, gzip.GzipFile(fileobj=output, mode='wb', mtime=0, filename='') as compressed, tarfile.open(fileobj=compressed, mode='w|') as tar:
    for name, raw in sorted(assets.items()):
        info = tarfile.TarInfo(name); info.size = len(raw); info.mode = 0o644
        tar.addfile(info, io.BytesIO(raw))
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == set(assets)
    for member in tar:
        assert tar.extractfile(member).read() == assets[member.name]
receipt = dict(schema='scriptw-property-definition-checkpoint-v1', complete=True,
    published_at=datetime.now(timezone.utc).isoformat(), measured_product_source=SOURCE,
    preceding_product_source='b9ecfe64bdac63e0553b8c38a178229056e38f73',
    native_counts=counts, compiled_semantic_families=17, original_structural_counts=old['outcomes'][0],
    corrected_structural_counts=new['outcomes'][0], source_equivalence='Production compiler inputs are unchanged after the measured source. Only the stale source-count integration test and standalone diagnostic/tooling/docs change; its complete 151-test Cargo target is rerun.',
    test262=dict(total=replay['total'], outcomes=replay['outcomes'], known_failures=sorted(known), execution_list_sha256=replay['execution_list_sha256'], full_suite=False),
    paired_cohorts=cohorts, startup_summaries=startup['summaries'], frozen_products=frozen,
    native_memory_completion=memory[-1], collision_controls=read('candidate52-existing-collision-controls.json'),
    replay_memory_completion=replay_memory,
    fast_source_guards=guards, tooling_control_tests=9,
    hill_terminal_count=22, hill_partial_count=7, hill_unresolved_count=131,
    archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive), members=len(assets), inventory_sha256=hashlib.sha256(add_raw).hexdigest()),
    limitations=[
        'Affected release native scopes and original Test262 families; broader release/all-feature acceptance remains open.',
        'All slower screens, the original stale-guard failure, storage deferrals and rejected continuation launch remain in the archive.',
        'Paired medians are descriptive; no statistical significance or isolated per-change attribution is claimed.',
        'Cold startup is about 26.5ms slower; executable size increases 893104 bytes and process RSS rises about 1-1.5MiB.',
        'Existing-key, object and retained-row confirmation rounds overlap. Integer screen is roughly flat; its later drop is not attributed to this optimization.',
        'The README V8 table and canonical full-suite graph remain bound to their separately identified source50 reports.',
        'Twenty older shared-memory archives remain unavailable; the current product and source50 runtime archive are verified.',
        'Cargo intentionally retains the existing empty-encoded-Rustflags dependency cohort; normal future builds use restored tracked config.'
    ])
output = archive.with_suffix('').with_suffix('.json')
assert not output.exists(); output.write_text(json.dumps(receipt, indent=2) + '\n')
print('Published', len(assets), 'verified members;', archive.stat().st_size, 'compressed bytes;', counts, replay['outcomes'])
