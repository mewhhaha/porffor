#!/bin/bash
set -euo pipefail
cd /workspace/lila-tooling-next
. /workspace/.scriptw-tools/activate.sh
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER
export CARGO_TARGET_DIR=/workspace/porffor/target TMPDIR=/tmp SCRIPTW_TEST_CODEGEN_JOBS=auto
export CARGO_ENCODED_RUSTFLAGS=''
export SCRIPTW_BUILD_MODULE_CACHE_DIR=/tmp/scriptw-performance-build-module-cache
export SCRIPTW_PRESERVED_OUTPUT_INVENTORY=/workspace/lila-tooling-next/target/performance-hills-20261021-attribution/candidate52b-native-preserved-output-inventory.json
export SCRIPTW_OUTPUT_PROTECTION_LOG=/workspace/lila-tooling-next/target/performance-hills-20261021-attribution/candidate52b-native-output-detach-intents.jsonl
python3 -B /tmp/scriptw-performance-batch23/prepare-native-b.py
python3 -B scripts/limited_verification.py --cloud --cloud-cpus auto -- python3 -B scripts/run_workspace_tests.py --profile release --include-ignored --test-processes 2 --partition-cli --partition-native-target scriptw-aot-wasm:scriptw_aot_wasm --selected-feature-roots --build-selected-together --idle-builds --no-test-incremental --shared-runtime-linker /tmp/scriptw-performance-release-linker/cc --shared-runtime-linker-contract /tmp/scriptw-performance-release-linker/contract.json --strip-test-debug --only-targets scriptw-aot-wasm:structure_builtins scriptw-aot-wasm:structure_language scriptw-aot-wasm:scriptw_aot_wasm scriptw-engine:scriptw_engine scriptw-engine:aot_builtins scriptw-engine:aot_language scriptw-engine:aot_realm_modules scriptw-cli:cli scriptw-runtime-image:scriptw_runtime_image --output target/performance-hills-20261021-attribution/candidate52b-native-checkpoint "$@"
