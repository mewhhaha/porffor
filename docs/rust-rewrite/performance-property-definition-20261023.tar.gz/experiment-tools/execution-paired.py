"""Checked case-wise ABBA on frozen accepted50/candidate52 ordinary products."""
import argparse,hashlib,json,os,statistics,subprocess,sys,time
from pathlib import Path
r=Path('/workspace/lila-tooling-next');b=r/'target/performance-hills-20261021-attribution'
sys.path.insert(0,str(r/'scripts'))
from benchmark_metrics import measure_process
p=argparse.ArgumentParser();p.add_argument('--confirm',action='store_true');p.add_argument('--idle-machine',required=True,action='store_true');p.add_argument('--case',action='append',dest='cases');a=p.parse_args()
out=b/('candidate52-definition-confirm' if a.confirm else 'candidate52-definition-screen');out.mkdir(exist_ok=False)
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
identities={};runners={};binary={}
for side,number in [('before',50),('after',52)]:
 rows=json.loads((b/f'candidate{number}-product-frozen.json').read_text())
 for name in ['scriptw','runtime_baseline']:
  row=next(x for x in rows if Path(x['storage']).name==name);assert sha(row['storage'])==row['sha256']
  if name=='scriptw':identities[side]=json.loads(subprocess.check_output([row['storage'],'compiler-identity'],cwd=r,text=True))
  else:runners[side]=row;binary[side]=row['storage']
config=dict(samples=7 if a.confirm else 3,warmups=10 if a.confirm else 3)
env=dict(os.environ,SCRIPTW_CACHE_DIR=str(b/'candidate52-measurement-cache'))
for key in ['SCRIPTW_WASM_TRACE','SCRIPTW_PERF_MAP_DIR']:env.pop(key,None)
report=dict(schema='scriptw-frozen-definition-diagnostic-v1',complete=False,configuration=config,cpu=sorted(os.sched_getaffinity(0)),harness_sha256=sha(__file__),identities=identities,runners=runners,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),boundary='Same-JS execution/completion in fresh Store/Realm after equal warmups. Whole invocation includes setup, conversions, definitions and checksum. Process memory is not live JS heap. Case-wise ABBA medians are descriptive, not statistical significance or isolated hash attribution.',observations=[])
fixtures=r/'crates/scriptw-cli/tests/fixtures';cases=[]
for folder,selected in [('v8_property_definition',None),('v8_key_arguments',{'property-long-fresh.js'}),('v8_baseline',{'integer.js','objects.js','retained-objects.js'})]:
 root=fixtures/folder
 for case in json.loads((root/'manifest.json').read_text())['execution']:
  if selected is None or case['file'] in selected:cases.append((root,case))
if a.cases:
 assert len(a.cases)==len(set(a.cases)) and set(a.cases)<={x['file'] for _,x in cases}
 cases=[(root,x) for root,x in cases if x['file'] in a.cases]
for root,case_spec in cases:
 name=case_spec['file'];source=root/name;expected=case_spec['stdout']
 node=subprocess.run(['node','-e','globalThis.print=console.log;require(process.argv[1])',str(source)],cwd=r,text=True,capture_output=True,check=True);assert node.stdout==expected
 for index,side in enumerate(['before','after','after','before'] if a.confirm else ['before','after']):
  label=f'{name}-{index}-{side}';artifacts=out/(label+'-wasm');artifacts.mkdir();stdout=out/(label+'.json');stderr=out/(label+'.stderr')
  command=[binary[side],str(root),str(config['samples']),str(config['warmups']),name,str(artifacts)];started=time.monotonic_ns()
  with stdout.open('x') as x,stderr.open('x') as y:event=measure_process(command,cwd=r,env=env,stdout=x,stderr=y,timeout=900,time_binary='/workspace/.scriptw-tools/gnu-time/usr/bin/time')
  assert event['exit_code']==0 and not event['timed_out'],(label,event,stderr.read_text()[-3000:])
  raw=json.loads(stdout.read_text());case=raw['cases'][0];obs=case['observations'];measured=[x for x in obs if not x['warmup']]
  assert raw['executable_sha256']==runners[side]['sha256']
  assert raw['source_commit']==identities[side]['source_revision']['commit'] and raw['source_fingerprint']==identities[side]['source_fingerprint']
  assert case['source_sha256']==sha(source) and len(measured)==config['samples'] and len(obs)==config['samples']+config['warmups']
  assert all(x['stdout']==expected for x in obs) and all(x['module_cache']=='Hit' for x in measured)
  assert any(sha(q)==case['wasm_sha256'] for q in artifacts.glob('*.wasm'))
  row=dict(label=label,side=side,file=name,oracle='stock Node stdout',command=command,raw=stdout.name,raw_sha256=sha(stdout),stderr_sha256=sha(stderr),runner_sha256=raw['executable_sha256'],source_commit=raw['source_commit'],source_fingerprint=raw['source_fingerprint'],source_sha256=case['source_sha256'],wasm_sha256=case['wasm_sha256'],elapsed_ns=time.monotonic_ns()-started,process=event,execution_ns=[x['execution_ns'] for x in measured],median_ns=statistics.median(x['execution_ns'] for x in measured))
  report['observations'].append(row);(out/'progress.json').write_text(json.dumps(report,indent=2)+'\n');print(label,round(row['median_ns']/1e6,6),'ms;',event['peak_rss_bytes'],'whole-child RSS bytes',flush=True)
report['complete']=True;(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
