"""Protect completed product bytes without invalidating fresh native dependencies."""
import hashlib
import json
from pathlib import Path

root = Path('/workspace/lila-tooling-next')
base = root / 'target/performance-hills-20261021-attribution'
release = Path('/workspace/porffor/target/release')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
rows = []
for directory in [release, release / 'deps', release / 'examples']:
    for p in sorted(directory.iterdir()):
        if not p.is_symlink():
            continue
        try:
            target = p.resolve(strict=True)
        except FileNotFoundError:
            continue
        if target.is_file() and str(target).startswith('/tmp/scriptw-performance-'):
            digest = sha(target)
            prefix = target.name.split('-')[0]
            if len(prefix) == 64:
                assert digest == prefix
            rows.append(dict(original=str(p), storage=str(target), sha256=digest, bytes=target.stat().st_size))
path = base / 'candidate52d-native-preserved-output-inventory.json'
assert not path.exists()
path.write_text(json.dumps(dict(cargo_target_dir='/workspace/porffor/target', files=rows), indent=2) + '\n')
print('Inventoried', len(rows), 'owned rustc aliases; runtime writer aliases use separate working files with immutable archived originals.')
