import hashlib,json,os,shutil,sys
from pathlib import Path
r=Path('/workspace/lila-tooling-next');b=r/'target/performance-hills-20261021-attribution';release=Path('/workspace/porffor/target/release');sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
assert json.loads((b/'candidate52-runtime-images-preserved-before-native.json').read_text())['complete']
events=[json.loads(x) for x in (b/'candidate52-product-cargo.jsonl').read_text().splitlines()]
artifacts=[x for x in events if x.get('reason')=='compiler-artifact' and x['target']['name']=='scriptw_aot_wasm' and not x['fresh']];assert len(artifacts)==2
files=[Path(n) for x in artifacts for n in x['filenames'] if n.endswith('.rlib')];assert len(files)==len(set(files))==2
stage=Path('/tmp/scriptw-performance-completed-product-libraries52');stage.mkdir(exist_ok=False);rows=[]
for p in files:
 assert p.is_file() and not p.is_symlink()
 digest=sha(p);q=stage/(digest+'-'+p.name);shutil.copy2(p,q);assert sha(q)==digest
 aliases=[p]
 aliases.extend(x for x in release.glob(p.name.split('-')[0]+'.*') if x.is_file() and not x.is_symlink() and x.samefile(p))
 rows.append(dict(original=str(p),storage=str(q),sha256=digest,bytes=p.stat().st_size,aliases=list(map(str,aliases))))
(b/'candidate52-native-staged-dependencies.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:
 for name in row['aliases']:
  p=Path(name);p.unlink();p.symlink_to(row['storage'])
# Separate mutable output for the independent native producer; never alias the
# product's retained runtime files while a build-script writer is active.
old=release/'build/scriptw-runtime-image-68ca4074ffcd8759/out';dest=Path('/tmp/scriptw-performance-native-producer52');assert not dest.exists() and old.is_dir() and not old.is_symlink()
assert all(p.is_file() and not p.is_symlink() and p.stat().st_size<16000000 for p in old.iterdir())
shutil.copytree(old,dest,copy_function=shutil.copy2)
oldfiles=[dict(name=p.name,sha256=sha(p),bytes=p.stat().st_size) for p in old.iterdir()]
assert all(sha(dest/x['name'])==x['sha256'] for x in oldfiles)
for p in old.iterdir():p.unlink()
old.rmdir();old.symlink_to(dest,target_is_directory=True)
(b/'candidate52-independent-native-producer-location.json').write_text(json.dumps(dict(logical=str(old),physical=str(dest),original_small_files=oldfiles,policy='Independent mutable build output, separate from archived/current product bytes. Cargo logical OUT_DIR unchanged.'),indent=2)+'\n')
sys.path.insert(0,str(r/'scripts'))
from workspace_test_storage import storage_snapshot
receipt=storage_snapshot(release.parent,b/'candidate52-native-checkpoint',dict(os.environ,TMPDIR='/tmp',CARGO_TARGET_DIR=str(release.parent)),native_processes=2,building=True)
(b/'candidate52-pre-native-storage.json').write_text(json.dumps(receipt,indent=2)+'\n');assert receipt['sufficient'],receipt
assert shutil.disk_usage('/tmp').free>=449334638+2*256*1024**2
print('Native storage admission passes:',{x:shutil.disk_usage(x).free for x in ['/workspace','/tmp']})
