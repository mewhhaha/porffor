"""Record bucket collisions already exercised by the retained semantic fixture."""
import hashlib
import json
from collections import defaultdict
from pathlib import Path

root = Path('/workspace/lila-tooling-next')
fixture = root / 'crates/scriptw-cli/tests/fixtures/wasm_prepared_property_hash.js'
owner = root / 'crates/scriptw-aot-wasm/src/operations/property_key_hash.rs'
mask = (1 << 64) - 1

def key_hash(index):
    key = 'property\ud800\udc00\udfff:' + 'x' * 257 + ':' + str(index)
    raw = key.encode('utf-16-le', errors='surrogatepass')
    h = 14695981039346656037
    for offset in range(0, len(raw), 2):
        h = ((h ^ int.from_bytes(raw[offset:offset + 2], 'little')) * 1099511628211) & mask
    h ^= 4
    for multiplier in [-49064778989728563, -4265267296055464877]:
        h = ((h ^ (h >> 33)) * multiplier) & mask
    return h ^ (h >> 33)

buckets = defaultdict(list)
for index in range(517):
    buckets[key_hash(index) & 2047].append(index)
collisions = {bucket: values for bucket, values in buckets.items() if len(values) > 1}
assert key_hash(207) == 0xcf31f47be76b71de
assert key_hash(220) == 0x786b270d7c2f61de
assert key_hash(207) & 2047 == key_hash(220) & 2047 == 478
assert 207 % 3 == 0 and 220 % 3 != 0
receipt = dict(
    source_commit='5c63c6597383ba4d6f56e0780daac922798b1033',
    fixture=str(fixture.relative_to(root)), fixture_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),
    algorithm=str(owner.relative_to(root)), algorithm_sha256=hashlib.sha256(owner.read_bytes()).hexdigest(),
    index_capacity=2048, keys=517, colliding_buckets=len(collisions),
    participating_keys=sum(map(len, collisions.values())), maximum_bucket_occupancy=max(map(len, collisions.values())),
    collisions=collisions, example=dict(indices=[207, 220], bucket=478,
        full_hashes=[f'{key_hash(i):016x}' for i in [207, 220]], reinserted_index=207),
    boundary='Static identification of collisions in the existing executed semantic fixture, not a new runtime test or timing. The fixture checks every distinct key and same-content replacement, then deletes/reinserts every third key and checks order, accessors, symbols, seals and freezes. These are bucket collisions with different complete hashes; equality is not inferred from a shared bucket.')
output = root / 'target/performance-hills-20261021-attribution/candidate52-existing-collision-controls.json'
output.write_text(json.dumps(receipt, indent=2) + '\n')
print({k: receipt[k] for k in ['keys', 'colliding_buckets', 'participating_keys', 'maximum_bucket_occupancy', 'example']})
