"""Preserve completed private measurement caches and diagnostic executables."""
import hashlib
import json
import shutil
import stat
import subprocess
import tarfile
from pathlib import Path

base = Path('/workspace/lila-tooling-next/target/performance-hills-20261021-attribution')
directories = [base / name for name in ['candidate50-semantic-cache', 'candidate52-semantic-cache']]
for candidate in [49, 50, 52]:
    directories.extend(p for p in (base / f'candidate{candidate}-startup-paired').iterdir()
                       if p.is_dir() and 'cache' in p.name)
paths = [p for d in directories for p in sorted(d.rglob('*')) if p.is_file()]
paths.extend(base / name / 'source-guards' for name in [
    'candidate50-fast-source-guard-original', 'candidate50-fast-source-guard-opt1',
    'candidate51-source-guards', 'candidate51-source-guards-recheck'])
assert len(paths) == len(set(paths)) and paths
assert all(p.is_file() and not p.is_symlink() and p.stat().st_nlink == 1 for p in paths)
selected = set(paths)
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit(): continue
    try:
        active = {(proc / 'exe').resolve()}
        for fd in (proc / 'fd').iterdir():
            try: active.add(fd.resolve())
            except (OSError, RuntimeError): pass
        for line in (proc / 'maps').read_text().splitlines():
            fields = line.split(maxsplit=5)
            if len(fields) == 6 and fields[5].startswith('/'): active.add(Path(fields[5]))
        assert not selected & active, ('live consumer', proc.name, selected & active)
    except (OSError, RuntimeError): pass
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
rows = [dict(original=str(p), member=str(p.relative_to(base)), bytes=p.stat().st_size,
             sha256=sha(p), mode=stat.S_IMODE(p.stat().st_mode), mtime_ns=p.stat().st_mtime_ns) for p in paths]
out = base / 'candidate52-closed-private-verification-archive'; out.mkdir()
packed = out / 'payload.tar.zst'
before = {p: shutil.disk_usage(p).free for p in ['/workspace', '/tmp']}
with packed.open('xb') as output:
    child = subprocess.Popen(['zstd', '-q', '-1', '-T1', '--long=27', '-c'], stdin=subprocess.PIPE, stdout=output)
    with tarfile.open(fileobj=child.stdin, mode='w|', format=tarfile.PAX_FORMAT) as tar:
        for row in rows: tar.add(row['original'], arcname=row['member'], recursive=False)
    child.stdin.close(); assert child.wait() == 0
child = subprocess.Popen(['zstd', '-q', '--long=27', '-dc', str(packed)], stdout=subprocess.PIPE)
actual = []
with tarfile.open(fileobj=child.stdout, mode='r|') as tar:
    for member in tar:
        actual.append((member.name, member.size, hashlib.file_digest(tar.extractfile(member), 'sha256').hexdigest()))
assert child.wait() == 0 and actual == [(r['member'], r['bytes'], r['sha256']) for r in rows]
assert all(sha(Path(r['original'])) == r['sha256'] for r in rows)
receipt = dict(complete=True, archive=str(packed), archive_bytes=packed.stat().st_size,
               archive_sha256=sha(packed), original_bytes=sum(r['bytes'] for r in rows),
               files=rows, free_before=before,
               policy='Closed private semantic/startup caches and completed standalone guard executables only. Current products, test artifacts, shared caches, sources, raw observations and dependencies excluded. All archive members verified before retiring originals; original mode/mtime retained. Restore exact members under the evidence base before reusing historical cache state.')
(out / 'inventory.json').write_text(json.dumps(receipt, indent=2) + '\n')
for p in paths: p.unlink()
receipt['free_after'] = {p: shutil.disk_usage(p).free for p in ['/workspace', '/tmp']}
(out / 'inventory.json').write_text(json.dumps(receipt, indent=2) + '\n')
print({k: receipt[k] for k in ['original_bytes', 'archive_bytes', 'free_before', 'free_after']}, flush=True)
