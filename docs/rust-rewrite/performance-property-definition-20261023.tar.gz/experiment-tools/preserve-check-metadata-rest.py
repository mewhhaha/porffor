from pathlib import Path
import hashlib,json,shutil
r=Path('/workspace/lila-tooling-next');b=r/'target/performance-hills-20261021-attribution';deps=Path('/workspace/porffor/target/release/deps');d=Path('/tmp/scriptw-performance-check-metadata52');log=b/'candidate52-aot-check.log';rows=[]
for p in sorted(deps.glob('*.rmeta')):
 if p.is_symlink() or p.stat().st_mtime < log.stat().st_ctime-150:continue
 assert p.stat().st_nlink==1
 digest=hashlib.sha256(p.read_bytes()).hexdigest();q=d/(digest+'-'+p.name)
 assert not q.exists();shutil.copy2(p,q);assert hashlib.sha256(q.read_bytes()).hexdigest()==digest
 rows.append(dict(original=str(p),storage=str(q),sha256=digest,bytes=p.stat().st_size))
(b/'candidate52-preserved-check-metadata-rest.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:
 p=Path(row['original']);p.unlink();p.symlink_to(row['storage'])
print('Preserved remaining fresh check metadata:',sum(x['bytes'] for x in rows),'bytes; free:',{x:shutil.disk_usage(x).free for x in ['/workspace','/tmp']})
