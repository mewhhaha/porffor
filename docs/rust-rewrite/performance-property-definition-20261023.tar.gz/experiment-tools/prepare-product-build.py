import hashlib,json,os,shutil
from pathlib import Path
r=Path('/workspace/lila-tooling-next');b=r/'target/performance-hills-20261021-attribution';release=Path('/workspace/porffor/target/release')
assert shutil.disk_usage('/workspace').free>=2*1024**3
assert shutil.disk_usage('/tmp').free>=1024**3
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
paths=set(release.glob('libscriptw_*'))|set((release/'deps').glob('*'))|set((release/'examples').glob('runtime_baseline*'))|{release/'scriptw'}
rows=[];missing=[]
for p in sorted(paths):
 if not p.is_symlink():continue
 try:target=p.resolve(strict=True)
 except FileNotFoundError:missing.append(str(p));continue
 if not str(target).startswith('/tmp/scriptw-performance-'):continue
 digest=sha(target);prefix=target.name.split('-')[0]
 if len(prefix)==64:assert prefix==digest
 rows.append(dict(original=str(p),storage=str(target),bytes=target.stat().st_size,sha256=digest))
with (b/'candidate52-preserved-output-inventory.json').open('x') as f:json.dump(dict(cargo_target_dir=str(release.parent),files=rows,historical_missing_aliases=missing),f,indent=2)
detached=[]
for out in sorted((release/'build').glob('scriptw-runtime-image-*/out')):
 for p in sorted(out.iterdir()):
  if not p.is_symlink():continue
  target=p.resolve(strict=True)
  assert str(target).startswith('/tmp/scriptw-performance-')
  digest=sha(target);assert target.name.startswith(digest+'-')
  detached.append(dict(original=str(p),storage=str(target),sha256=digest,bytes=target.stat().st_size));p.unlink()
with (b/'candidate52-protected-build-script-outputs.json').open('x') as f:json.dump(detached,f,indent=2)
print('Protected',len(rows),'live aliases; retained',len(detached),'runtime payloads;',len(missing),'historical missing aliases remain excluded.')
