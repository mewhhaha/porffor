(function () {
print("scriptw:rows:construction:start");
print("scriptw:rows:traversal:start");
print("scriptw:rows:traversal:end");
print(0);
})();
