(function () {
print("scriptw:rows:construction:start");
var rows = [];
for (var i = 0; i < 8192; i++) rows.push({name: 'row-' + i, values: [i + 0, i + 1, i + 2, i + 3]});
var sum = rows.length + rows[rows.length - 1].values[3];
var first = rows[0], last = rows[rows.length - 1];
var firstValues = first.values, lastValues = last.values;
print("scriptw:rows:traversal:start");
for (var pass = 0; pass < 0; pass++) {
  for (var column = 0; column < 4; column++) {
    for (var i = 0; i < rows.length; i++) sum += rows[i].values[column];
  }
}
print("scriptw:rows:traversal:end");
if (rows[0] !== first || rows[rows.length - 1] !== last ||
    first.values !== firstValues || last.values !== lastValues) {
  throw new Error('retained row identity changed during traversal');
}
print(sum);
})();
