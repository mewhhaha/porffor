"""Reproduce the row-phase diagnostic from portable raw measurements/exports."""
from pathlib import Path
import argparse
from bisect import bisect_right
from collections import Counter
import gzip
import hashlib
import json
import re
from statistics import median
import sys


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def analyze(base):
    report_path = base / 'receipt.json'
    report = json.loads(report_path.read_text())
    assert report['complete'] and report['schema'] == 'scriptw-row-phase-measurement-v1'
    sys.path.insert(0, str(base.parent / 'sources'))
    from measure_row_phases import check_map, validate
    config = report['configuration']
    entries = report['corpus']
    rows = report['observations']
    assert len(rows) == len(entries) * 4 + 12
    sources = {}
    summaries = []
    raw_by_label = {}
    common = None
    for row in rows:
        assert row['complete'] and row['process']['exit_code'] == 0 and not row['process']['timed_out']
        entry = next(entry for entry in entries if entry['file'] == row['file'])
        assert sha(base / 'corpus' / row['file']) == entry['source_sha256']
        folder = base / row['label']
        path = folder / 'stdout.json'
        assert sha(path) == row['raw_sha256']
        raw = json.loads(path.read_text())
        identity = validate(raw, entry, report['runner']['sha256'], config['samples'],
                            config['warmups'], row['observer'], row['region'])
        assert identity == row['identity'] == sources.setdefault(row['file'], identity)
        source_binding = {key: identity[key] for key in ('source_commit', 'source_fingerprint', 'linked_runtime', 'runtime_policy')}
        common = common or source_binding
        assert common == source_binding
        assert sha(folder / 'wasm' / (row['file'] + '.wasm')) == identity['wasm_sha256']
        measured = raw['cases'][0]['observations'][config['warmups']:]
        assert row['execution_median_ns'] == median(item['execution_ns'] for item in measured)
        if row['observer']:
            for key, value in row['phase_medians_ns'].items():
                assert value == median(item['row_phases'][key] for item in measured)
        raw_by_label[row['label']] = measured

    def paired(group):
        assert [row['index'] for row in group] == [0, 1, 2, 3]
        medians = [row['execution_median_ns'] for row in group]
        return dict(rounds=[dict(label=row['label'], execution_median_ns=row['execution_median_ns'],
                                 phase_medians_ns=row.get('phase_medians_ns'),
                                 execution_samples_ns=[sample['execution_ns'] for sample in raw_by_label[row['label']]])
                            for row in group],
                    paired_effect_percent=[(medians[1]/medians[0]-1)*100, (medians[2]/medians[3]-1)*100],
                    median_ratio_effect_percent=(median(medians[1:3])/median([medians[0],medians[3]])-1)*100)

    for entry in entries:
        group = [row for row in rows if row['file'] == entry['file'] and row['group'] == 'observer-abba']
        assert [row['observer'] for row in group] == [False, True, True, False]
        assert all(row['region'] is None for row in group)
        phase_keys = group[1]['phase_medians_ns']
        timed = [sample for row in group[1:3] for sample in raw_by_label[row['label']]]
        summaries.append(dict(file=entry['file'], parameters=entry['parameters'], observer_overhead=paired(group),
                              phase_round_median_ranges_ns={key: [min(row['phase_medians_ns'][key] for row in group[1:3]),
                                                                  max(row['phase_medians_ns'][key] for row in group[1:3])]
                                                            for key in phase_keys},
                              phase_median_of_round_medians_ns={key: median(row['phase_medians_ns'][key] for row in group[1:3])
                                                                for key in phase_keys},
                              invocation_gc_capacity_before_bytes=sorted(set(item['memory']['gc_capacity_before_bytes'] for item in timed)),
                              invocation_gc_capacity_after_bytes=sorted(set(item['memory']['gc_capacity_after_bytes'] for item in timed)),
                              invocation_process_peak_rss_bytes=[item['memory']['process_rss'].get('maximum_rss_bytes') for item in timed]))
    overhead = []
    for entry in entries:
        group = [row for row in rows if row['file'] == entry['file'] and row['group'] == 'profiler-abba']
        if group:
            assert [row['region'] for row in group] == [None, 'combined', 'combined', None]
            assert all(row['observer'] for row in group)
            overhead.append(dict(file=entry['file'], **paired(group)))
    assert len(overhead) == 2
    profiles = []
    for row in rows:
        if not row['region']:
            continue
        folder = base / row['label']
        audit = json.loads((folder / 'profile-export.json').read_text())
        assert audit['complete'] and audit['lost_record_count'] == 0
        assert sha(folder / 'perf.data') == row['perf_data_sha256']
        assert sha(folder / 'events.txt.gz') == audit['events_compressed_sha256']
        events = gzip.decompress((folder / 'events.txt.gz').read_bytes())
        assert hashlib.sha256(events).hexdigest() == audit['commands'][2]['sha256']
        assert events.count(b'PERF_RECORD_LOST') == 0
        assert events.count(b'PERF_RECORD_SAMPLE') == audit['sample_record_count']
        pid = row['map']['pid']
        assert audit['pid'] == pid and audit['process_comm_records']
        assert all(line.encode() in events and f'{pid}/' in line for line in audit['process_comm_records'])
        mapped = check_map(folder / f'perf-{pid}.map.identity', dict(wasm_sha256=row['identity']['wasm_sha256'],
                            linked_runtime=row['identity']['linked_runtime']))
        assert mapped == row['map']
        for export in audit['commands'][:2]:
            assert export['exit_code'] == 0 and sha(folder / export['stdout']) == export['sha256']
        mappings = []
        for line in (folder / f'perf-{pid}.map').read_text().splitlines():
            start, length, name = line.split(' ', 2)
            mappings.append((int(start, 16), int(length, 16), name))
        mappings.sort()
        starts = [start for start, _, _ in mappings]
        counts, dsos = Counter(), Counter()
        for line in (folder / 'cpu-samples.txt').read_text().splitlines():
            if not line.strip():
                continue
            match = re.fullmatch(r'\s*(\d+)\s+([0-9a-f]+)\s+(.+)\s+\((.*)\)\s*', line)
            assert match, repr(line)
            sampled_pid, address, symbol, dso = match.groups()
            assert int(sampled_pid) == pid, 'sample process differs from loaded-code map'
            address = int(address, 16)
            index = bisect_right(starts, address)-1
            if index >= 0 and address < mappings[index][0]+mappings[index][1]:
                symbol = mappings[index][2]
                dso = 'mapped-' + symbol.split(':')[1]
            symbol = re.sub(r'\+0x[0-9a-f]+$', '', symbol.strip())
            counts[symbol] += 1
            dsos[dso] += 1
        total = sum(counts.values())
        assert total == audit['sample_record_count']
        profiles.append(dict(label=row['label'], file=row['file'], region=row['region'], pid=pid,
                             samples=total, lost_samples=0, sampled_pid_matches_map=True,
                             phase_medians_ns=row['phase_medians_ns'],
                             symbols=[dict(symbol=symbol, samples=count, percent=count/total*100) for symbol,count in counts.most_common()],
                             dsos=dict(dsos),
                             control_spans_ns=[sample['row_phases']['perf_control_spans'] for sample in raw_by_label[row['label']]]))
    assert len(profiles) == 8
    return dict(schema='scriptw-row-phase-analysis-v1', receipt_sha256=sha(report_path),
                analyzer_sha256=sha(Path(__file__)), product=common, runner=report['runner'],
                machine=report['machine'], configuration=config, cases=summaries,
                profiler_overhead=overhead, profiles=profiles,
                boundaries=[
                    'Diagnostic same-source runner; compiler release libraries and native runtime are unchanged source53.',
                    'Wall-clock phases inside one fresh Store; all invocation scores retain construction and the marker/identity workload.',
                    'Observer ABBA compares the same marked source with callback off/on/on/off; it does not isolate the added JS marker instructions.',
                    'CPU samples cover enabled measured regions only, with small boundary-control work; no allocation counters or exact GC pause times.',
                    'All original samples and both adjacent effects are retained; no speedup or significance claim.',
                    'Capacity and RSS are not live JS heap size; README V8 and full-suite cohorts remain separate.'
                ])


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = analyze(args.evidence)
    with args.output.open('x') as stream:
        stream.write(json.dumps(result, indent=2)+'\n')
    print('Verified and summarized', len(result['cases']), 'cases and', len(result['profiles']), 'profiles')
