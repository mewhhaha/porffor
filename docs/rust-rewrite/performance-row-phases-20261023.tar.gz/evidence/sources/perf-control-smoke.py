"""Exercise the real bundled perf FIFO protocol; not a performance score."""
from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path('/workspace/lila-tooling-next')
base = root / 'target/performance-hills-20261021-attribution'
out = base / 'candidate54b-perf-control-smoke'
out.mkdir(exist_ok=False)
(out / 'wasm').mkdir()
for name in ['control', 'ack']: os.mkfifo(out / name)
perf = Path('/tmp/scriptw-perf-tool/extract/usr/bin/perf')
runner = Path('/tmp/scriptw-performance-phase-runner-54b/runtime_baseline')
os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
environment = dict(os.environ,
    LD_LIBRARY_PATH='/tmp/scriptw-perf-tool/extract/usr/lib/x86_64-linux-gnu',
    SCRIPTW_CACHE_DIR=str(base / 'candidate53-measurement-cache-after'),
    SCRIPTW_ROW_PERF_CONTROL=str(out / 'control'), SCRIPTW_ROW_PERF_ACK=str(out / 'ack'),
    SCRIPTW_ROW_PERF_REGION='combined', SCRIPTW_PERF_MAP_DIR='/tmp')
environment.pop('SCRIPTW_WASM_TRACE', None)
command = [str(perf), 'record', '-D', '-1', '--control', f"fifo:{out/'control'},{out/'ack'}",
           '-e', 'cpu-clock:u', '-F', '99', '-g', '-o', str(out / 'perf.data'), '--',
           'env', '-u', 'LD_LIBRARY_PATH', str(runner), str(base / 'candidate54-row-phase-corpus'),
           '3', '1', 'row-phases-empty.js', str(out / 'wasm'), '--row-phases']
with (out / 'stdout.json').open('x') as stdout, (out / 'stderr.log').open('x') as stderr:
    process = subprocess.run(command, cwd=root, env=environment, stdout=stdout, stderr=stderr, timeout=120)
assert process.returncode == 0, (out / 'stderr.log').read_text()
raw = json.loads((out / 'stdout.json').read_text())
observations = raw['cases'][0]['observations']
assert observations[0]['warmup'] and not observations[0]['row_phases']['perf_sampled']
assert observations[0]['row_phases']['perf_control_spans'] == []
for row in observations[1:]:
    phase = row['row_phases']
    assert not row['warmup'] and phase['perf_sampled'] and phase['perf_region'] == 'combined'
    assert [span['enable'] for span in phase['perf_control_spans']] == [True, False]
sha = lambda path: hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
(out / 'receipt.json').write_text(json.dumps(dict(complete=True, purpose='real perf/FIFO correctness only; no speed or CPU attribution claim',
    command=command, profiler_sha256=sha(perf), runner_sha256=sha(runner),
    source=raw['source_commit'], raw_sha256=sha(out / 'stdout.json'),
    checked_measured_enable_disable_pairs=3, warmup_commands=0), indent=2) + '\n')
print('Real perf acknowledged all three measured enable/disable pairs; warmup stayed disabled')
