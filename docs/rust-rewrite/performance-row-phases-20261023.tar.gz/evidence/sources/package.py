"""Freeze portable raw phase evidence; preserve failed first attempts too."""
from pathlib import Path
import hashlib
import json
import shutil
import tarfile

root = Path('/workspace/lila-tooling-next')
base = root / 'target/performance-hills-20261021-attribution'
batch = Path('/tmp/scriptw-performance-batch26')
stage = base / 'candidate54b-row-publication'
stage.mkdir(exist_ok=False)
(stage / 'sources').mkdir()
for name in ('measure_row_phases.py', 'benchmark_metrics.py', 'performance_corpus.py'):
    shutil.copy2(root / 'scripts' / name, stage / 'sources' / name)
shutil.copy2(root / 'crates/scriptw-cli/examples/runtime_baseline.rs', stage / 'sources' / 'runtime_baseline.rs')
shutil.copytree(root / 'crates/scriptw-cli/examples/runtime_baseline', stage / 'sources/runtime_baseline')
for name in ('analyze.py', 'export-profiles.py', 'export-profiles-first.py', 'package.py', 'build-cached-runner.py',
             'perf-control-smoke.py', 'preserve-failed-runner.py'):
    shutil.copy2(batch / name, stage / 'sources' / name)
for name in ('test_measure_row_phases.py', 'test_performance_corpus.py'):
    shutil.copy2(root / 'scripts/tests' / name, stage / 'sources' / name)
report = json.loads((base / 'candidate54b-row-measurements/receipt.json').read_text())
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
assert report['complete'] and report['harness_sha256'] == sha(stage / 'sources/measure_row_phases.py')
build = json.loads((base / 'candidate54b-cached-driver-build.json').read_text())
assert build['complete']
for name in ['runtime_baseline.rs', 'runtime_baseline/phase_observer.rs']:
    original = str(batch / name)
    expected = next(row['sha256'] for row in build['inputs'] if row['path'] == original)
    assert sha(stage / 'sources' / name) == expected
for name in ['candidate54-cached-driver-build.json', 'candidate54b-cached-driver-build.json',
             'candidate54-closed-runner-preservation.json', 'candidate54-closed-replay-binary-dedup.json',
             'candidate53-independent-native-runtime-identity.json']:
    shutil.copy2(base / name, stage / name)
for pattern in ['candidate54-cached-driver-*.log', 'candidate54b-cached-driver-*.log']:
    for path in base.glob(pattern):
        shutil.copy2(path, stage / path.name)
shutil.copy2(batch / 'measurement.log', stage / 'measurement.log')

# The raw tree remains in place; tar reads each regular file once. FIFOs cannot
# be evidence payloads, and all source/Wasm/profile/raw JSON bytes are retained.
paths = []
for path in stage.rglob('*'):
    if path.is_file():
        paths.append((path, 'evidence/' + str(path.relative_to(stage))))
folders = [('candidate54b-row-measurements', 'measurements'),
           ('candidate54-phase-smoke', 'first-phase-smoke'),
           ('candidate54-perf-control-smoke', 'failed-perf-smoke'),
           ('candidate54b-perf-control-smoke', 'verified-perf-smoke')]
for folder, target in folders:
    for path in (base / folder).rglob('*'):
        if path.is_file():
            paths.append((path, 'evidence/' + target + '/' + str(path.relative_to(base / folder))))
for path in [Path('/tmp/scriptw-performance-batch25/runtime_baseline.rs'),
             Path('/tmp/scriptw-performance-batch25/runtime_baseline/phase_observer.rs'),
             Path('/tmp/scriptw-performance-batch25/perf-control-smoke.log')]:
    paths.append((path, 'evidence/failed-first-sources/' + path.name))
assets = [dict(path=name, bytes=path.stat().st_size, sha256=sha(path)) for path, name in sorted(paths, key=lambda row: row[1])]
assert len(set(row['path'] for row in assets)) == len(assets)
archive = root / 'docs/rust-rewrite/performance-row-phases-20261023.tar.gz'
with tarfile.open(archive, 'x:gz') as tar:
    for path, name in sorted(paths, key=lambda row: row[1]):
        tar.add(path, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(assets)
    for member, expected in zip(members, assets):
        assert member.isfile() and member.name == expected['path'] and member.size == expected['bytes']
        assert hashlib.file_digest(tar.extractfile(member), 'sha256').hexdigest() == expected['sha256']
inventory = dict(schema='scriptw-row-phase-evidence-v1', complete=True,
                 archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive)),
                 assets=assets, build=build,
                 boundary='Raw profiles, samples, sources and original failed/successful diagnostics. Cached source53 libraries and frozen executables are identified by digest; their binary contents are not embedded.')
(root / 'docs/rust-rewrite/performance-row-phases-20261023-evidence.json').write_text(json.dumps(inventory, indent=2)+'\n')
print('Verified portable archive:', len(assets), 'members,', archive.stat().st_size, 'compressed bytes')
