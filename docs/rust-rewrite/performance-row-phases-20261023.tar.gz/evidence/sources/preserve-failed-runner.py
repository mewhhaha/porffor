from pathlib import Path
import hashlib
import json
import subprocess

base = Path('/workspace/lila-tooling-next/target/performance-hills-20261021-attribution')
old = Path('/tmp/scriptw-performance-phase-runner-54/runtime_baseline')
archive = old.with_suffix('.zst')
receipt = json.loads((base / 'candidate54-cached-driver-build.json').read_text())
expected = next(row for row in receipt['outputs'] if row['path'] == str(old))
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
assert sha(old) == expected['sha256']
with archive.open('xb') as output:
    subprocess.run(['zstd', '-T1', '-3', '-c', str(old)], stdout=output, check=True)
process = subprocess.Popen(['zstd', '-dc', str(archive)], stdout=subprocess.PIPE)
restored = hashlib.file_digest(process.stdout, 'sha256').hexdigest()
assert process.wait() == 0 and restored == expected['sha256']
record = dict(original=expected, compressed_path=str(archive),
              compressed_bytes=archive.stat().st_size, compressed_sha256=sha(archive),
              decoded_sha256=restored,
              reason='Closed failed diagnostic runner, fully preserved before freeing scratch space; frozen source53 product and ordinary runner untouched.')
(base / 'candidate54-closed-runner-preservation.json').write_text(json.dumps(record, indent=2)+'\n')
old.unlink()
print(json.dumps(record), flush=True)
