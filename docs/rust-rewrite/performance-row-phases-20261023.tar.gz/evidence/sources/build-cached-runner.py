"""Link only the diagnostic driver against the measured source53 libraries."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('/workspace/lila-tooling-next')
base = root / 'target/performance-hills-20261021-attribution'
batch = Path('/tmp/scriptw-performance-batch26')
out = Path('/tmp/scriptw-performance-phase-runner-54b')
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
space = os.statvfs(root)
assert space.f_bavail * space.f_frsize >= 2 * 1024**3, 'keep two-GiB workspace reserve'
out.mkdir(exist_ok=False)
cargo_path = base / 'candidate53-product-cargo.jsonl'
rows = [json.loads(line) for line in cargo_path.read_text().splitlines() if line.startswith('{')]
libs = {}
for row in rows:
    if (row.get('reason') == 'compiler-artifact' and row['target']['name'] in
            ['scriptw_engine', 'serde_json', 'sha2'] and row['profile']['opt_level'] == '3'
            and not row['profile']['test']):
        libs[row['target']['name']] = next(Path(p) for p in row['filenames'] if p.endswith('.rlib'))
assert set(libs) == {'scriptw_engine', 'serde_json', 'sha2'}
images = json.loads((base / 'candidate53-independent-native-runtime-identity.json').read_text())
native = next(row for row in images['files'] if Path(row['product']).name == 'libscriptw_runtime_images.a')
assert sha(native['product']) == native['product_sha256']
inputs = [batch / 'runtime_baseline.rs', batch / 'runtime_baseline/phase_observer.rs',
          *libs.values(), Path(native['product'])]
bound = [dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p)) for p in inputs]
common = ['rustc', '--edition=2021', '-C', 'opt-level=3', '-C', 'strip=debuginfo',
          '-L', 'dependency=/workspace/porffor/target/release/deps',
          '-L', 'native=' + str(Path(native['product']).parent)]
for name, path in sorted(libs.items()):
    common += ['--extern', f'{name}={path}']
tests = batch / 'phase-tests.rs'
tests.write_text('#[path="runtime_baseline/phase_observer.rs"]\nmod phase_observer;\n')
commands = [
    [*common, '--crate-name', 'runtime_baseline', str(batch / 'runtime_baseline.rs'), '-o', str(out / 'runtime_baseline')],
    [*common, '--crate-name', 'phase_observer_tests', '--test', str(tests), '-o', str(out / 'phase-tests')],
    [str(out / 'phase-tests'), '--test-threads=1'],
]
receipt = dict(schema='scriptw-cached-library-diagnostic-build-v1', complete=False,
               boundary='Only the diagnostic harness is compiled. Existing measured source53 release libraries and byte-verified R are linked unchanged. This is not a new product/Cargo build or full native acceptance.',
               product_cargo_sha256=sha(cargo_path), inputs=bound, commands=[])
for index, command in enumerate(commands):
    started = time.monotonic_ns()
    log = base / f'candidate54b-cached-driver-{index}.log'
    with log.open('x') as stream:
        run = subprocess.run(['python3', '-B', 'scripts/limited_verification.py', '--cloud', '--cloud-cpus', 'auto', '--', *command], cwd=root, stdout=stream, stderr=subprocess.STDOUT)
    receipt['commands'].append(dict(command=command, exit_code=run.returncode,
                                    elapsed_ns=time.monotonic_ns() - started,
                                    log=str(log), log_sha256=sha(log)))
    (base / 'candidate54b-cached-driver-build.json').write_text(json.dumps(receipt, indent=2) + '\n')
    assert run.returncode == 0, log.read_text()[-5000:]
    print(index, 'passed in', round(receipt['commands'][-1]['elapsed_ns']/1e9, 3), 'seconds', flush=True)
assert all(sha(row['path']) == row['sha256'] for row in bound)
receipt.update(complete=True, outputs=[dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(out.iterdir())])
(base / 'candidate54b-cached-driver-build.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('Diagnostic driver and its tests built from unchanged cached libraries', flush=True)
