"""Export original perf data, retaining loss records and process identities."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import subprocess

root = Path('/workspace/lila-tooling-next')
base = root / 'target/performance-hills-20261021-attribution/candidate54b-row-measurements'
report = json.loads((base / 'receipt.json').read_text())
assert report['complete']
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
perf = Path(report['perf']['path'])
assert sha(perf) == report['perf']['sha256']
env = dict(os.environ, LD_LIBRARY_PATH='/tmp/scriptw-perf-tool/extract/usr/lib/x86_64-linux-gnu')
for row in report['observations']:
    if not row['region']:
        continue
    folder = base / row['label']
    assert sha(folder / 'perf.data') == row['perf_data_sha256']
    audit = dict(commands=[], complete=False)
    commands = [
        ('cpu-samples.txt', ['script', '--hide-call-graph', '-F', 'pid,ip,sym,dso']),
        ('cpu-report.txt', ['report', '--stdio', '--no-children', '-g', 'none',
                            '--percent-limit', '0', '--show-nr-samples', '--show-total-period',
                            '-s', 'dso,symbol']),
        ('events.txt', ['script', '-D']),
    ]
    for name, options in commands:
        command = [str(perf), *options, '-i', str(folder / 'perf.data')]
        with (folder / name).open('xb') as stdout, (folder / (name + '.stderr')).open('xb') as stderr:
            run = subprocess.run(command, env=env, stdout=stdout, stderr=stderr, timeout=60)
        audit['commands'].append(dict(command=command, exit_code=run.returncode,
                                       stdout=name, sha256=sha(folder / name)))
        assert run.returncode == 0, (folder / (name + '.stderr')).read_text()
    events = (folder / 'events.txt').read_bytes()
    audit['lost_record_count'] = events.count(b'PERF_RECORD_LOST')
    audit['sample_record_count'] = events.count(b'PERF_RECORD_SAMPLE')
    pid = row['map']['pid']
    audit['pid'] = pid
    audit['process_comm_records'] = [line.decode() for line in events.splitlines()
                                      if b'PERF_RECORD_COMM' in line
                                      and f'{pid}/'.encode() in line]
    assert audit['process_comm_records'], 'saved map PID must be present in perf process metadata'
    assert audit['lost_record_count'] == 0, 'lost samples need investigation, never silent acceptance'
    compressed = folder / 'events.txt.gz'
    with compressed.open('xb') as stream:
        stream.write(gzip.compress(events, mtime=0))
    assert gzip.decompress(compressed.read_bytes()) == events
    audit['events_compressed_sha256'] = sha(compressed)
    # Only this just-created export is replaced by its verified lossless copy.
    (folder / 'events.txt').unlink()
    audit['complete'] = True
    (folder / 'profile-export.json').write_text(json.dumps(audit, indent=2)+'\n')
    print(row['label'], audit['sample_record_count'], 'samples, PID', pid, 'verified; zero lost', flush=True)
