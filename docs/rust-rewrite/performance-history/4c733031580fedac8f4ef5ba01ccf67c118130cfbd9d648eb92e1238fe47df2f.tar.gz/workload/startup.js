print("scriptw-startup-ok");
